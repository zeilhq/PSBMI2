# plan.md

## 1) Objectives
- Deliver a production-ready, mobile-first and desktop-friendly web app for **pendataan santri pesantren** with a **collapsible/hidable sidebar**.
- Support complete operational flows end-to-end:
  - Input santri (Data Diri) → overview (Santri + detail modal) → administrasi pembayaran + **kwitansi PDF** → seragam → perlengkapan asrama + murobbi → **name tag/KTS** numbering + print tracking.
- Provide **WhatsApp click-to-chat** actions (wa.me) for quick coordination.
- Provide **backend-generated PDFs** (ReportLab) for consistent printing across devices.
- Enforce **role-based access** (Admin vs Petugas) plus **granular per-menu permissions**, enforced both **frontend (hide menus)** and **backend (403)**.
- Current status: **Phase 2 complete**; system is ready for **User Acceptance Testing (UAT)**.

## 2) Implementation Steps

### Phase 1 — Core Flow POC (Skip: app is standard CRUD + simple JWT)
- No POC; proceeded directly to V1 build.

### Phase 2 — V1 App Development (Core usable MVP)
**Scope focus:** build the full operational app (all 8 menus) with reliable mobile/desktop UX, PDF output, and permissions.

1) **Project setup (implemented)**
- Backend: FastAPI + Motor (async MongoDB), JWT auth, bcrypt hashing, modular routes.
- Frontend: React (CRA/craco) + Tailwind + shadcn/ui + React Router.
- Mobile-first layout: desktop sidebar + mobile drawer (Sheet).

2) **MongoDB schema (implemented as collections/documents)**
- `users`: username, password_hash, nama, role, wa_number, profile_photo(base64), permissions[], active, created_at.
- `santri`: nis, nama, alamat, wali_nama, wali_wa, foto(base64), murobbi_id,
  - `administrasi` items[{key,name,price,paid,paid_at}],
  - `seragam` (biru/ungu/coklat: ukuran_seragam, ukuran_sarung, ready, delivered + all_delivered),
  - `perlengkapan` (kasur/bantal/guling/sarung_bantal_guling/alat_tulis/yanbua + all_delivered),
  - `print_status` (name_tag_printed, name_tag_ready, kts_printed, lemari_label_printed),
  - bet_no & lemari_no derived from config + ordering,
  - timestamps + created_by.
- `murobbi`: nama, wa.
- `config`: admin_fees, starting_bet_no, starting_lemari_no, psb_admin_link.

3) **Backend API (FastAPI) (implemented; under `/api`)**
- Auth:
  - `POST /api/auth/login`
  - `GET /api/auth/me`
- Dashboard:
  - `GET /api/dashboard` (KPI counts/sums + petugas list + PSB link)
- Santri:
  - `GET /api/santri` (list)
  - `POST /api/santri` (create)
  - `GET /api/santri/{id}` (detail)
  - `PUT /api/santri/{id}` (update)
  - `DELETE /api/santri/{id}` (delete)
  - Administrasi toggle:
    - `POST /api/santri/{id}/administrasi/toggle` body `{key, paid}`
- PDFs (ReportLab):
  - `GET /api/santri/{id}/kwitansi.pdf`
  - `GET /api/santri/print/name-tag.pdf`
  - `GET /api/santri/print/kts.pdf`
- Admin (admin-only for write + protected):
  - Users CRUD: `GET/POST/PUT/DELETE /api/admin/users...`
  - Murobbi CRUD: `GET/POST/PUT/DELETE /api/admin/murobbi...` (read allowed for authenticated, write admin-only)
  - Config: `GET/PUT /api/admin/config`
  - Menu keys: `GET /api/admin/menu-keys`

4) **PDF generation (ReportLab) (implemented)**
- Kwitansi A5: identitas santri + item biaya + totals + timestamps + signature placeholders.
- Name Tag (A4 grid): nomor bet + nama + NIS.
- KTS preview (A4 grid): NIS, Nama, Orang Tua/Wali, Alamat.

5) **Photos (client-side compression) (implemented)**
- Frontend uses `browser-image-compression` then uploads as base64 data URL.
- Fallback avatar when no photo.

6) **Frontend UI (mobile-first) (implemented)**
- Layout: collapsible sidebar (desktop) + drawer (mobile).
- Pages (all implemented and integrated):
  - Dashboard: KPI cards + petugas list + WA buttons + PSB link + quick actions.
  - Santri: card grid + search + detail modal (tabs) + quick links to related pages.
  - Data Diri: create/edit form + photo upload + PSB link + murobbi assignment.
  - Administrasi: per-santri selection + fee checklist + totals/progress + print kwitansi.
  - Seragam: per-santri size inputs per color + ready/delivered + WA confirm + save.
  - Perlengkapan: per-santri checklist + murobbi select + WA notify + save.
  - Name Tag/KTS: previews + print status checklists + print PDF buttons.
  - Akses Admin: Users (CRUD + permissions), Biaya (CRUD), Murobbi (CRUD), Konfigurasi (starting numbers + PSB link).

7) **Permissions (granular menu access) (implemented)**
- Backend dependencies enforce:
  - Admin-only routes (`/api/admin/*` writes + user management)
  - Permission per menu key for operational routes.
- Frontend hides menu items not permitted and shows “Akses ditolak” page if navigated directly.

**Phase 2 user stories (completed & validated)**
1. Petugas can add new santri from “Data Diri” and see them in “Santri”.
2. Petugas can upload compressed photo and view it in card/modal.
3. Petugas can record administrasi payments and print kwitansi PDF.
4. Petugas can record uniform sizes and open WhatsApp with a prefilled message.
5. Admin can see dashboard totals (counts/sums/status).
6. Petugas can update perlengkapan status + assign murobbi.
7. Petugas can manage name tag/KTS print checklists and print PDFs.
8. Admin can manage users + permissions, biaya, murobbi, and config.

**Phase 2 checkpoint/testing (completed)**
- Comprehensive testing via `testing_agent_v3`:
  - Backend: **31/31 tests passed** (auth, CRUD, permissions, PDFs, config)
  - Frontend: all pages validated, permissions separation admin vs petugas verified, mobile drawer verified.

### Phase 3 — Feature Expansion (optional; polish and advanced workflows)
- Add advanced filtering/search (by payment completeness, seragam delivered, perlengkapan delivered, murobbi).
- Add audit trail (who updated which fields + timestamps) and activity log.
- Add batch operations (bulk mark delivered/printed) and export (CSV/Excel) if needed.
- Improve admin fee updates behavior for existing santri (optional: apply updated fee templates to existing records).
- Optional: lemari label PDF generation (if required as separate PDF output).

**Phase 3 user stories (optional)**
1. Petugas can filter santri by murobbi/paid/delivered so processing is faster.
2. Admin can apply updated biaya template to existing santri with confirmation.
3. Petugas can bulk-print/mark print status for faster labeling.

**Phase 3 checkpoint/testing (optional)**
- Run regression tests for filters, bulk operations, and permission rules.

### Phase 4 — Hardening & Release (UAT + deployment readiness)
- UAT with real workflows and data volume.
- Security hardening (optional): rate-limit login, stronger password policy, rotation of JWT secret.
- Data validation and error handling improvements.
- Deployment packaging: environment variables, backup strategy, and monitoring.

**Phase 4 user stories**
1. Admin can onboard new petugas and restrict menu access safely.
2. Petugas only sees allowed menus and cannot bypass via direct URL.
3. System provides stable PDF printing across devices/printers.

## 3) Next Actions
1. **UAT (User Acceptance Testing):** validate real operational flow with 10–50 sample santri.
2. Collect feedback on:
   - fee items/labels, size options, WA message templates, print layout spacing.
3. Decide Phase 3 enhancements (filters, exports, lemari labels, audit logs).
4. Prepare deployment checklist (env vars, MongoDB backup, admin password change from default).

## 4) Success Criteria
- Mobile + desktop responsive UI with collapsible/hidable sidebar and smooth navigation.
- Santri CRUD works; santri list as cards; detail modal shows linked data with photo.
- Administrasi supports per-item paid tracking, remaining calculation, and downloadable/printable kwitansi PDF.
- Seragam & Perlengkapan data saved per santri; WA links open with correct prefilled messages.
- Name tag/KTS numbering derives from config; print status is trackable; PDFs download/open correctly.
- Admin can manage users, permissions, murobbi, and config values.
- Unauthorized access is blocked server-side; petugas cannot access admin menus/routes.
- Testing baseline: backend endpoints and frontend flows pass regression checks (currently achieved: 100% test pass in iteration 1).
