"""Comprehensive backend API tests for Pesantren Amtsilati Santri Management."""
import requests
import sys
from datetime import datetime

BASE_URL = "https://santri-admin-hub.preview.emergentagent.com/api"

class APITester:
    def __init__(self):
        self.admin_token = None
        self.petugas_token = None
        self.tests_run = 0
        self.tests_passed = 0
        self.failed_tests = []
        self.test_santri_id = None

    def log(self, msg, level="INFO"):
        print(f"[{level}] {msg}")

    def run_test(self, name, method, endpoint, expected_status, data=None, token=None, check_pdf=False):
        """Run a single API test."""
        url = f"{BASE_URL}{endpoint}"
        headers = {'Content-Type': 'application/json'}
        if token:
            headers['Authorization'] = f'Bearer {token}'

        self.tests_run += 1
        self.log(f"Testing {name}...")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=10)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers, timeout=10)
            elif method == 'PUT':
                response = requests.put(url, json=data, headers=headers, timeout=10)
            elif method == 'DELETE':
                response = requests.delete(url, headers=headers, timeout=10)

            success = response.status_code == expected_status
            
            if success:
                self.tests_passed += 1
                self.log(f"✅ PASSED - {name} (Status: {response.status_code})", "PASS")
                
                # For PDF endpoints, check content-type
                if check_pdf:
                    content_type = response.headers.get('content-type', '')
                    if 'application/pdf' not in content_type:
                        self.log(f"⚠️  WARNING - PDF endpoint returned wrong content-type: {content_type}", "WARN")
                    elif len(response.content) == 0:
                        self.log(f"⚠️  WARNING - PDF endpoint returned empty body", "WARN")
                    else:
                        self.log(f"✅ PDF valid (size: {len(response.content)} bytes)", "PASS")
                
                return True, response.json() if not check_pdf and response.content else response.content
            else:
                self.tests_passed += 1 if response.status_code == expected_status else 0
                self.log(f"❌ FAILED - {name} - Expected {expected_status}, got {response.status_code}", "FAIL")
                self.log(f"   Response: {response.text[:200]}", "FAIL")
                self.failed_tests.append({
                    "test": name,
                    "expected": expected_status,
                    "actual": response.status_code,
                    "response": response.text[:200]
                })
                return False, {}

        except Exception as e:
            self.log(f"❌ FAILED - {name} - Error: {str(e)}", "FAIL")
            self.failed_tests.append({
                "test": name,
                "error": str(e)
            })
            return False, {}

    def test_auth(self):
        """Test authentication endpoints."""
        self.log("\n========== TESTING AUTH ==========", "INFO")
        
        # Test admin login
        success, response = self.run_test(
            "Admin Login",
            "POST",
            "/auth/login",
            200,
            data={"username": "admin", "password": "admin123"}
        )
        if success and 'access_token' in response:
            self.admin_token = response['access_token']
            self.log(f"✅ Admin token obtained", "PASS")
        else:
            self.log("❌ CRITICAL: Admin login failed - cannot proceed", "FAIL")
            return False

        # Test petugas login
        success, response = self.run_test(
            "Petugas Login",
            "POST",
            "/auth/login",
            200,
            data={"username": "petugas", "password": "petugas123"}
        )
        if success and 'access_token' in response:
            self.petugas_token = response['access_token']
            self.log(f"✅ Petugas token obtained", "PASS")
        else:
            self.log("⚠️  WARNING: Petugas login failed", "WARN")

        # Test wrong password
        self.run_test(
            "Login with wrong password",
            "POST",
            "/auth/login",
            401,
            data={"username": "admin", "password": "wrongpass"}
        )

        # Test /auth/me
        self.run_test(
            "GET /auth/me (admin)",
            "GET",
            "/auth/me",
            200,
            token=self.admin_token
        )

        return True

    def test_dashboard(self):
        """Test dashboard endpoint."""
        self.log("\n========== TESTING DASHBOARD ==========", "INFO")
        
        success, response = self.run_test(
            "GET /dashboard",
            "GET",
            "/dashboard",
            200,
            token=self.admin_token
        )
        
        if success:
            required_keys = ['santri_count', 'total_uang', 'paid_uang', 'seragam_lengkap', 
                           'perlengkapan_lengkap', 'petugas', 'psb_admin_link']
            for key in required_keys:
                if key not in response:
                    self.log(f"⚠️  WARNING - Dashboard missing key: {key}", "WARN")

    def test_santri_crud(self):
        """Test santri CRUD operations."""
        self.log("\n========== TESTING SANTRI CRUD ==========", "INFO")
        
        # Create santri
        test_nis = f"TEST{datetime.now().strftime('%H%M%S')}"
        success, response = self.run_test(
            "POST /santri (create)",
            "POST",
            "/santri",
            200,
            data={
                "nis": test_nis,
                "nama": "Test Santri",
                "alamat": "Jl. Test No. 123",
                "wali_nama": "Wali Test",
                "wali_wa": "628123456789",
                "foto": "",
                "murobbi_id": None
            },
            token=self.admin_token
        )
        
        if success and 'id' in response:
            self.test_santri_id = response['id']
            self.log(f"✅ Santri created with ID: {self.test_santri_id}", "PASS")
            
            # Check auto-assigned fields
            if 'bet_no' not in response or 'lemari_no' not in response:
                self.log("⚠️  WARNING - bet_no or lemari_no not auto-assigned", "WARN")
            if 'administrasi' not in response or len(response.get('administrasi', [])) == 0:
                self.log("⚠️  WARNING - administrasi not auto-seeded", "WARN")
        else:
            self.log("❌ CRITICAL: Failed to create santri", "FAIL")
            return False

        # Test duplicate NIS
        self.run_test(
            "POST /santri (duplicate NIS should fail)",
            "POST",
            "/santri",
            400,
            data={
                "nis": test_nis,
                "nama": "Duplicate Test",
                "alamat": "",
                "wali_nama": "",
                "wali_wa": "",
                "foto": "",
                "murobbi_id": None
            },
            token=self.admin_token
        )

        # List santri
        success, response = self.run_test(
            "GET /santri (list)",
            "GET",
            "/santri",
            200,
            token=self.admin_token
        )
        
        if success and isinstance(response, list):
            self.log(f"✅ Found {len(response)} santri", "PASS")

        # Get single santri
        if self.test_santri_id:
            self.run_test(
                "GET /santri/{id}",
                "GET",
                f"/santri/{self.test_santri_id}",
                200,
                token=self.admin_token
            )

            # Update santri - test seragam all_delivered flag
            self.run_test(
                "PUT /santri/{id} (update seragam)",
                "PUT",
                f"/santri/{self.test_santri_id}",
                200,
                data={
                    "seragam": {
                        "biru": {"ukuran_seragam": "M", "ukuran_sarung": "L", "ready": True, "delivered": True},
                        "ungu": {"ukuran_seragam": "M", "ukuran_sarung": "L", "ready": True, "delivered": True},
                        "coklat": {"ukuran_seragam": "M", "ukuran_sarung": "L", "ready": True, "delivered": True},
                        "all_delivered": False  # Should be auto-computed to True
                    }
                },
                token=self.admin_token
            )

            # Update perlengkapan - test all_delivered flag
            self.run_test(
                "PUT /santri/{id} (update perlengkapan)",
                "PUT",
                f"/santri/{self.test_santri_id}",
                200,
                data={
                    "perlengkapan": {
                        "kasur": True,
                        "bantal": True,
                        "guling": True,
                        "sarung_bantal_guling": True,
                        "alat_tulis": True,
                        "yanbua": True,
                        "all_delivered": False  # Should be auto-computed to True
                    }
                },
                token=self.admin_token
            )

        return True

    def test_administrasi(self):
        """Test administrasi endpoints."""
        self.log("\n========== TESTING ADMINISTRASI ==========", "INFO")
        
        if not self.test_santri_id:
            self.log("⚠️  SKIP - No test santri ID available", "WARN")
            return

        # Toggle payment
        self.run_test(
            "POST /santri/{id}/administrasi/toggle",
            "POST",
            f"/santri/{self.test_santri_id}/administrasi/toggle",
            200,
            data={"key": "seragam", "paid": True},
            token=self.admin_token
        )

        # Get kwitansi PDF
        self.run_test(
            "GET /santri/{id}/kwitansi.pdf",
            "GET",
            f"/santri/{self.test_santri_id}/kwitansi.pdf",
            200,
            token=self.admin_token,
            check_pdf=True
        )

    def test_print_pdfs(self):
        """Test print PDF endpoints."""
        self.log("\n========== TESTING PRINT PDFs ==========", "INFO")
        
        self.run_test(
            "GET /santri/print/name-tag.pdf",
            "GET",
            "/santri/print/name-tag.pdf",
            200,
            token=self.admin_token,
            check_pdf=True
        )

        self.run_test(
            "GET /santri/print/kts.pdf",
            "GET",
            "/santri/print/kts.pdf",
            200,
            token=self.admin_token,
            check_pdf=True
        )

    def test_admin_routes(self):
        """Test admin-only routes."""
        self.log("\n========== TESTING ADMIN ROUTES ==========", "INFO")
        
        # List users (admin only)
        self.run_test(
            "GET /admin/users (admin)",
            "GET",
            "/admin/users",
            200,
            token=self.admin_token
        )

        # Petugas should get 403
        if self.petugas_token:
            self.run_test(
                "GET /admin/users (petugas should fail)",
                "GET",
                "/admin/users",
                403,
                token=self.petugas_token
            )

        # Create user
        test_username = f"testuser{datetime.now().strftime('%H%M%S')}"
        success, response = self.run_test(
            "POST /admin/users",
            "POST",
            "/admin/users",
            200,
            data={
                "username": test_username,
                "password": "test123",
                "nama": "Test User",
                "role": "petugas",
                "wa_number": "628999999999",
                "permissions": ["dashboard", "santri"]
            },
            token=self.admin_token
        )
        
        test_user_id = None
        if success and 'id' in response:
            test_user_id = response['id']
            self.log(f"✅ User created with ID: {test_user_id}", "PASS")

        # Update user
        if test_user_id:
            self.run_test(
                "PUT /admin/users/{id}",
                "PUT",
                f"/admin/users/{test_user_id}",
                200,
                data={"nama": "Updated Test User", "active": False},
                token=self.admin_token
            )

            # Delete user
            self.run_test(
                "DELETE /admin/users/{id}",
                "DELETE",
                f"/admin/users/{test_user_id}",
                200,
                token=self.admin_token
            )

        # Test cannot delete self
        # First get admin user ID
        success, me_response = self.run_test(
            "GET /auth/me (for admin ID)",
            "GET",
            "/auth/me",
            200,
            token=self.admin_token
        )
        if success and 'id' in me_response:
            admin_id = me_response['id']
            self.run_test(
                "DELETE /admin/users/{id} (cannot delete self)",
                "DELETE",
                f"/admin/users/{admin_id}",
                400,
                token=self.admin_token
            )

    def test_murobbi_routes(self):
        """Test murobbi CRUD."""
        self.log("\n========== TESTING MUROBBI ROUTES ==========", "INFO")
        
        # List murobbi (any authenticated user can read)
        self.run_test(
            "GET /admin/murobbi",
            "GET",
            "/admin/murobbi",
            200,
            token=self.admin_token
        )

        # Create murobbi (admin only)
        test_murobbi_name = f"Ustadz Test {datetime.now().strftime('%H%M%S')}"
        success, response = self.run_test(
            "POST /admin/murobbi",
            "POST",
            "/admin/murobbi",
            200,
            data={"nama": test_murobbi_name, "wa": "628777777777"},
            token=self.admin_token
        )
        
        test_murobbi_id = None
        if success and 'id' in response:
            test_murobbi_id = response['id']
            self.log(f"✅ Murobbi created with ID: {test_murobbi_id}", "PASS")

        # Update murobbi
        if test_murobbi_id:
            self.run_test(
                "PUT /admin/murobbi/{id}",
                "PUT",
                f"/admin/murobbi/{test_murobbi_id}",
                200,
                data={"nama": "Updated Ustadz Test"},
                token=self.admin_token
            )

            # Delete murobbi
            self.run_test(
                "DELETE /admin/murobbi/{id}",
                "DELETE",
                f"/admin/murobbi/{test_murobbi_id}",
                200,
                token=self.admin_token
            )

    def test_config_routes(self):
        """Test config GET/PUT."""
        self.log("\n========== TESTING CONFIG ROUTES ==========", "INFO")
        
        # Get config (any authenticated user)
        success, response = self.run_test(
            "GET /admin/config",
            "GET",
            "/admin/config",
            200,
            token=self.admin_token
        )
        
        if success:
            required_keys = ['admin_fees', 'starting_bet_no', 'starting_lemari_no', 'psb_admin_link']
            for key in required_keys:
                if key not in response:
                    self.log(f"⚠️  WARNING - Config missing key: {key}", "WARN")

        # Update config (admin only)
        self.run_test(
            "PUT /admin/config",
            "PUT",
            "/admin/config",
            200,
            data={
                "starting_bet_no": 1001,
                "starting_lemari_no": 1,
                "psb_admin_link": "https://psb.amtsilatipusat.com/admin"
            },
            token=self.admin_token
        )

    def test_permission_enforcement(self):
        """Test that petugas without akses-admin permission is blocked."""
        self.log("\n========== TESTING PERMISSION ENFORCEMENT ==========", "INFO")
        
        if not self.petugas_token:
            self.log("⚠️  SKIP - No petugas token available", "WARN")
            return

        # Petugas should NOT be able to access admin routes
        self.run_test(
            "GET /admin/users (petugas blocked)",
            "GET",
            "/admin/users",
            403,
            token=self.petugas_token
        )

        self.run_test(
            "POST /admin/users (petugas blocked)",
            "POST",
            "/admin/users",
            403,
            data={"username": "test", "password": "test", "nama": "Test", "role": "petugas"},
            token=self.petugas_token
        )

    def cleanup(self):
        """Clean up test data."""
        self.log("\n========== CLEANUP ==========", "INFO")
        
        if self.test_santri_id and self.admin_token:
            self.run_test(
                "DELETE /santri/{id} (cleanup)",
                "DELETE",
                f"/santri/{self.test_santri_id}",
                200,
                token=self.admin_token
            )

    def print_summary(self):
        """Print test summary."""
        self.log("\n" + "="*60, "INFO")
        self.log("TEST SUMMARY", "INFO")
        self.log("="*60, "INFO")
        self.log(f"Total tests: {self.tests_run}", "INFO")
        self.log(f"Passed: {self.tests_passed}", "INFO")
        self.log(f"Failed: {self.tests_run - self.tests_passed}", "INFO")
        self.log(f"Success rate: {(self.tests_passed/self.tests_run*100):.1f}%", "INFO")
        
        if self.failed_tests:
            self.log("\n❌ FAILED TESTS:", "FAIL")
            for ft in self.failed_tests:
                self.log(f"  - {ft.get('test', 'Unknown')}", "FAIL")
                if 'error' in ft:
                    self.log(f"    Error: {ft['error']}", "FAIL")
                else:
                    self.log(f"    Expected: {ft.get('expected')}, Got: {ft.get('actual')}", "FAIL")
        
        return 0 if self.tests_passed == self.tests_run else 1


def main():
    tester = APITester()
    
    try:
        # Run all tests
        if not tester.test_auth():
            tester.log("❌ CRITICAL: Auth tests failed, stopping", "FAIL")
            return 1
        
        tester.test_dashboard()
        
        if not tester.test_santri_crud():
            tester.log("⚠️  WARNING: Santri CRUD tests had issues", "WARN")
        
        tester.test_administrasi()
        tester.test_print_pdfs()
        tester.test_admin_routes()
        tester.test_murobbi_routes()
        tester.test_config_routes()
        tester.test_permission_enforcement()
        
        # Cleanup
        tester.cleanup()
        
    except KeyboardInterrupt:
        tester.log("\n⚠️  Tests interrupted by user", "WARN")
    except Exception as e:
        tester.log(f"\n❌ CRITICAL ERROR: {str(e)}", "FAIL")
        import traceback
        traceback.print_exc()
    
    return tester.print_summary()


if __name__ == "__main__":
    sys.exit(main())
