-- =====================================================================
-- Pondok Pesantren Amtsilati - Sistem Pendataan Santri
-- SQL Schema untuk phpMyAdmin (MySQL / MariaDB)
--
-- Catatan: Aplikasi production menggunakan MongoDB. Schema SQL ini
-- disediakan sebagai REFERENSI/CADANGAN bila kelak ingin migrasi atau
-- export data ke RDBMS. Tipe data sengaja dipilih agar mendukung UUID
-- (VARCHAR(36)) dan foto base64 (LONGTEXT).
--
-- Cara pakai di phpMyAdmin:
--   1) Buat database baru, misal `amtsilati_santri`
--   2) Pilih database tsb -> Tab Import
--   3) Upload file ini, klik Go
-- =====================================================================

SET FOREIGN_KEY_CHECKS = 0;
SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;

-- Drop tables (urutan terbalik karena foreign key)
DROP TABLE IF EXISTS `santri_print_status`;
DROP TABLE IF EXISTS `santri_perlengkapan`;
DROP TABLE IF EXISTS `santri_seragam`;
DROP TABLE IF EXISTS `santri_administrasi`;
DROP TABLE IF EXISTS `santri`;
DROP TABLE IF EXISTS `config_fees`;
DROP TABLE IF EXISTS `config`;
DROP TABLE IF EXISTS `murobbi`;
DROP TABLE IF EXISTS `users`;

-- =========================================
-- Tabel: users (admin & petugas)
-- =========================================
CREATE TABLE `users` (
  `id`              VARCHAR(36)  NOT NULL PRIMARY KEY COMMENT 'UUID',
  `username`        VARCHAR(64)  NOT NULL UNIQUE,
  `password_hash`   VARCHAR(255) NOT NULL COMMENT 'bcrypt hash',
  `nama`            VARCHAR(255) NOT NULL,
  `role`            ENUM('admin','petugas') NOT NULL DEFAULT 'petugas',
  `wa_number`       VARCHAR(20)  NOT NULL DEFAULT '',
  `profile_photo`   LONGTEXT     NULL COMMENT 'Data URL base64 (image/jpeg)',
  `permissions`     JSON         NULL COMMENT 'array of menu keys yang diizinkan',
  `active`          TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_users_role` (`role`),
  INDEX `idx_users_active` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================
-- Tabel: murobbi (daftar murobbi/pembimbing)
-- =========================================
CREATE TABLE `murobbi` (
  `id`         VARCHAR(36)  NOT NULL PRIMARY KEY,
  `nama`       VARCHAR(255) NOT NULL,
  `wa`         VARCHAR(20)  NOT NULL DEFAULT '',
  `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_murobbi_nama` (`nama`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================
-- Tabel: config (single row, id selalu 'config')
-- =========================================
CREATE TABLE `config` (
  `id`                  VARCHAR(36)  NOT NULL PRIMARY KEY,
  `starting_bet_no`     INT          NOT NULL DEFAULT 1001,
  `starting_lemari_no`  INT          NOT NULL DEFAULT 1,
  `psb_admin_link`      VARCHAR(500) NOT NULL DEFAULT 'https://psb.amtsilatipusat.com/admin',
  `updated_at`          DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                    ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================
-- Tabel: config_fees (daftar biaya administrasi template)
-- =========================================
CREATE TABLE `config_fees` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `config_id`  VARCHAR(36) NOT NULL,
  `fee_key`    VARCHAR(64) NOT NULL COMMENT 'contoh: seragam, stifin, perlengkapan_tidur, yanbua_alat_tulis',
  `name`       VARCHAR(255) NOT NULL,
  `price`      BIGINT NOT NULL DEFAULT 0 COMMENT 'IDR satuan rupiah',
  `sort_order` INT NOT NULL DEFAULT 0,
  UNIQUE KEY `uk_config_fee` (`config_id`, `fee_key`),
  CONSTRAINT `fk_fees_config` FOREIGN KEY (`config_id`) REFERENCES `config`(`id`)
      ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================
-- Tabel: santri (data utama santri)
-- =========================================
CREATE TABLE `santri` (
  `id`            VARCHAR(36)  NOT NULL PRIMARY KEY,
  `nis`           VARCHAR(64)  NOT NULL UNIQUE,
  `nama`          VARCHAR(255) NOT NULL,
  `alamat`        TEXT         NULL,
  `wali_nama`     VARCHAR(255) NOT NULL DEFAULT '',
  `wali_wa`       VARCHAR(20)  NOT NULL DEFAULT '',
  `foto`          LONGTEXT     NULL COMMENT 'Data URL base64',
  `murobbi_id`    VARCHAR(36)  NULL,
  `bet_no`        INT          NULL COMMENT 'Auto-render dari starting_bet_no + urutan',
  `lemari_no`     INT          NULL COMMENT 'Auto-render dari starting_lemari_no + urutan',
  `created_by`    VARCHAR(36)  NULL,
  `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                              ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_santri_nama` (`nama`),
  INDEX `idx_santri_murobbi` (`murobbi_id`),
  CONSTRAINT `fk_santri_murobbi` FOREIGN KEY (`murobbi_id`) REFERENCES `murobbi`(`id`)
      ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_santri_creator` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`)
      ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================
-- Tabel: santri_administrasi (riwayat biaya per santri)
-- =========================================
CREATE TABLE `santri_administrasi` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `santri_id`  VARCHAR(36)  NOT NULL,
  `fee_key`    VARCHAR(64)  NOT NULL,
  `name`       VARCHAR(255) NOT NULL,
  `price`      BIGINT       NOT NULL DEFAULT 0,
  `paid`       TINYINT(1)   NOT NULL DEFAULT 0,
  `paid_at`    DATETIME     NULL,
  UNIQUE KEY `uk_santri_fee` (`santri_id`, `fee_key`),
  INDEX `idx_admin_paid` (`paid`),
  CONSTRAINT `fk_admin_santri` FOREIGN KEY (`santri_id`) REFERENCES `santri`(`id`)
      ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================
-- Tabel: santri_seragam (1:1 dengan santri)
-- 3 warna seragam pesantren: biru, ungu, coklat (masing-masing + sarungnya)
-- =========================================
CREATE TABLE `santri_seragam` (
  `santri_id`              VARCHAR(36) NOT NULL PRIMARY KEY,
  `biru_ukuran_seragam`    VARCHAR(20) NOT NULL DEFAULT '',
  `biru_ukuran_sarung`     VARCHAR(20) NOT NULL DEFAULT '',
  `biru_ready`             TINYINT(1)  NOT NULL DEFAULT 0,
  `biru_delivered`         TINYINT(1)  NOT NULL DEFAULT 0,
  `ungu_ukuran_seragam`    VARCHAR(20) NOT NULL DEFAULT '',
  `ungu_ukuran_sarung`     VARCHAR(20) NOT NULL DEFAULT '',
  `ungu_ready`             TINYINT(1)  NOT NULL DEFAULT 0,
  `ungu_delivered`         TINYINT(1)  NOT NULL DEFAULT 0,
  `coklat_ukuran_seragam`  VARCHAR(20) NOT NULL DEFAULT '',
  `coklat_ukuran_sarung`   VARCHAR(20) NOT NULL DEFAULT '',
  `coklat_ready`           TINYINT(1)  NOT NULL DEFAULT 0,
  `coklat_delivered`       TINYINT(1)  NOT NULL DEFAULT 0,
  `all_delivered`          TINYINT(1)  NOT NULL DEFAULT 0 COMMENT 'cache: true bila 3 warna semua delivered',
  CONSTRAINT `fk_seragam_santri` FOREIGN KEY (`santri_id`) REFERENCES `santri`(`id`)
      ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================
-- Tabel: santri_perlengkapan (1:1 dengan santri)
-- =========================================
CREATE TABLE `santri_perlengkapan` (
  `santri_id`              VARCHAR(36) NOT NULL PRIMARY KEY,
  `kasur`                  TINYINT(1) NOT NULL DEFAULT 0,
  `bantal`                 TINYINT(1) NOT NULL DEFAULT 0,
  `guling`                 TINYINT(1) NOT NULL DEFAULT 0,
  `sarung_bantal_guling`   TINYINT(1) NOT NULL DEFAULT 0,
  `alat_tulis`             TINYINT(1) NOT NULL DEFAULT 0,
  `yanbua`                 TINYINT(1) NOT NULL DEFAULT 0,
  `all_delivered`          TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'cache: true bila 6 item semua true',
  CONSTRAINT `fk_perlengkapan_santri` FOREIGN KEY (`santri_id`) REFERENCES `santri`(`id`)
      ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================
-- Tabel: santri_print_status (1:1 dengan santri)
-- Tracking pencetakan bet nama, KTS, dan label lemari
-- =========================================
CREATE TABLE `santri_print_status` (
  `santri_id`              VARCHAR(36) NOT NULL PRIMARY KEY,
  `name_tag_printed`       TINYINT(1) NOT NULL DEFAULT 0,
  `name_tag_ready`         TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'sudah tertempel/siap',
  `kts_printed`            TINYINT(1) NOT NULL DEFAULT 0,
  `lemari_label_printed`   TINYINT(1) NOT NULL DEFAULT 0,
  CONSTRAINT `fk_print_santri` FOREIGN KEY (`santri_id`) REFERENCES `santri`(`id`)
      ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
-- SEED DATA (sesuai default aplikasi)
-- =====================================================================
-- Catatan: hash bcrypt di bawah ini untuk password 'admin123' dan
-- 'petugas123'. Bila Anda ingin generate sendiri, gunakan bcrypt cost=12.
-- Anda boleh kosongkan section ini bila tidak butuh seed.

-- Admin user (password: admin123)
INSERT INTO `users` (`id`, `username`, `password_hash`, `nama`, `role`, `wa_number`, `permissions`, `active`)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  'admin',
  '$2b$12$5Wt5ZqIxJ7QkjFqzG9C3GO5x2nQc9JpTnWvZqZxV7xJ5cKsZ8t.OG',
  'Administrator Pesantren',
  'admin',
  '628123456789',
  JSON_ARRAY('dashboard','santri','data-diri','administrasi','seragam','perlengkapan','name-tag','akses-admin'),
  1
);

-- Petugas user (password: petugas123)
INSERT INTO `users` (`id`, `username`, `password_hash`, `nama`, `role`, `wa_number`, `permissions`, `active`)
VALUES (
  '00000000-0000-0000-0000-000000000002',
  'petugas',
  '$2b$12$kQ7Jp9X3xVnLm2KqA4yZ.eW9TfH8s.6rNgVcXyZ1bO7uM4pEhTjQO',
  'Petugas Asrama',
  'petugas',
  '628987654321',
  JSON_ARRAY('dashboard','santri','data-diri','administrasi','seragam','perlengkapan','name-tag'),
  1
);

-- Config default
INSERT INTO `config` (`id`, `starting_bet_no`, `starting_lemari_no`, `psb_admin_link`)
VALUES ('config', 1001, 1, 'https://psb.amtsilatipusat.com/admin');

-- 4 biaya default
INSERT INTO `config_fees` (`config_id`, `fee_key`, `name`, `price`, `sort_order`) VALUES
  ('config', 'seragam',             'Seragam',                 800000, 1),
  ('config', 'stifin',              'Tes STIFIn',              750000, 2),
  ('config', 'perlengkapan_tidur',  'Perlengkapan Tidur',      650000, 3),
  ('config', 'yanbua_alat_tulis',   'Yanbua & Alat Tulis',      75000, 4);

-- 2 murobbi contoh
INSERT INTO `murobbi` (`id`, `nama`, `wa`) VALUES
  ('00000000-0000-0000-0000-000000000010', 'Ustadz Ahmad',  '628111111111'),
  ('00000000-0000-0000-0000-000000000011', 'Ustadz Fauzi',  '628222222222');

-- =====================================================================
-- VIEWS (Opsional) - bantu reporting via phpMyAdmin
-- =====================================================================

-- View: agregat tagihan per santri
CREATE OR REPLACE VIEW `v_santri_admin_summary` AS
SELECT
  s.id           AS santri_id,
  s.nis,
  s.nama,
  COUNT(a.id)                                     AS total_items,
  SUM(a.price)                                    AS total_tagihan,
  SUM(CASE WHEN a.paid = 1 THEN a.price ELSE 0 END) AS total_dibayar,
  SUM(CASE WHEN a.paid = 0 THEN a.price ELSE 0 END) AS sisa,
  SUM(CASE WHEN a.paid = 1 THEN 1 ELSE 0 END)     AS items_lunas
FROM `santri` s
LEFT JOIN `santri_administrasi` a ON a.santri_id = s.id
GROUP BY s.id, s.nis, s.nama;

-- View: dashboard counter
CREATE OR REPLACE VIEW `v_dashboard_kpi` AS
SELECT
  (SELECT COUNT(*) FROM `santri`)                                       AS santri_count,
  (SELECT COALESCE(SUM(price),0) FROM `santri_administrasi`)            AS total_uang,
  (SELECT COALESCE(SUM(price),0) FROM `santri_administrasi` WHERE paid=1) AS paid_uang,
  (SELECT COUNT(*) FROM `santri_seragam`      WHERE all_delivered=1)    AS seragam_lengkap,
  (SELECT COUNT(*) FROM `santri_perlengkapan` WHERE all_delivered=1)    AS perlengkapan_lengkap;

-- =====================================================================
-- SELESAI - schema siap dipakai
-- =====================================================================
