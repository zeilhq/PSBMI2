# Pondok Pesantren Amtsilati - API Documentation

> Sistem pendataan santri pesantren. Semua endpoint berada di bawah prefix `/api` dan (kecuali login) wajib mengirimkan header `Authorization: Bearer <token>`.

- Base URL contoh: `https://santri-admin-hub.preview.emergentagent.com/api`
- Format: JSON
- Auth: JWT Bearer Token (HS256, exp 7 hari)
- Database: MongoDB (NoSQL). Skema SQL ekuivalen ada di `docs/schema.sql`

---

## Daftar Isi

1. [Authentication](#1-authentication)
2. [Dashboard](#2-dashboard)
3. [Santri](#3-santri)
4. [Administrasi (PDF Kwitansi)](#4-administrasi-pdf-kwitansi)
5. [Print PDF Name Tag & KTS](#5-print-pdf-name-tag--kts)
6. [Admin: Users](#6-admin-users)
7. [Admin: Murobbi](#7-admin-murobbi)
8. [Admin: Config](#8-admin-config)
9. [Codes Error](#9-codes-error)
10. [Permission Keys](#10-permission-keys)

---

## Autentikasi & Cara Pakai

1. Login terlebih dahulu (`POST /api/auth/login`) untuk mendapatkan `access_token`.
2. Sertakan token di setiap request berikutnya:
   ```
   Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
   ```
3. Token kadaluarsa dalam **7 hari**. Setelah kadaluarsa akan dapat status 401 — silakan login ulang.

Default user (untuk testing):

| Username | Password | Role |
|----------|----------|------|
| `admin` | `admin123` | admin (akses semua) |
| `petugas` | `petugas123` | petugas (tanpa Akses Admin) |

---

## 1. Authentication

### POST `/api/auth/login`

Login dengan username/password.

**Request Body**
```json
{
  "username": "admin",
  "password": "admin123"
}
```

**Response 200**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIs...",
  "token_type": "bearer",
  "user": {
    "id": "e0af9327-...",
    "username": "admin",
    "nama": "Administrator Pesantren",
    "role": "admin",
    "wa_number": "628123456789",
    "profile_photo": "",
    "permissions": ["dashboard","santri","data-diri","administrasi","seragam","perlengkapan","name-tag","akses-admin"],
    "active": true,
    "created_at": "2026-06-01T07:10:10.504433+00:00"
  }
}
```

**Response 401**
```json
{ "detail": "Username atau password salah" }
```

---

### GET `/api/auth/me`

Return data user yang sedang login (verifikasi token).

**Headers:** `Authorization: Bearer <token>`

**Response 200** — sama dengan field `user` di login.

---

## 2. Dashboard

### GET `/api/dashboard`

Mengambil ringkasan KPI dan daftar petugas.

**Permission:** `dashboard`

**Response 200**
```json
{
  "santri_count": 42,
  "total_uang": 95550000,
  "paid_uang": 38220000,
  "remaining_uang": 57330000,
  "seragam_lengkap": 12,
  "perlengkapan_lengkap": 8,
  "petugas": [
    {
      "id": "...",
      "username": "admin",
      "nama": "Administrator Pesantren",
      "role": "admin",
      "wa_number": "628123456789",
      "profile_photo": ""
    }
  ],
  "psb_admin_link": "https://psb.amtsilatipusat.com/admin"
}
```

---

## 3. Santri

### GET `/api/santri`

List seluruh santri. `bet_no` dan `lemari_no` di-render berdasarkan urutan dan `starting_bet_no`/`starting_lemari_no` dari config.

**Permission:** `santri`

**Response 200** (array)
```json
[
  {
    "id": "f941...",
    "nis": "2025001",
    "nama": "Ahmad Fulan",
    "alamat": "Jepara",
    "wali_nama": "H. Yusuf",
    "wali_wa": "628123",
    "foto": "data:image/jpeg;base64,...",
    "murobbi_id": "...",
    "bet_no": 1001,
    "lemari_no": 1,
    "administrasi": [
      { "key": "seragam", "name": "Seragam", "price": 800000, "paid": false, "paid_at": null }
    ],
    "seragam": {
      "biru":   { "ukuran_seragam": "M", "ukuran_sarung": "Standar", "ready": true, "delivered": false },
      "ungu":   { "ukuran_seragam": "",  "ukuran_sarung": "",         "ready": false, "delivered": false },
      "coklat": { "ukuran_seragam": "",  "ukuran_sarung": "",         "ready": false, "delivered": false },
      "all_delivered": false
    },
    "perlengkapan": {
      "kasur": false, "bantal": false, "guling": false,
      "sarung_bantal_guling": false, "alat_tulis": false, "yanbua": false,
      "all_delivered": false
    },
    "print_status": {
      "name_tag_printed": false, "name_tag_ready": false,
      "kts_printed": false, "lemari_label_printed": false
    },
    "created_at": "2026-06-01T...",
    "updated_at": "2026-06-01T..."
  }
]
```

---

### POST `/api/santri`

Tambah santri baru. Otomatis seed `administrasi` dari config, set default seragam/perlengkapan/print_status, dan assign `bet_no` + `lemari_no`.

**Permission:** `data-diri`

**Request Body**
```json
{
  "nis": "2025001",
  "nama": "Ahmad Fulan",
  "alamat": "Jepara",
  "wali_nama": "H. Yusuf",
  "wali_wa": "628123456789",
  "foto": "data:image/jpeg;base64,...",
  "murobbi_id": "uuid-of-murobbi"
}
```

**Response 201/200** — santri lengkap (sama format dengan list).

**Response 400** — bila `nis` sudah dipakai: `{"detail":"NIS sudah terdaftar"}`.

---

### GET `/api/santri/{id}`

Detail satu santri.

**Permission:** `santri`

---

### PUT `/api/santri/{id}`

Update santri. Bisa partial. Field yang dapat diupdate:
- `nis`, `nama`, `alamat`, `wali_nama`, `wali_wa`, `foto`, `murobbi_id`
- `seragam` (object 3 warna). `all_delivered` akan auto-dihitung.
- `perlengkapan` (object). `all_delivered` akan auto-dihitung.
- `administrasi` (array dengan field `paid`/`paid_at`).
- `print_status` (object).

**Request body (partial seragam contoh):**
```json
{
  "seragam": {
    "biru":   { "ukuran_seragam": "L", "ukuran_sarung": "Standar", "ready": true, "delivered": true },
    "ungu":   { "ukuran_seragam": "L", "ukuran_sarung": "Standar", "ready": true, "delivered": true },
    "coklat": { "ukuran_seragam": "L", "ukuran_sarung": "Standar", "ready": true, "delivered": true }
  }
}
```

---

### DELETE `/api/santri/{id}`

Hapus santri.

**Permission:** `data-diri`

---

### POST `/api/santri/{santri_id}/administrasi/toggle`

Toggle status pembayaran untuk satu item biaya.

**Permission:** `administrasi`

**Request Body**
```json
{ "key": "seragam", "paid": true }
```

**Response 200**
```json
{
  "ok": true,
  "administrasi": [
    { "key": "seragam", "name": "Seragam", "price": 800000, "paid": true, "paid_at": "2026-06-01T07:30:00+00:00" }
  ]
}
```

---

## 4. Administrasi (PDF Kwitansi)

### GET `/api/santri/{santri_id}/kwitansi.pdf`

Men-generate file PDF kwitansi pembayaran untuk satu santri (format A5).

- **Content-Type:** `application/pdf`
- Header `Content-Disposition: inline; filename="kwitansi-<NIS>.pdf"`
- **Permission:** `administrasi`

Cara konsumsi di frontend:
```js
const resp = await fetch(`${API_BASE}/santri/${id}/kwitansi.pdf`, {
  headers: { Authorization: `Bearer ${token}` }
});
const blob = await resp.blob();
window.open(URL.createObjectURL(blob), '_blank');
```

---

## 5. Print PDF Name Tag & KTS

### GET `/api/santri/print/name-tag.pdf`
Generate PDF bet nama (grid A4) semua santri.
**Permission:** `name-tag`

### GET `/api/santri/print/kts.pdf`
Generate PDF preview KTS semua santri (grid A4, 2 per baris).
**Permission:** `name-tag`

---

## 6. Admin: Users

Semua endpoint di bawah `/api/admin/users` membutuhkan role **admin**. Petugas akan dapat 403.

### GET `/api/admin/users`
List semua user.

### POST `/api/admin/users`
Tambah user.
```json
{
  "username": "petugas2",
  "password": "P@sswordKuat",
  "nama": "Petugas Asrama 2",
  "role": "petugas",
  "wa_number": "628999000111",
  "profile_photo": "",
  "permissions": ["dashboard","santri","seragam"]
}
```

### PUT `/api/admin/users/{user_id}`
Update user (semua field optional). Kosongkan `password` bila tidak ingin diubah.
```json
{
  "nama": "Nama Baru",
  "permissions": ["dashboard","santri","data-diri"],
  "active": true,
  "wa_number": "628..."
}
```

### DELETE `/api/admin/users/{user_id}`
Hapus user. Tidak boleh menghapus diri sendiri (400).

---

## 7. Admin: Murobbi

### GET `/api/admin/murobbi`
List murobbi. **Boleh** untuk semua user terotentikasi (dipakai juga oleh form Data Diri & Perlengkapan).

### POST `/api/admin/murobbi`  (admin only)
```json
{ "nama": "Ustadz Hasan", "wa": "628300000000" }
```

### PUT `/api/admin/murobbi/{mid}`  (admin only)
```json
{ "wa": "628300000001" }
```

### DELETE `/api/admin/murobbi/{mid}`  (admin only)

---

## 8. Admin: Config

### GET `/api/admin/config`
Return config tunggal. **Boleh** untuk semua user terotentikasi.
```json
{
  "id": "config",
  "admin_fees": [
    { "key": "seragam", "name": "Seragam", "price": 800000 },
    { "key": "stifin",  "name": "Tes STIFIn", "price": 750000 }
  ],
  "starting_bet_no": 1001,
  "starting_lemari_no": 1,
  "psb_admin_link": "https://psb.amtsilatipusat.com/admin",
  "updated_at": "2026-06-01T07:00:00+00:00"
}
```

### PUT `/api/admin/config`  (admin only)
Update config. Semua field optional.
```json
{
  "admin_fees": [
    { "key": "seragam",            "name": "Seragam",             "price": 850000 },
    { "key": "stifin",             "name": "Tes STIFIn",          "price": 750000 },
    { "key": "perlengkapan_tidur", "name": "Perlengkapan Tidur",  "price": 650000 },
    { "key": "yanbua_alat_tulis",  "name": "Yanbua & Alat Tulis",  "price":  75000 }
  ],
  "starting_bet_no": 2001,
  "starting_lemari_no": 1,
  "psb_admin_link": "https://psb.amtsilatipusat.com/admin"
}
```

> Catatan: perubahan `admin_fees` hanya berdampak untuk santri **baru** yang dibuat setelahnya. Untuk santri lama harus diubah manual via PUT /api/santri/{id}.

### GET `/api/admin/menu-keys`
List semua menu key valid:
```json
{ "keys": ["dashboard","santri","data-diri","administrasi","seragam","perlengkapan","name-tag","akses-admin"] }
```

---

## 9. Codes Error

| HTTP | Arti |
|------|------|
| 200 | OK |
| 400 | Validasi gagal (mis. NIS duplikat, password kosong) |
| 401 | Token tidak valid/kadaluarsa atau kredensial salah |
| 403 | Akun dinonaktifkan, atau menu tidak diizinkan |
| 404 | Sumber tidak ditemukan |
| 422 | Payload tidak sesuai schema (Pydantic validation) |
| 500 | Server error |

---

## 10. Permission Keys

Digunakan di field `permissions[]` user (array dari string berikut):

| Key | Menu |
|-----|------|
| `dashboard` | Dashboard Utama |
| `santri` | Daftar Santri |
| `data-diri` | Data Diri (create/edit/delete) |
| `administrasi` | Administrasi Asrama + cetak kwitansi |
| `seragam` | Seragam |
| `perlengkapan` | Perlengkapan Asrama |
| `name-tag` | Name Tag / KTS + cetak PDF |
| `akses-admin` | Akses Admin (hanya role admin yang efektif memilikinya) |

Role `admin` melewati pengecekan permission (semua menu otomatis terbuka).

---

## Swagger / OpenAPI Otomatis

FastAPI menyediakan dokumentasi interaktif di:

- Swagger UI: `<base>/api/docs`
- ReDoc: `<base>/api/redoc`
- OpenAPI JSON: `<base>/api/openapi.json`

Contoh: `https://santri-admin-hub.preview.emergentagent.com/api/docs`
