{
  "design_system_name": "AM Tsilati Pesantren Ops UI (Mobile-first Admin)",
  "brand_attributes": [
    "tenang & terpercaya (administrasi pesantren)",
    "minimalis-estetik (tidak ramai, tapi tidak kaku)",
    "mobile-first untuk petugas lapangan",
    "jelas untuk non-tech staff (label kuat, feedback status tegas)",
    "Islamic-friendly (geometri halus, hijau-sage, tanpa ornamen berlebihan)"
  ],
  "visual_personality": {
    "style_fusion": [
      "Swiss-style grid + whitespace (keterbacaan)",
      "Bento cards (dashboard & santri)",
      "Soft glass accents (hanya untuk header/hero strip kecil, <20% viewport)",
      "Islamic geometric motif sebagai watermark/noise halus (bukan pattern ramai)"
    ],
    "do_not": [
      "Jangan pakai layout serba center.",
      "Jangan pakai gradient gelap/saturated (ungu/pink, biru-ungu, merah-pink).",
      "Jangan jadikan background gelap sebagai default.",
      "Jangan gunakan emoji sebagai ikon; gunakan lucide-react atau FontAwesome CDN."
    ]
  },
  "typography": {
    "google_fonts": {
      "heading": {
        "family": "Space Grotesk",
        "weights": [500, 600, 700],
        "usage": "Judul halaman, KPI angka, section headers"
      },
      "body": {
        "family": "Plus Jakarta Sans",
        "weights": [400, 500, 600],
        "usage": "Body, label form, tabel, helper text (Bahasa Indonesia)"
      }
    },
    "tailwind_font_tokens": {
      "font-sans": "'Plus Jakarta Sans', ui-sans-serif, system-ui",
      "font-display": "'Space Grotesk', ui-sans-serif, system-ui"
    },
    "type_scale": {
      "h1": "text-4xl sm:text-5xl lg:text-6xl font-display font-semibold tracking-tight",
      "h2": "text-base md:text-lg font-sans text-muted-foreground",
      "page_title": "text-xl sm:text-2xl font-display font-semibold",
      "section_title": "text-sm font-sans font-semibold tracking-wide text-foreground",
      "body": "text-sm sm:text-base font-sans",
      "caption": "text-xs font-sans text-muted-foreground"
    },
    "numbers": {
      "kpi": "tabular-nums tracking-tight",
      "nis": "font-mono text-xs sm:text-sm"
    }
  },
  "color_system": {
    "notes": [
      "Palet calm: sage/emerald + ocean + sand. Cocok pesantren, profesional.",
      "Gunakan warna status yang jelas untuk checklist & pembayaran.",
      "Gradients hanya untuk strip dekoratif (maks 20% viewport)."
    ],
    "semantic_tokens_hsl": {
      "background": "150 25% 98%",
      "foreground": "160 18% 12%",
      "card": "0 0% 100%",
      "card-foreground": "160 18% 12%",
      "popover": "0 0% 100%",
      "popover-foreground": "160 18% 12%",

      "primary": "158 55% 28%",
      "primary-foreground": "0 0% 98%",

      "secondary": "150 18% 94%",
      "secondary-foreground": "160 18% 12%",

      "muted": "150 18% 95%",
      "muted-foreground": "160 10% 40%",

      "accent": "195 55% 92%",
      "accent-foreground": "160 18% 12%",

      "border": "150 14% 88%",
      "input": "150 14% 88%",
      "ring": "158 55% 28%",

      "destructive": "0 72% 52%",
      "destructive-foreground": "0 0% 98%",

      "success": "152 55% 34%",
      "warning": "38 92% 50%",
      "info": "199 85% 45%",
      "pending": "28 85% 55%"
    },
    "hex_palette": {
      "sage_900": "#0F2A22",
      "sage_700": "#1F5A46",
      "sage_600": "#2B6F57",
      "sage_100": "#E7F1EC",
      "ocean_600": "#0E7490",
      "ocean_100": "#DDF2F7",
      "sand_100": "#F6F1E7",
      "ink": "#0B1220",
      "line": "#D7E2DC",
      "white": "#FFFFFF"
    },
    "allowed_gradients": {
      "hero_strip_only": [
        "linear-gradient(135deg, rgba(43,111,87,0.10), rgba(14,116,144,0.08), rgba(246,241,231,0.35))",
        "radial-gradient(600px circle at 20% 10%, rgba(14,116,144,0.10), transparent 55%)"
      ],
      "rules": [
        "Jangan gunakan gradient pada card konten / tabel / form.",
        "Jangan gunakan gradient pada elemen kecil (<100px).",
        "Jika area gradient >20% viewport: ganti solid background + noise halus."
      ]
    }
  },
  "design_tokens_css": {
    "instructions": "Main agent: update /app/frontend/src/index.css :root tokens sesuai semantic_tokens_hsl. Tambahkan token tambahan di bawah.",
    "css_variables_to_add": ":root {\n  --radius-lg: 0.9rem;\n  --radius-md: 0.75rem;\n  --radius-sm: 0.6rem;\n\n  --shadow-sm: 0 1px 2px rgba(15, 42, 34, 0.06);\n  --shadow-md: 0 10px 30px rgba(15, 42, 34, 0.10);\n  --shadow-ring: 0 0 0 4px rgba(43, 111, 87, 0.18);\n\n  --sidebar-width: 280px;\n  --sidebar-collapsed-width: 76px;\n\n  --ease-out: cubic-bezier(0.16, 1, 0.3, 1);\n  --ease-in: cubic-bezier(0.7, 0, 0.84, 0);\n}\n\n::selection { background: rgba(14,116,144,0.18); }\n"
  },
  "layout_and_spacing": {
    "grid": {
      "app_shell": "min-h-dvh grid grid-cols-1 lg:grid-cols-[var(--sidebar-width)_1fr]",
      "content_max_width": "max-w-6xl",
      "page_padding": "px-4 sm:px-6 lg:px-8 py-4 sm:py-6",
      "section_gap": "space-y-4 sm:space-y-6",
      "bento_grid": "grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 sm:gap-4"
    },
    "density": {
      "mobile": "Single column, sticky action bar untuk form panjang.",
      "desktop": "2-column forms (label kiri, input kanan) untuk settings; tabel full width."
    },
    "touch_targets": {
      "min_height": "min-h-11",
      "notes": "Semua tombol/row action minimal 44px tinggi untuk nyaman di HP."
    }
  },
  "navigation_shell": {
    "pattern": "Desktop: sidebar fixed + collapsible. Mobile: Drawer/Sheet dari kiri dengan overlay.",
    "components": {
      "desktop_sidebar": ["/app/frontend/src/components/ui/collapsible.jsx", "/app/frontend/src/components/ui/scroll-area.jsx", "/app/frontend/src/components/ui/button.jsx", "/app/frontend/src/components/ui/separator.jsx"],
      "mobile_drawer": ["/app/frontend/src/components/ui/sheet.jsx", "/app/frontend/src/components/ui/drawer.jsx"],
      "breadcrumbs": ["/app/frontend/src/components/ui/breadcrumb.jsx"],
      "tooltip": ["/app/frontend/src/components/ui/tooltip.jsx"]
    },
    "sidebar_structure": {
      "top": "Logo + nama app + tombol collapse",
      "middle": "8 menu items (ikon + label). Group: Operasional (Dashboard, Santri, Data Diri), Administrasi (Administrasi Asrama, Seragam, Perlengkapan, Name Tag/KTS), Sistem (Akses Admin)",
      "bottom": "User chip + tombol logout"
    },
    "collapsed_behavior": {
      "desktop": "Saat collapsed: hanya ikon, label muncul via Tooltip. Lebar 76px.",
      "mobile": "Tidak ada collapsed; gunakan drawer full height."
    },
    "data_testids": {
      "sidebar_toggle": "sidebar-collapse-toggle",
      "mobile_menu_button": "mobile-sidebar-open-button",
      "nav_item": "sidebar-nav-item-<route>"
    }
  },
  "page_blueprints": {
    "login": {
      "layout": "Split subtle: mobile full card; desktop 2-column (left brand panel kecil, right form).",
      "components": ["/app/frontend/src/components/ui/card.jsx", "/app/frontend/src/components/ui/input.jsx", "/app/frontend/src/components/ui/button.jsx", "/app/frontend/src/components/ui/label.jsx"],
      "details": [
        "Tambahkan watermark pattern geometri sangat halus di background (opacity 0.06).",
        "CTA: 'Masuk' primary; secondary: 'Lupa sandi' ghost."
      ],
      "data_testids": {
        "username": "login-username-input",
        "password": "login-password-input",
        "submit": "login-submit-button",
        "error": "login-error-text"
      }
    },
    "dashboard": {
      "top_row": "Bento KPI cards: Jumlah Santri, Total Uang Masuk, Seragam Terkonfirmasi, Tugas Pending.",
      "middle": "Petugas list (Avatar + nama + role) + tombol WA; Quick actions (PSB admin link, tambah santri, cetak kwitansi).",
      "bottom": "Tabel ringkas: Santri terbaru / pembayaran terbaru.",
      "components": [
        "/app/frontend/src/components/ui/card.jsx",
        "/app/frontend/src/components/ui/badge.jsx",
        "/app/frontend/src/components/ui/table.jsx",
        "/app/frontend/src/components/ui/button.jsx",
        "/app/frontend/src/components/ui/avatar.jsx",
        "/app/frontend/src/components/ui/sonner.jsx"
      ],
      "kpi_card_style": "Card putih, border halus, shadow-sm. Angka besar font-display.",
      "quick_actions": {
        "wa_button": "Gunakan variant 'secondary' + ikon WhatsApp (FontAwesome) + hover ring.",
        "psb_link": "Button outline dengan external-link icon."
      },
      "data_testids": {
        "kpi_santri": "dashboard-kpi-total-santri",
        "kpi_uang": "dashboard-kpi-total-uang",
        "petugas_list": "dashboard-petugas-list",
        "psb_admin_link": "dashboard-psb-admin-link"
      }
    },
    "santri_list": {
      "layout": "Search + filter sticky top (mobile). Grid cards 2 kolom di mobile landscape, 3-4 kolom desktop.",
      "card": "Card dengan foto (AspectRatio), NIS chip (mono), nama tebal, alamat 2 baris clamp.",
      "interaction": "Tap card -> Dialog modal detail (foto besar + tabs: Profil, Administrasi, Seragam, Perlengkapan).",
      "components": [
        "/app/frontend/src/components/ui/input.jsx",
        "/app/frontend/src/components/ui/card.jsx",
        "/app/frontend/src/components/ui/aspect-ratio.jsx",
        "/app/frontend/src/components/ui/dialog.jsx",
        "/app/frontend/src/components/ui/tabs.jsx",
        "/app/frontend/src/components/ui/badge.jsx",
        "/app/frontend/src/components/ui/skeleton.jsx"
      ],
      "data_testids": {
        "search": "santri-search-input",
        "card": "santri-card-<nis>",
        "open_modal": "santri-open-detail-<nis>",
        "modal": "santri-detail-modal"
      }
    },
    "data_diri_form": {
      "pattern": "Form dibagi section Card: Identitas, Alamat, Wali, Foto. Gunakan Form shadcn (react-hook-form).",
      "photo_upload": "Gunakan dropzone area + preview Avatar. Kompres sebelum upload.",
      "components": [
        "/app/frontend/src/components/ui/form.jsx",
        "/app/frontend/src/components/ui/input.jsx",
        "/app/frontend/src/components/ui/textarea.jsx",
        "/app/frontend/src/components/ui/select.jsx",
        "/app/frontend/src/components/ui/card.jsx",
        "/app/frontend/src/components/ui/avatar.jsx",
        "/app/frontend/src/components/ui/button.jsx"
      ],
      "sticky_actions": "Mobile: sticky bottom bar (Simpan, Simpan & Lanjut). Desktop: actions di header kanan.",
      "data_testids": {
        "save": "data-diri-save-button",
        "photo": "data-diri-photo-input"
      }
    },
    "administrasi_asrama": {
      "layout": "Per santri: 4 biaya sebagai checklist cards + total + tombol 'Cetak PDF Kwitansi'.",
      "fees": [
        {"name": "Seragam", "amount": 800000},
        {"name": "Tes STIFIn", "amount": 750000},
        {"name": "Perlengkapan Tidur", "amount": 650000},
        {"name": "Yanbua/Alat Tulis", "amount": 75000}
      ],
      "components": [
        "/app/frontend/src/components/ui/checkbox.jsx",
        "/app/frontend/src/components/ui/progress.jsx",
        "/app/frontend/src/components/ui/card.jsx",
        "/app/frontend/src/components/ui/button.jsx",
        "/app/frontend/src/components/ui/badge.jsx",
        "/app/frontend/src/components/ui/alert-dialog.jsx"
      ],
      "status_ui": "Paid -> badge success; Unpaid -> badge outline + muted; Partial -> badge pending.",
      "pdf": {
        "library": "jspdf + jspdf-autotable",
        "install": "npm i jspdf jspdf-autotable",
        "button": "Primary kecil (min-w-[140px]) hanya di area actions.",
        "data_testids": {
          "print": "administrasi-print-kwitansi-button",
          "fee_checkbox": "administrasi-fee-checkbox-<feeKey>"
        }
      }
    },
    "seragam": {
      "layout": "Checklist per item: biru, ungu, coklat, sarung + ukuran. Tombol WA konfirmasi.",
      "components": [
        "/app/frontend/src/components/ui/checkbox.jsx",
        "/app/frontend/src/components/ui/select.jsx",
        "/app/frontend/src/components/ui/button.jsx",
        "/app/frontend/src/components/ui/card.jsx",
        "/app/frontend/src/components/ui/badge.jsx"
      ],
      "wa": {
        "pattern": "Button secondary dengan ikon WA; klik membuka wa.me/?text=...",
        "data_testids": "seragam-wa-confirm-button"
      }
    },
    "perlengkapan_asrama": {
      "layout": "Checklist grid: lemari, kasur, bantal, guling, alat tulis + assignment murobbi (Select).",
      "components": [
        "/app/frontend/src/components/ui/checkbox.jsx",
        "/app/frontend/src/components/ui/select.jsx",
        "/app/frontend/src/components/ui/card.jsx",
        "/app/frontend/src/components/ui/table.jsx"
      ],
      "data_testids": {
        "murobbi_select": "perlengkapan-murobbi-select",
        "item_checkbox": "perlengkapan-item-checkbox-<itemKey>"
      }
    },
    "name_tag_kts": {
      "layout": "Preview card (KTS) + form setting (nomor awal, nama, kelas) + tombol print.",
      "components": [
        "/app/frontend/src/components/ui/card.jsx",
        "/app/frontend/src/components/ui/input.jsx",
        "/app/frontend/src/components/ui/button.jsx",
        "/app/frontend/src/components/ui/separator.jsx"
      ],
      "render": "Gunakan canvas (html-to-image) untuk render bet number & KTS preview.",
      "library": {
        "install": "npm i html-to-image",
        "notes": "Fallback: render SVG template untuk print."
      },
      "data_testids": {
        "preview": "kts-preview",
        "print": "kts-print-button"
      }
    },
    "akses_admin": {
      "layout": "Tabs: Users, Hak Akses, Biaya, Murobbi, Konfigurasi Nomor. Setiap tab: table + side panel form.",
      "components": [
        "/app/frontend/src/components/ui/tabs.jsx",
        "/app/frontend/src/components/ui/table.jsx",
        "/app/frontend/src/components/ui/dialog.jsx",
        "/app/frontend/src/components/ui/switch.jsx",
        "/app/frontend/src/components/ui/input.jsx",
        "/app/frontend/src/components/ui/button.jsx",
        "/app/frontend/src/components/ui/alert-dialog.jsx"
      ],
      "permission_ui": "Gunakan Switch per menu item + badge role. Pastikan ada 'Simpan Perubahan' sticky.",
      "data_testids": {
        "tab_users": "admin-tab-users",
        "tab_permissions": "admin-tab-permissions",
        "save": "admin-save-settings-button"
      }
    }
  },
  "component_styling": {
    "buttons": {
      "variants": {
        "primary": "bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] hover:bg-[hsl(var(--primary))]/90 focus-visible:ring-2 focus-visible:ring-[hsl(var(--ring))] focus-visible:ring-offset-2",
        "secondary": "bg-[hsl(var(--secondary))] text-[hsl(var(--secondary-foreground))] hover:bg-[hsl(var(--secondary))]/80",
        "outline": "border border-[hsl(var(--border))] bg-white hover:bg-[hsl(var(--muted))]",
        "ghost": "hover:bg-[hsl(var(--muted))]"
      },
      "shape": "rounded-[var(--radius-md)]",
      "motion": "transition-colors duration-200",
      "press": "active:scale-[0.99]"
    },
    "cards": {
      "base": "rounded-[var(--radius-lg)] border border-[hsl(var(--border))] bg-white shadow-[var(--shadow-sm)]",
      "hover": "hover:shadow-[var(--shadow-md)] transition-shadow duration-200",
      "kpi_accent": "Tambahkan strip kecil kiri (w-1) warna primary/ocean untuk diferensiasi, bukan gradient besar."
    },
    "forms": {
      "inputs": "Gunakan Input shadcn; tambah focus ring jelas. Helper text kecil.",
      "sections": "Pisahkan dengan Card + Separator; jangan form panjang tanpa section.",
      "validation": "Error text merah + icon kecil; jangan hanya warna (tambahkan teks)."
    },
    "tables": {
      "pattern": "Mobile: gunakan Card rows (stacked) atau horizontal ScrollArea. Desktop: Table shadcn.",
      "row_hover": "hover:bg-[hsl(var(--muted))]/60",
      "sticky_header": "Jika tabel panjang: header sticky + shadow tipis."
    },
    "modals": {
      "dialog": "Dialog shadcn dengan max-w-lg sm:max-w-2xl; konten scrollable.",
      "mobile": "Untuk detail cepat gunakan Drawer (bottom sheet) agar nyaman di HP."
    },
    "badges_status": {
      "paid": "Badge bg-[hsl(var(--success))]/10 text-[hsl(var(--success))] border-[hsl(var(--success))]/20",
      "unpaid": "Badge bg-transparent text-[hsl(var(--muted-foreground))] border-[hsl(var(--border))]",
      "pending": "Badge bg-[hsl(var(--pending))]/12 text-[hsl(var(--pending))] border-[hsl(var(--pending))]/25",
      "info": "Badge bg-[hsl(var(--info))]/10 text-[hsl(var(--info))] border-[hsl(var(--info))]/20"
    }
  },
  "micro_interactions_motion": {
    "principles": [
      "Gunakan motion untuk feedback, bukan dekorasi.",
      "Durasi pendek: 160–220ms untuk hover/focus.",
      "Hindari transition: all."
    ],
    "recommended_library": {
      "name": "framer-motion",
      "install": "npm i framer-motion",
      "usage": [
        "Sidebar collapse animasi width",
        "Card entrance (fade + y 6px) saat load",
        "Checklist completion micro-celebration (scale 1.02 lalu balik)"
      ]
    },
    "tailwind_motion_snippets": {
      "card_enter": "motion-safe:animate-in motion-safe:fade-in motion-safe:slide-in-from-bottom-2",
      "drawer": "data-[state=open]:animate-in data-[state=closed]:animate-out",
      "focus_ring": "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--ring))] focus-visible:ring-offset-2"
    },
    "scroll": {
      "sticky_header": "Header halaman sticky top-0 dengan backdrop-blur (opacity rendah) hanya untuk bar kecil.",
      "notes": "Backdrop blur hanya pada header strip kecil (<=72px tinggi)."
    }
  },
  "status_indicators": {
    "checklist": {
      "states": [
        {"key": "done", "label": "Selesai", "ui": "Checkbox checked + badge success"},
        {"key": "pending", "label": "Belum", "ui": "Checkbox unchecked + badge unpaid"},
        {"key": "needs_confirm", "label": "Butuh Konfirmasi", "ui": "badge pending + tombol WA"}
      ],
      "progress": "Gunakan Progress bar untuk ringkasan per-santri (0–100%)."
    },
    "money": {
      "format": "IDR (Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }))",
      "emphasis": "Angka uang gunakan font-display + tabular-nums."
    }
  },
  "images_and_assets": {
    "image_urls": [
      {
        "category": "login_background_optional",
        "description": "Foto konteks sekolah/pesantren (gunakan blur + overlay putih 70% agar tidak mengganggu).",
        "urls": [
          "https://images.pexels.com/photos/16056111/pexels-photo-16056111.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
          "https://images.pexels.com/photos/8304925/pexels-photo-8304925.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
        ]
      },
      {
        "category": "subtle_pattern_reference",
        "description": "Referensi tekstur/pattern halus untuk watermark (gunakan opacity 0.04–0.08).",
        "urls": [
          "https://images.unsplash.com/photo-1711836830357-daff8bc5b560?crop=entropy&cs=srgb&fm=jpg&ixlib=rb-4.1.0&q=85",
          "https://images.pexels.com/photos/31624790/pexels-photo-31624790.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
        ]
      }
    ],
    "icons": {
      "library": "lucide-react",
      "notes": "Untuk WhatsApp gunakan FontAwesome icon (faWhatsapp) atau SVG inline."
    }
  },
  "libraries_and_integrations": {
    "pdf_generation": {
      "library": "jspdf + jspdf-autotable",
      "install": "npm i jspdf jspdf-autotable",
      "usage_notes": "Generate kwitansi dari data santri + checklist biaya. Pastikan tombol print punya loading state + toast sukses/gagal."
    },
    "photo_compression": {
      "library": "browser-image-compression",
      "install": "npm i browser-image-compression",
      "usage_notes": "Compress ke max 1280px, target 200–400KB. Tampilkan progress."
    },
    "charts_optional": {
      "library": "recharts",
      "install": "npm i recharts",
      "use_cases": "Dashboard: trend pembayaran per minggu/bulan (jika ada data). Jangan pakai chart jika datanya minim."
    }
  },
  "component_path": {
    "shadcn_ui_primary": "/app/frontend/src/components/ui/",
    "use_components": [
      "button.jsx",
      "card.jsx",
      "badge.jsx",
      "input.jsx",
      "textarea.jsx",
      "select.jsx",
      "checkbox.jsx",
      "table.jsx",
      "dialog.jsx",
      "drawer.jsx",
      "sheet.jsx",
      "tabs.jsx",
      "form.jsx",
      "scroll-area.jsx",
      "separator.jsx",
      "avatar.jsx",
      "sonner.jsx",
      "skeleton.jsx",
      "tooltip.jsx",
      "breadcrumb.jsx",
      "collapsible.jsx",
      "progress.jsx",
      "alert-dialog.jsx"
    ]
  },
  "instructions_to_main_agent": [
    "Hapus styling default CRA di App.css yang membuat header center/dark. Jangan gunakan .App { text-align:center }.",
    "Update token warna di /app/frontend/src/index.css :root sesuai semantic_tokens_hsl (tema light).",
    "Tambahkan font Google (Space Grotesk + Plus Jakarta Sans) via index.html atau CSS import; set Tailwind fontFamily jika ada config.",
    "Bangun DashboardShell: desktop sidebar + mobile Sheet drawer. Sidebar collapsible (width anim) + tooltip saat collapsed.",
    "Semua tombol/link/input/checkbox/select/tab harus punya data-testid (kebab-case).",
    "Santri list: gunakan Card grid + Dialog/Drawer detail. Pastikan search input sticky di mobile.",
    "Checklist pages: gunakan Badge status + Progress ringkasan + toast (sonner) untuk aksi simpan/print.",
    "PDF kwitansi: implement jspdf-autotable; pastikan layout kwitansi rapi (logo kecil, tabel biaya, total, tanda tangan).",
    "Photo upload: compress sebelum upload; tampilkan preview Avatar + skeleton saat loading.",
    "Jangan gunakan gradient besar; jika butuh aksen, gunakan strip kecil atau background overlay tipis di header saja."
  ],
  "accessibility": {
    "requirements": [
      "Kontras teks minimal WCAG AA (terutama badge & tombol).",
      "Focus state wajib terlihat (ring).",
      "Gunakan aria-label untuk ikon-only buttons.",
      "Modal/Drawer harus trap focus (shadcn sudah).",
      "Tabel: header jelas, row actions punya label."
    ]
  },
  "appendix_general_ui_ux_design_guidelines": "<General UI UX Design Guidelines>\n    - You must **not** apply universal transition. Eg: `transition: all`. This results in breaking transforms. Always add transitions for specific interactive elements like button, input excluding transforms\n    - You must **not** center align the app container, ie do not add `.App { text-align: center; }` in the css file. This disrupts the human natural reading flow of text\n   - NEVER: use AI assistant Emoji characters like`🤖🧠💭💡🔮🎯📚🎭🎬🎪🎉🎊🎁🎀🎂🍰🎈🎨🎰💰💵💳🏦💎🪙💸🤑📊📈📉💹🔢🏆🥇 etc for icons. Always use **FontAwesome cdn** or **lucid-react** library already installed in the package.json\n\n **GRADIENT RESTRICTION RULE**\nNEVER use dark/saturated gradient combos (e.g., purple/pink) on any UI element.  Prohibited gradients: blue-500 to purple 600, purple 500 to pink-500, green-500 to blue-500, red to pink etc\nNEVER use dark gradients for logo, testimonial, footer etc\nNEVER let gradients cover more than 20% of the viewport.\nNEVER apply gradients to text-heavy content or reading areas.\nNEVER use gradients on small UI elements (<100px width).\nNEVER stack multiple gradient layers in the same viewport.\n\n**ENFORCEMENT RULE:**\n    • Id gradient area exceeds 20% of viewport OR affects readability, **THEN** use solid colors\n\n**How and where to use:**\n   • Section backgrounds (not content backgrounds)\n   • Hero section header content. Eg: dark to light to dark color\n   • Decorative overlays and accent elements only\n   • Hero section with 2-3 mild color\n   • Gradients creation can be done for any angle say horizontal, vertical or diagonal\n\n- For AI chat, voice application, **do not use purple color. Use color like light green, ocean blue, peach orange etc**\n\n</Font Guidelines>\n\n- Every interaction needs micro-animations - hover states, transitions, parallax effects, and entrance animations. Static = dead. \n   \n- Use 2-3x more spacing than feels comfortable. Cramped designs look cheap.\n\n- Subtle grain textures, noise overlays, custom cursors, selection states, and loading animations: separates good from extraordinary.\n   \n- Before generating UI, infer the visual style from the problem statement (palette, contrast, mood, motion) and immediately instantiate it by setting global design tokens (primary, secondary/accent, background, foreground, ring, state colors), rather than relying on any library defaults. Don't make the background dark as a default step, always understand problem first and define colors accordingly\n    Eg: - if it implies playful/energetic, choose a colorful scheme\n           - if it implies monochrome/minimal, choose a black–white/neutral scheme\n\n**Component Reuse:**\n\t- Prioritize using pre-existing components from src/components/ui when applicable\n\t- Create new components that match the style and conventions of existing components when needed\n\t- Examine existing components to understand the project's component patterns before creating new ones\n\n**IMPORTANT**: Do not use HTML based component like dropdown, calendar, toast etc. You **MUST** always use `/app/frontend/src/components/ui/ ` only as a primary components as these are modern and stylish component\n\n**Best Practices:**\n\t- Use Shadcn/UI as the primary component library for consistency and accessibility\n\t- Import path: ./components/[component-name]\n\n**Export Conventions:**\n\t- Components MUST use named exports (export const ComponentName = ...)\n\t- Pages MUST use default exports (export default function PageName() {...})\n\n**Toasts:**\n  - Use `sonner` for toasts\"\n  - Sonner component are located in `/app/src/components/ui/sonner.tsx`\n\nUse 2–4 color gradients, subtle textures/noise overlays, or CSS-based noise to avoid flat visuals.\n</General UI UX Design Guidelines>"
}
