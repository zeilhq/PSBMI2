"""Main FastAPI application for Pesantren Santri Management."""
import os
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, APIRouter
from starlette.middleware.cors import CORSMiddleware

from database import client
from seed import seed_admin_and_config
from routes.auth_routes import router as auth_router
from routes.santri_routes import router as santri_router
from routes.dashboard_routes import router as dashboard_router
from routes.admin_routes import router as admin_router


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        await seed_admin_and_config()
        logger.info("Seed completed (admin/config/murobbi)")
    except Exception as e:
        logger.exception(f"Seed failed: {e}")
    yield
    client.close()


app = FastAPI(
    title="Pesantren Amtsilati Santri Management API",
    description="Backend untuk Sistem Pendataan Santri Pondok Pesantren Amtsilati. "
                "Sertakan header Authorization: Bearer <token> untuk semua endpoint kecuali /auth/login.",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
    lifespan=lifespan,
)


api_router = APIRouter(prefix="/api")


@api_router.get("/")
async def root():
    return {"message": "Pesantren Amtsilati Santri Management API", "status": "ok"}


# Include all routers
api_router.include_router(auth_router)
api_router.include_router(santri_router)
api_router.include_router(dashboard_router)
api_router.include_router(admin_router)

app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)
