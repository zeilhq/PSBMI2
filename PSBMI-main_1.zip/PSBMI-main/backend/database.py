"""MongoDB database connection and helpers."""
import os
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv
from pathlib import Path

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Collections
users_col = db['users']
santri_col = db['santri']
murobbi_col = db['murobbi']
config_col = db['config']


def serialize_doc(doc):
    """Strip MongoDB _id and convert datetime to iso string for JSON."""
    if doc is None:
        return None
    if isinstance(doc, list):
        return [serialize_doc(d) for d in doc]
    if isinstance(doc, dict):
        out = {}
        for k, v in doc.items():
            if k == '_id':
                continue
            out[k] = serialize_doc(v)
        return out
    # datetime
    try:
        from datetime import datetime
        if isinstance(doc, datetime):
            return doc.isoformat()
    except Exception:
        pass
    return doc
