"""PDF style helpers shared by PDF generators (centralized to reduce duplication)."""
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.enums import TA_CENTER

PRIMARY = colors.HexColor('#1F5A46')
MUTED = colors.HexColor('#6B7C75')
BORDER = colors.HexColor('#D7E2DC')
ACCENT_BG = colors.HexColor('#E7F1EC')


def base_styles():
    """Return the common paragraph styles dictionary used across PDFs."""
    styles = getSampleStyleSheet()
    return {
        'sheet': styles,
        'title': ParagraphStyle(
            'title', parent=styles['Heading1'], alignment=TA_CENTER,
            fontSize=14, leading=18, textColor=PRIMARY, spaceAfter=2,
        ),
        'subtitle': ParagraphStyle(
            'sub', parent=styles['Normal'], alignment=TA_CENTER,
            fontSize=9, leading=12, textColor=colors.HexColor('#4A5C55'), spaceAfter=10,
        ),
        'label': ParagraphStyle('label', parent=styles['Normal'], fontSize=9, leading=12),
        'small': ParagraphStyle('small', parent=styles['Normal'], fontSize=8, leading=10, textColor=MUTED),
        'head_center': ParagraphStyle('head', parent=styles['Normal'], alignment=TA_CENTER,
                                      fontSize=10, leading=12, textColor=PRIMARY),
        'head2': ParagraphStyle('h2', parent=styles['Heading2'], alignment=TA_CENTER,
                                fontSize=14, textColor=PRIMARY),
        'bet_no': ParagraphStyle('bet', parent=styles['Normal'], alignment=TA_CENTER,
                                 fontSize=22, leading=24, textColor=PRIMARY),
        'bet_nama': ParagraphStyle('nama', parent=styles['Normal'], alignment=TA_CENTER,
                                   fontSize=10, leading=12),
        'bet_nis': ParagraphStyle('nis', parent=styles['Normal'], alignment=TA_CENTER,
                                  fontSize=8, leading=10, textColor=MUTED),
        'kts_value': ParagraphStyle('v', parent=styles['Normal'], fontSize=9, leading=11),
        'kts_field': ParagraphStyle('l', parent=styles['Normal'], fontSize=8, leading=10, textColor=MUTED),
    }


def rupiah(n) -> str:
    """Format integer to Indonesian rupiah string (Rp 1.234.567)."""
    try:
        n = int(n)
    except (TypeError, ValueError):
        return f"Rp {n}"
    s = f"{n:,}".replace(",", ".")
    return f"Rp {s}"
