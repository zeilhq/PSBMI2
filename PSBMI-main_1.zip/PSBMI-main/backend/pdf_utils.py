"""PDF generation utilities using ReportLab.

All PDFs share styles from pdf_styles.py and are built from small helper
functions, keeping each generator under ~50 lines.
"""
from io import BytesIO
from datetime import datetime
from reportlab.lib.pagesizes import A4, A5
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
)

from pdf_styles import base_styles, rupiah, PRIMARY, BORDER, ACCENT_BG, MUTED  # noqa: F401


def _document(buf: BytesIO, page_size, margin_mm: int = 14) -> SimpleDocTemplate:
    return SimpleDocTemplate(
        buf,
        pagesize=page_size,
        topMargin=margin_mm * mm,
        bottomMargin=margin_mm * mm,
        leftMargin=margin_mm * mm,
        rightMargin=margin_mm * mm,
    )


# ---------------------------- Kwitansi ----------------------------
def _kwitansi_info_table(santri: dict, st: dict) -> Table:
    """Build identitas santri block for kwitansi."""
    label = st['label']
    no_kwitansi = f"KW-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    tanggal = datetime.now().strftime('%d %B %Y, %H:%M')
    rows = [
        ('No. Kwitansi', no_kwitansi),
        ('Tanggal', tanggal),
        ('NIS', santri.get('nis', '-')),
        ('Nama Santri', santri.get('nama', '-')),
        ('Wali Santri', santri.get('wali_nama', '-') or '-'),
        ('Alamat', santri.get('alamat', '-') or '-'),
    ]
    data = [[Paragraph(f'<b>{k}</b>', label), Paragraph(str(v), label)] for k, v in rows]
    tbl = Table(data, colWidths=[35 * mm, 90 * mm])
    tbl.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
        ('TOPPADDING', (0, 0), (-1, -1), 3),
    ]))
    return tbl


def _kwitansi_items_table(items, totals, st):
    label = st['label']
    rows = [[Paragraph('<b>No</b>', label), Paragraph('<b>Item Biaya</b>', label),
             Paragraph('<b>Nominal</b>', label), Paragraph('<b>Status</b>', label)]]
    for idx, it in enumerate(items, start=1):
        status_text = 'LUNAS' if it.get('paid') else 'BELUM'
        rows.append([
            Paragraph(str(idx), label),
            Paragraph(it.get('name', '-'), label),
            Paragraph(rupiah(it.get('price', 0)), label),
            Paragraph(status_text, label),
        ])
    total, paid_total, remaining = totals
    rows.append(['', Paragraph('<b>Total Tagihan</b>', label), Paragraph(f'<b>{rupiah(total)}</b>', label), ''])
    rows.append(['', Paragraph('<b>Total Dibayar</b>', label), Paragraph(f'<b>{rupiah(paid_total)}</b>', label), ''])
    rows.append(['', Paragraph('<b>Sisa</b>', label), Paragraph(f'<b>{rupiah(remaining)}</b>', label), ''])
    tbl = Table(rows, colWidths=[10 * mm, 60 * mm, 35 * mm, 22 * mm])
    tbl.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), ACCENT_BG),
        ('TEXTCOLOR', (0, 0), (-1, 0), PRIMARY),
        ('GRID', (0, 0), (-1, -4), 0.5, BORDER),
        ('LINEABOVE', (0, -3), (-1, -3), 0.8, PRIMARY),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
    ]))
    return tbl


def _kwitansi_signature_block(petugas_name: str, st) -> Table:
    label = st['label']
    data = [
        [Paragraph('Wali Santri,', label), Paragraph('Petugas Pesantren,', label)],
        [Spacer(1, 38), Spacer(1, 38)],
        [Paragraph('(....................)', label), Paragraph(f'({petugas_name})', label)],
    ]
    tbl = Table(data, colWidths=[60 * mm, 60 * mm])
    tbl.setStyle(TableStyle([('ALIGN', (0, 0), (-1, -1), 'CENTER')]))
    return tbl


def generate_kwitansi_pdf(santri: dict, items: list, paid_total: int, total: int,
                          remaining: int, petugas_name: str = "-") -> bytes:
    buf = BytesIO()
    doc = _document(buf, A5)
    st = base_styles()
    elements = [
        Paragraph("KWITANSI PEMBAYARAN", st['title']),
        Paragraph("Pondok Pesantren Amtsilati", st['subtitle']),
        _kwitansi_info_table(santri, st),
        Spacer(1, 6),
        _kwitansi_items_table(items, (total, paid_total, remaining), st),
        Spacer(1, 14),
        _kwitansi_signature_block(petugas_name, st),
        Spacer(1, 6),
        Paragraph("Dokumen ini sah tanpa tanda tangan basah jika diunduh dari sistem.", st['small']),
    ]
    doc.build(elements)
    buf.seek(0)
    return buf.read()


# ---------------------------- Name Tag ----------------------------
def _nametag_cell(santri: dict, st) -> Table:
    cell = Table([
        [Paragraph(f"<b>#{santri.get('bet_no', '-')}</b>", st['bet_no'])],
        [Paragraph(santri.get('nama', '-'), st['bet_nama'])],
        [Paragraph(f"NIS: {santri.get('nis', '-')}", st['bet_nis'])],
    ], colWidths=[58 * mm], rowHeights=[14 * mm, 10 * mm, 6 * mm])
    cell.setStyle(TableStyle([
        ('BOX', (0, 0), (-1, -1), 0.8, PRIMARY),
        ('INNERGRID', (0, 0), (-1, -1), 0.2, BORDER),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ]))
    return cell


def _grid_rows(cells: list, cols_per_row: int):
    """Chunk a list of cells into rows of `cols_per_row`, padding last row with ''."""
    rows = []
    row = []
    for c in cells:
        row.append(c)
        if len(row) == cols_per_row:
            rows.append(row)
            row = []
    if row:
        while len(row) < cols_per_row:
            row.append('')
        rows.append(row)
    return rows


def generate_nametag_pdf(santri_list: list) -> bytes:
    buf = BytesIO()
    doc = _document(buf, A4, margin_mm=15)
    st = base_styles()
    elements = [Paragraph("Bet Nama Santri - Pondok Pesantren Amtsilati", st['head2']), Spacer(1, 8)]

    if not santri_list:
        elements.append(Paragraph("Tidak ada santri.", st['sheet']['Normal']))
    else:
        cells = [_nametag_cell(s, st) for s in santri_list]
        grid_rows = _grid_rows(cells, cols_per_row=3)
        grid = Table(grid_rows, colWidths=[60 * mm, 60 * mm, 60 * mm])
        grid.setStyle(TableStyle([
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('LEFTPADDING', (0, 0), (-1, -1), 2),
            ('RIGHTPADDING', (0, 0), (-1, -1), 2),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
        ]))
        elements.append(grid)

    doc.build(elements)
    buf.seek(0)
    return buf.read()


# ---------------------------- KTS ----------------------------
def _kts_cell(santri: dict, st) -> Table:
    label = st['kts_field']
    value = st['kts_value']
    inner = [
        [Paragraph("<b>PONDOK PESANTREN AMTSILATI</b>", st['head_center'])],
        [Paragraph("KARTU TANDA SANTRI", label)],
        [Spacer(1, 4)],
        [Paragraph("<b>NIS</b>", label)],
        [Paragraph(santri.get('nis', '-'), value)],
        [Paragraph("<b>Nama</b>", label)],
        [Paragraph(santri.get('nama', '-'), value)],
        [Paragraph("<b>Orang Tua / Wali</b>", label)],
        [Paragraph(santri.get('wali_nama', '-') or '-', value)],
        [Paragraph("<b>Alamat</b>", label)],
        [Paragraph(santri.get('alamat', '-') or '-', value)],
    ]
    cell = Table(inner, colWidths=[80 * mm])
    cell.setStyle(TableStyle([
        ('BOX', (0, 0), (-1, -1), 0.8, PRIMARY),
        ('LEFTPADDING', (0, 0), (-1, -1), 6),
        ('RIGHTPADDING', (0, 0), (-1, -1), 6),
        ('TOPPADDING', (0, 0), (-1, -1), 2),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 2),
    ]))
    return cell


def generate_kts_pdf(santri_list: list) -> bytes:
    buf = BytesIO()
    doc = _document(buf, A4, margin_mm=15)
    st = base_styles()
    elements = [Paragraph("Kartu Tanda Santri (KTS) Preview", st['head2']), Spacer(1, 8)]

    if not santri_list:
        elements.append(Paragraph("Tidak ada santri.", st['sheet']['Normal']))
    else:
        cells = [_kts_cell(s, st) for s in santri_list]
        grid_rows = _grid_rows(cells, cols_per_row=2)
        grid = Table(grid_rows, colWidths=[90 * mm, 90 * mm])
        grid.setStyle(TableStyle([
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ]))
        elements.append(grid)

    doc.build(elements)
    buf.seek(0)
    return buf.read()
