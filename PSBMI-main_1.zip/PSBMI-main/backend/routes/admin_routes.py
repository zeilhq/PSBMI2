"""Admin: users, murobbi, config routes."""
from fastapi import APIRouter, HTTPException, Depends
from database import users_col, murobbi_col, config_col, serialize_doc
from auth import require_admin, hash_password, get_current_user
from models import UserCreate, UserUpdate, MurobbiCreate, MurobbiUpdate, ConfigUpdate, now_iso, ALL_MENU_KEYS
import uuid

router = APIRouter(prefix="/admin", tags=["admin"])


# ------- USERS -------
@router.get("/users")
async def list_users(user=Depends(require_admin)):
    docs = await users_col.find({}).sort("created_at", 1).to_list(500)
    out = []
    for d in docs:
        d = serialize_doc(d)
        d.pop('password_hash', None)
        out.append(d)
    return out


@router.post("/users")
async def create_user(payload: UserCreate, user=Depends(require_admin)):
    if not payload.username or not payload.password:
        raise HTTPException(status_code=400, detail="username & password wajib diisi")
    if await users_col.find_one({"username": payload.username.strip()}):
        raise HTTPException(status_code=400, detail="Username sudah dipakai")
    perms = payload.permissions
    if perms is None:
        # Default: admin gets all, petugas gets all except admin menu
        if payload.role == 'admin':
            perms = ALL_MENU_KEYS
        else:
            perms = [k for k in ALL_MENU_KEYS if k != 'akses-admin']
    doc = {
        "id": str(uuid.uuid4()),
        "username": payload.username.strip(),
        "password_hash": hash_password(payload.password),
        "nama": payload.nama,
        "role": payload.role,
        "wa_number": payload.wa_number or "",
        "profile_photo": payload.profile_photo or "",
        "permissions": perms,
        "active": True,
        "created_at": now_iso(),
    }
    await users_col.insert_one(doc)
    public = serialize_doc(doc)
    public.pop('password_hash', None)
    return public


@router.put("/users/{user_id}")
async def update_user(user_id: str, payload: UserUpdate, user=Depends(require_admin)):
    existing = await users_col.find_one({"id": user_id})
    if not existing:
        raise HTTPException(status_code=404, detail="User tidak ditemukan")
    update_doc = {k: v for k, v in payload.model_dump(exclude_unset=True).items() if v is not None}
    if 'password' in update_doc:
        update_doc['password_hash'] = hash_password(update_doc.pop('password'))
    await users_col.update_one({"id": user_id}, {"$set": update_doc})
    new_doc = await users_col.find_one({"id": user_id})
    new_doc = serialize_doc(new_doc)
    new_doc.pop('password_hash', None)
    return new_doc


@router.delete("/users/{user_id}")
async def delete_user(user_id: str, user=Depends(require_admin)):
    if user_id == user.get('id'):
        raise HTTPException(status_code=400, detail="Tidak dapat menghapus diri sendiri")
    existing = await users_col.find_one({"id": user_id})
    if not existing:
        raise HTTPException(status_code=404, detail="User tidak ditemukan")
    await users_col.delete_one({"id": user_id})
    return {"ok": True}


# ------- MUROBBI -------
@router.get("/murobbi")
async def list_murobbi(user=Depends(get_current_user)):
    docs = await murobbi_col.find({}).sort("created_at", 1).to_list(500)
    return [serialize_doc(d) for d in docs]


@router.post("/murobbi")
async def create_murobbi(payload: MurobbiCreate, user=Depends(require_admin)):
    doc = {"id": str(uuid.uuid4()), "nama": payload.nama, "wa": payload.wa or "", "created_at": now_iso()}
    await murobbi_col.insert_one(doc)
    return serialize_doc(doc)


@router.put("/murobbi/{mid}")
async def update_murobbi(mid: str, payload: MurobbiUpdate, user=Depends(require_admin)):
    existing = await murobbi_col.find_one({"id": mid})
    if not existing:
        raise HTTPException(status_code=404, detail="Murobbi tidak ditemukan")
    update = {k: v for k, v in payload.model_dump(exclude_unset=True).items() if v is not None}
    await murobbi_col.update_one({"id": mid}, {"$set": update})
    new_doc = await murobbi_col.find_one({"id": mid})
    return serialize_doc(new_doc)


@router.delete("/murobbi/{mid}")
async def delete_murobbi(mid: str, user=Depends(require_admin)):
    await murobbi_col.delete_one({"id": mid})
    return {"ok": True}


# ------- CONFIG -------
@router.get("/config")
async def get_config(user=Depends(get_current_user)):
    cfg = await config_col.find_one({"id": "config"})
    return serialize_doc(cfg) or {}


@router.put("/config")
async def update_config(payload: ConfigUpdate, user=Depends(require_admin)):
    update = {k: v for k, v in payload.model_dump(exclude_unset=True).items() if v is not None}
    if 'admin_fees' in update:
        # ensure list of dicts
        update['admin_fees'] = [
            {"key": it.get('key') if isinstance(it, dict) else it.key,
             "name": it.get('name') if isinstance(it, dict) else it.name,
             "price": int(it.get('price') if isinstance(it, dict) else it.price)}
            for it in update['admin_fees']
        ]
    update['updated_at'] = now_iso()
    await config_col.update_one({"id": "config"}, {"$set": update}, upsert=True)
    cfg = await config_col.find_one({"id": "config"})
    return serialize_doc(cfg)


@router.get("/menu-keys")
async def menu_keys(user=Depends(get_current_user)):
    return {"keys": ALL_MENU_KEYS}
