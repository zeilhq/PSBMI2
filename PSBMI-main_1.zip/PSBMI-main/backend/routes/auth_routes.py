"""Authentication routes."""
from fastapi import APIRouter, HTTPException, Depends
from database import users_col, serialize_doc
from auth import verify_password, create_access_token, get_current_user
from models import LoginRequest, TokenResponse

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/login", response_model=TokenResponse)
async def login(payload: LoginRequest):
    user = await users_col.find_one({"username": payload.username.strip()})
    if not user:
        raise HTTPException(status_code=401, detail="Username atau password salah")
    if not user.get('active', True):
        raise HTTPException(status_code=403, detail="Akun dinonaktifkan")
    if not verify_password(payload.password, user.get('password_hash', '')):
        raise HTTPException(status_code=401, detail="Username atau password salah")
    token = create_access_token({"sub": user['id'], "username": user['username'], "role": user.get('role', 'petugas')})
    public_user = serialize_doc(user)
    public_user.pop('password_hash', None)
    return {"access_token": token, "token_type": "bearer", "user": public_user}


@router.get("/me")
async def me(user=Depends(get_current_user)):
    user.pop('password_hash', None)
    return user
