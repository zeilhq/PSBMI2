"""Santri (student) routes."""
from fastapi import APIRouter, HTTPException, Depends, Response
from database import santri_col, config_col, murobbi_col, users_col, serialize_doc
from auth import get_current_user, require_permission
from models import SantriCreate, SantriUpdate, now_iso, AdminFeeItem
import uuid
from pdf_utils import generate_kwitansi_pdf, generate_nametag_pdf, generate_kts_pdf

router = APIRouter(prefix="/santri", tags=["santri"])


async def _next_bet_and_lemari():
    """Compute next bet_no and lemari_no based on config and existing data."""
    cfg = await config_col.find_one({"id": "config"}) or {}
    start_bet = int(cfg.get('starting_bet_no', 1001))
    start_lemari = int(cfg.get('starting_lemari_no', 1))
    count = await santri_col.count_documents({})
    return start_bet + count, start_lemari + count


def _default_admin_items(fee_config):
    items = []
    for f in fee_config:
        items.append({
            "key": f['key'],
            "name": f['name'],
            "price": int(f['price']),
            "paid": False,
            "paid_at": None,
        })
    return items


@router.get("")
async def list_santri(user=Depends(require_permission("santri"))):
    docs = await santri_col.find({}).sort("created_at", 1).to_list(2000)
    cfg = await config_col.find_one({"id": "config"}) or {}
    start_bet = int(cfg.get('starting_bet_no', 1001))
    start_lemari = int(cfg.get('starting_lemari_no', 1))
    # Recompute bet/lemari ordinal-wise so it stays consistent with config starting numbers
    enriched = []
    for idx, d in enumerate(docs):
        d = serialize_doc(d)
        # If document already has stored bet_no/lemari_no, keep override only when config-derived value differs; we still recompute to keep consistent with config changes.
        d['bet_no'] = start_bet + idx
        d['lemari_no'] = start_lemari + idx
        enriched.append(d)
    return enriched


@router.get("/{santri_id}")
async def get_santri(santri_id: str, user=Depends(require_permission("santri"))):
    doc = await santri_col.find_one({"id": santri_id})
    if not doc:
        raise HTTPException(status_code=404, detail="Santri tidak ditemukan")
    return serialize_doc(doc)


@router.post("")
async def create_santri(payload: SantriCreate, user=Depends(require_permission("data-diri"))):
    # Ensure unique NIS
    if payload.nis:
        existing = await santri_col.find_one({"nis": payload.nis})
        if existing:
            raise HTTPException(status_code=400, detail="NIS sudah terdaftar")
    cfg = await config_col.find_one({"id": "config"}) or {}
    fee_config = cfg.get('admin_fees', [])
    bet_no, lemari_no = await _next_bet_and_lemari()
    new_id = str(uuid.uuid4())
    doc = {
        "id": new_id,
        "nis": payload.nis,
        "nama": payload.nama,
        "alamat": payload.alamat or "",
        "wali_nama": payload.wali_nama or "",
        "wali_wa": payload.wali_wa or "",
        "foto": payload.foto or "",
        "murobbi_id": payload.murobbi_id,
        "bet_no": bet_no,
        "lemari_no": lemari_no,
        "administrasi": _default_admin_items(fee_config),
        "seragam": {
            "biru": {"ukuran_seragam": "", "ukuran_sarung": "", "ready": False, "delivered": False},
            "ungu": {"ukuran_seragam": "", "ukuran_sarung": "", "ready": False, "delivered": False},
            "coklat": {"ukuran_seragam": "", "ukuran_sarung": "", "ready": False, "delivered": False},
            "all_delivered": False,
        },
        "perlengkapan": {
            "kasur": False,
            "bantal": False,
            "guling": False,
            "sarung_bantal_guling": False,
            "alat_tulis": False,
            "yanbua": False,
            "all_delivered": False,
        },
        "print_status": {
            "name_tag_printed": False,
            "name_tag_ready": False,
            "kts_printed": False,
            "lemari_label_printed": False,
        },
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "created_by": user.get('id'),
    }
    await santri_col.insert_one(doc)
    return serialize_doc(doc)


@router.put("/{santri_id}")
async def update_santri(santri_id: str, payload: SantriUpdate, user=Depends(get_current_user)):
    # Anyone with relevant menu permission can update; admin always.
    existing = await santri_col.find_one({"id": santri_id})
    if not existing:
        raise HTTPException(status_code=404, detail="Santri tidak ditemukan")
    update_doc = {k: v for k, v in payload.model_dump(exclude_unset=True).items() if v is not None}
    if 'nis' in update_doc and update_doc['nis'] != existing.get('nis'):
        dupe = await santri_col.find_one({"nis": update_doc['nis'], "id": {"$ne": santri_id}})
        if dupe:
            raise HTTPException(status_code=400, detail="NIS sudah dipakai santri lain")
    # Re-compute all_delivered flags for seragam/perlengkapan if relevant
    if 'seragam' in update_doc:
        s = update_doc['seragam']
        all_d = all(s.get(c, {}).get('delivered', False) for c in ['biru', 'ungu', 'coklat'])
        s['all_delivered'] = all_d
    if 'perlengkapan' in update_doc:
        p = update_doc['perlengkapan']
        keys = ['kasur', 'bantal', 'guling', 'sarung_bantal_guling', 'alat_tulis', 'yanbua']
        p['all_delivered'] = all(bool(p.get(k, False)) for k in keys)
    update_doc['updated_at'] = now_iso()
    await santri_col.update_one({"id": santri_id}, {"$set": update_doc})
    new_doc = await santri_col.find_one({"id": santri_id})
    return serialize_doc(new_doc)


@router.delete("/{santri_id}")
async def delete_santri(santri_id: str, user=Depends(require_permission("data-diri"))):
    existing = await santri_col.find_one({"id": santri_id})
    if not existing:
        raise HTTPException(status_code=404, detail="Santri tidak ditemukan")
    await santri_col.delete_one({"id": santri_id})
    return {"ok": True}


@router.post("/{santri_id}/administrasi/toggle")
async def toggle_admin_payment(santri_id: str, body: dict, user=Depends(require_permission("administrasi"))):
    key = body.get('key')
    paid = bool(body.get('paid'))
    existing = await santri_col.find_one({"id": santri_id})
    if not existing:
        raise HTTPException(status_code=404, detail="Santri tidak ditemukan")
    items = existing.get('administrasi', [])
    for it in items:
        if it.get('key') == key:
            it['paid'] = paid
            it['paid_at'] = now_iso() if paid else None
            break
    await santri_col.update_one({"id": santri_id}, {"$set": {"administrasi": items, "updated_at": now_iso()}})
    return {"ok": True, "administrasi": items}


@router.get("/{santri_id}/kwitansi.pdf")
async def kwitansi_pdf(santri_id: str, user=Depends(require_permission("administrasi"))):
    s = await santri_col.find_one({"id": santri_id})
    if not s:
        raise HTTPException(status_code=404, detail="Santri tidak ditemukan")
    items = s.get('administrasi', [])
    paid_total = sum(int(i['price']) for i in items if i.get('paid'))
    total = sum(int(i['price']) for i in items)
    remaining = total - paid_total
    pdf = generate_kwitansi_pdf(serialize_doc(s), items, paid_total, total, remaining, petugas_name=user.get('nama', '-'))
    nis = s.get('nis', santri_id)
    return Response(
        content=pdf,
        media_type="application/pdf",
        headers={"Content-Disposition": f'inline; filename="kwitansi-{nis}.pdf"'},
    )


@router.get("/print/name-tag.pdf")
async def print_nametag_pdf(user=Depends(require_permission("name-tag"))):
    docs = await santri_col.find({}).sort("created_at", 1).to_list(2000)
    cfg = await config_col.find_one({"id": "config"}) or {}
    start_bet = int(cfg.get('starting_bet_no', 1001))
    enriched = []
    for idx, d in enumerate(docs):
        d = serialize_doc(d)
        d['bet_no'] = start_bet + idx
        enriched.append(d)
    pdf = generate_nametag_pdf(enriched)
    return Response(content=pdf, media_type="application/pdf", headers={"Content-Disposition": 'inline; filename="name-tag.pdf"'})


@router.get("/print/kts.pdf")
async def print_kts_pdf(user=Depends(require_permission("name-tag"))):
    docs = await santri_col.find({}).sort("created_at", 1).to_list(2000)
    enriched = [serialize_doc(d) for d in docs]
    pdf = generate_kts_pdf(enriched)
    return Response(content=pdf, media_type="application/pdf", headers={"Content-Disposition": 'inline; filename="kts.pdf"'})
