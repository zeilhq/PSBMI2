"""Dashboard route."""
from fastapi import APIRouter, Depends
from database import santri_col, users_col, config_col, serialize_doc
from auth import require_permission

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("")
async def get_dashboard(user=Depends(require_permission("dashboard"))):
    santri_count = await santri_col.count_documents({})
    docs = await santri_col.find({}).to_list(5000)
    total_uang = 0
    paid_uang = 0
    seragam_lengkap = 0
    perlengkapan_lengkap = 0
    for d in docs:
        for it in d.get('administrasi', []):
            total_uang += int(it.get('price', 0))
            if it.get('paid'):
                paid_uang += int(it.get('price', 0))
        if d.get('seragam', {}).get('all_delivered'):
            seragam_lengkap += 1
        if d.get('perlengkapan', {}).get('all_delivered'):
            perlengkapan_lengkap += 1

    petugas_cursor = users_col.find({"active": True}).sort("created_at", 1)
    petugas_docs = await petugas_cursor.to_list(200)
    petugas_list = []
    for u in petugas_docs:
        u = serialize_doc(u)
        u.pop('password_hash', None)
        petugas_list.append({
            "id": u['id'],
            "username": u['username'],
            "nama": u['nama'],
            "role": u['role'],
            "wa_number": u.get('wa_number', ''),
            "profile_photo": u.get('profile_photo', ''),
        })

    cfg = await config_col.find_one({"id": "config"}) or {}
    return {
        "santri_count": santri_count,
        "total_uang": total_uang,
        "paid_uang": paid_uang,
        "remaining_uang": total_uang - paid_uang,
        "seragam_lengkap": seragam_lengkap,
        "perlengkapan_lengkap": perlengkapan_lengkap,
        "petugas": petugas_list,
        "psb_admin_link": cfg.get('psb_admin_link', 'https://psb.amtsilatipusat.com/admin'),
    }
