"""JWT auth helpers and dependencies."""
import os
import jwt
import bcrypt
from datetime import datetime, timedelta, timezone
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from database import users_col, serialize_doc

JWT_SECRET = os.environ.get('JWT_SECRET', 'pesantren-amtsilati-secret-key-change-me')
JWT_ALG = 'HS256'
JWT_EXP_HOURS = 24 * 7  # 7 days

security = HTTPBearer(auto_error=False)


def hash_password(password: str) -> str:
    salt = bcrypt.gensalt(rounds=12)
    return bcrypt.hashpw(password.encode(), salt).decode()


def verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode(), hashed.encode())
    except Exception:
        return False


def create_access_token(payload: dict) -> str:
    data = payload.copy()
    data['exp'] = datetime.now(timezone.utc) + timedelta(hours=JWT_EXP_HOURS)
    data['iat'] = datetime.now(timezone.utc)
    return jwt.encode(data, JWT_SECRET, algorithm=JWT_ALG)


def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token kadaluarsa, silakan login ulang")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Token tidak valid")


async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if credentials is None:
        raise HTTPException(status_code=401, detail="Tidak terotentikasi")
    payload = decode_token(credentials.credentials)
    user_id = payload.get('sub')
    if not user_id:
        raise HTTPException(status_code=401, detail="Token tidak valid")
    user = await users_col.find_one({"id": user_id})
    if not user:
        raise HTTPException(status_code=401, detail="User tidak ditemukan")
    if not user.get('active', True):
        raise HTTPException(status_code=403, detail="User dinonaktifkan")
    return serialize_doc(user)


async def require_admin(user=Depends(get_current_user)):
    if user.get('role') != 'admin':
        raise HTTPException(status_code=403, detail="Hanya admin yang dapat mengakses")
    return user


def require_permission(menu_key: str):
    async def dep(user=Depends(get_current_user)):
        if user.get('role') == 'admin':
            return user
        perms = user.get('permissions', []) or []
        if menu_key not in perms:
            raise HTTPException(status_code=403, detail=f"Tidak ada akses ke menu '{menu_key}'")
        return user
    return dep
