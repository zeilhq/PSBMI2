"""Seed initial admin user and config (idempotent)."""
import uuid

from database import users_col, config_col, murobbi_col
from auth import hash_password
from models import now_iso, ALL_MENU_KEYS

DEFAULT_FEES = [
    {"key": "seragam", "name": "Seragam", "price": 800000},
    {"key": "stifin", "name": "Tes STIFIn", "price": 750000},
    {"key": "perlengkapan_tidur", "name": "Perlengkapan Tidur", "price": 650000},
    {"key": "yanbua_alat_tulis", "name": "Yanbua & Alat Tulis", "price": 75000},
]

PETUGAS_DEFAULT_PERMS = [
    "dashboard", "santri", "data-diri", "administrasi",
    "seragam", "perlengkapan", "name-tag",
]


def _build_user_doc(username: str, password: str, nama: str, role: str,
                    wa: str, permissions) -> dict:
    return {
        "id": str(uuid.uuid4()),
        "username": username,
        "password_hash": hash_password(password),
        "nama": nama,
        "role": role,
        "wa_number": wa,
        "profile_photo": "",
        "permissions": permissions,
        "active": True,
        "created_at": now_iso(),
    }


async def _ensure_admin_user():
    existing = await users_col.find_one({"username": "admin"})
    if existing:
        return False
    doc = _build_user_doc(
        "admin", "admin123", "Administrator Pesantren", "admin",
        "628123456789", ALL_MENU_KEYS,
    )
    await users_col.insert_one(doc)
    print("[seed] Default admin created (username: admin / password: admin123)")
    return True


async def _ensure_petugas_user():
    existing = await users_col.find_one({"username": "petugas"})
    if existing:
        return False
    doc = _build_user_doc(
        "petugas", "petugas123", "Petugas Asrama", "petugas",
        "628987654321", PETUGAS_DEFAULT_PERMS,
    )
    await users_col.insert_one(doc)
    print("[seed] Default petugas created (username: petugas / password: petugas123)")
    return True


async def _ensure_default_config():
    cfg = await config_col.find_one({"id": "config"})
    if cfg:
        return False
    await config_col.insert_one({
        "id": "config",
        "admin_fees": DEFAULT_FEES,
        "starting_bet_no": 1001,
        "starting_lemari_no": 1,
        "psb_admin_link": "https://psb.amtsilatipusat.com/admin",
        "updated_at": now_iso(),
    })
    print("[seed] Default config created")
    return True


async def _ensure_default_murobbi():
    mcount = await murobbi_col.count_documents({})
    if mcount > 0:
        return False
    defaults = [
        {"id": str(uuid.uuid4()), "nama": "Ustadz Ahmad", "wa": "628111111111", "created_at": now_iso()},
        {"id": str(uuid.uuid4()), "nama": "Ustadz Fauzi", "wa": "628222222222", "created_at": now_iso()},
    ]
    await murobbi_col.insert_many(defaults)
    print("[seed] Default murobbi list created")
    return True


async def seed_admin_and_config():
    """Idempotent seed: creates admin user, petugas user, config, and default murobbi if missing."""
    await _ensure_admin_user()
    await _ensure_petugas_user()
    await _ensure_default_config()
    await _ensure_default_murobbi()
