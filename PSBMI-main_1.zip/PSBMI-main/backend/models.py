"""Pydantic models for the pesantren santri management app."""
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone
import uuid


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ---------------------- Auth ----------------------
class LoginRequest(BaseModel):
    username: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: Dict[str, Any]


# ---------------------- Users / Petugas ----------------------
ALL_MENU_KEYS = [
    "dashboard",
    "santri",
    "data-diri",
    "administrasi",
    "seragam",
    "perlengkapan",
    "name-tag",
    "akses-admin",
]


class UserCreate(BaseModel):
    username: str
    password: str
    nama: str
    role: str = Field(default="petugas")  # 'admin' or 'petugas'
    wa_number: Optional[str] = ""
    profile_photo: Optional[str] = ""  # base64
    permissions: Optional[List[str]] = None


class UserUpdate(BaseModel):
    nama: Optional[str] = None
    password: Optional[str] = None
    role: Optional[str] = None
    wa_number: Optional[str] = None
    profile_photo: Optional[str] = None
    permissions: Optional[List[str]] = None
    active: Optional[bool] = None


class UserPublic(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    username: str
    nama: str
    role: str
    wa_number: Optional[str] = ""
    profile_photo: Optional[str] = ""
    permissions: List[str] = []
    active: bool = True
    created_at: str = Field(default_factory=now_iso)


# ---------------------- Santri ----------------------
class AdminFeeItem(BaseModel):
    key: str
    name: str
    price: int
    paid: bool = False
    paid_at: Optional[str] = None


class SeragamSet(BaseModel):
    ukuran_seragam: Optional[str] = ""
    ukuran_sarung: Optional[str] = ""
    ready: bool = False  # ukuran sudah tersedia/dipesan
    delivered: bool = False  # sudah diserahkan ke santri


class SantriSeragam(BaseModel):
    biru: SeragamSet = Field(default_factory=SeragamSet)
    ungu: SeragamSet = Field(default_factory=SeragamSet)
    coklat: SeragamSet = Field(default_factory=SeragamSet)
    all_delivered: bool = False


class SantriPerlengkapan(BaseModel):
    kasur: bool = False
    bantal: bool = False
    guling: bool = False
    sarung_bantal_guling: bool = False
    alat_tulis: bool = False
    yanbua: bool = False
    all_delivered: bool = False


class SantriPrintStatus(BaseModel):
    name_tag_printed: bool = False
    name_tag_ready: bool = False  # tempel/siap
    kts_printed: bool = False
    lemari_label_printed: bool = False


class SantriCreate(BaseModel):
    nis: str
    nama: str
    alamat: Optional[str] = ""
    wali_nama: Optional[str] = ""
    wali_wa: Optional[str] = ""
    foto: Optional[str] = ""  # base64
    murobbi_id: Optional[str] = None


class SantriUpdate(BaseModel):
    nis: Optional[str] = None
    nama: Optional[str] = None
    alamat: Optional[str] = None
    wali_nama: Optional[str] = None
    wali_wa: Optional[str] = None
    foto: Optional[str] = None
    murobbi_id: Optional[str] = None
    seragam: Optional[Dict[str, Any]] = None
    perlengkapan: Optional[Dict[str, Any]] = None
    administrasi: Optional[List[Dict[str, Any]]] = None
    print_status: Optional[Dict[str, Any]] = None


# ---------------------- Murobbi ----------------------
class MurobbiCreate(BaseModel):
    nama: str
    wa: Optional[str] = ""


class MurobbiUpdate(BaseModel):
    nama: Optional[str] = None
    wa: Optional[str] = None


# ---------------------- Config ----------------------
class FeeConfigItem(BaseModel):
    key: str
    name: str
    price: int


class ConfigUpdate(BaseModel):
    admin_fees: Optional[List[FeeConfigItem]] = None
    starting_bet_no: Optional[int] = None
    starting_lemari_no: Optional[int] = None
    psb_admin_link: Optional[str] = None
