import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import '@/App.css';
import { AuthProvider } from '@/context/AuthContext';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import Login from '@/pages/Login';
import Dashboard from '@/pages/Dashboard';
import Santri from '@/pages/Santri';
import DataDiri from '@/pages/DataDiri';
import Administrasi from '@/pages/Administrasi';
import Seragam from '@/pages/Seragam';
import Perlengkapan from '@/pages/Perlengkapan';
import NameTag from '@/pages/NameTag';
import AksesAdmin from '@/pages/AksesAdmin';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/" element={<ProtectedRoute permission="dashboard"><Dashboard /></ProtectedRoute>} />
            <Route path="/santri" element={<ProtectedRoute permission="santri"><Santri /></ProtectedRoute>} />
            <Route path="/data-diri" element={<ProtectedRoute permission="data-diri"><DataDiri /></ProtectedRoute>} />
            <Route path="/administrasi" element={<ProtectedRoute permission="administrasi"><Administrasi /></ProtectedRoute>} />
            <Route path="/seragam" element={<ProtectedRoute permission="seragam"><Seragam /></ProtectedRoute>} />
            <Route path="/perlengkapan" element={<ProtectedRoute permission="perlengkapan"><Perlengkapan /></ProtectedRoute>} />
            <Route path="/name-tag" element={<ProtectedRoute permission="name-tag"><NameTag /></ProtectedRoute>} />
            <Route path="/akses-admin" element={<ProtectedRoute permission="akses-admin"><AksesAdmin /></ProtectedRoute>} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </div>
  );
}

export default App;
