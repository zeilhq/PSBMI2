import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';

export function ProtectedRoute({ children, permission }) {
  const { user, loading, hasPermission } = useAuth();
  if (loading) {
    return (
      <div className="min-h-dvh flex items-center justify-center bg-[hsl(var(--background))]">
        <div className="text-sm text-muted-foreground">Memuat...</div>
      </div>
    );
  }
  if (!user) return <Navigate to="/login" replace />;
  if (permission && !hasPermission(permission)) {
    return (
      <div className="min-h-dvh flex items-center justify-center p-6">
        <div className="max-w-md text-center bg-white border rounded-xl p-6 shadow-sm">
          <h2 className="font-display text-xl font-semibold">Akses ditolak</h2>
          <p className="text-sm text-muted-foreground mt-2">
            Anda tidak memiliki izin untuk mengakses halaman ini. Hubungi admin pesantren.
          </p>
        </div>
      </div>
    );
  }
  return children;
}
