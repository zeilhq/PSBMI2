import React, { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { APP } from '@/constants/testIds';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Separator } from '@/components/ui/separator';
import {
  LayoutDashboard, Users, UserPlus, ReceiptText, Shirt, Bed,
  Tag, Settings, LogOut, Menu, ChevronLeft, ChevronRight, GraduationCap,
} from 'lucide-react';
import { Toaster } from '@/components/ui/sonner';

const MENU = [
  { key: 'dashboard', to: '/', label: 'Dashboard', icon: LayoutDashboard, group: 'Operasional' },
  { key: 'santri', to: '/santri', label: 'Santri', icon: Users, group: 'Operasional' },
  { key: 'data-diri', to: '/data-diri', label: 'Data Diri', icon: UserPlus, group: 'Operasional' },
  { key: 'administrasi', to: '/administrasi', label: 'Administrasi Asrama', icon: ReceiptText, group: 'Administrasi' },
  { key: 'seragam', to: '/seragam', label: 'Seragam', icon: Shirt, group: 'Administrasi' },
  { key: 'perlengkapan', to: '/perlengkapan', label: 'Perlengkapan Asrama', icon: Bed, group: 'Administrasi' },
  { key: 'name-tag', to: '/name-tag', label: 'Name Tag / KTS', icon: Tag, group: 'Administrasi' },
  { key: 'akses-admin', to: '/akses-admin', label: 'Akses Admin', icon: Settings, group: 'Sistem' },
];

function SidebarContent({ collapsed, onItemClick }) {
  const { user, logout, hasPermission } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const groups = ['Operasional', 'Administrasi', 'Sistem'];

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Logo */}
      <div className={`flex items-center gap-3 px-4 ${collapsed ? 'justify-center' : ''} py-4 border-b`}>
        <div className="w-10 h-10 rounded-xl bg-[hsl(var(--primary))] text-white flex items-center justify-center shrink-0">
          <GraduationCap className="w-5 h-5" />
        </div>
        {!collapsed && (
          <div className="min-w-0">
            <div className="font-display font-semibold text-sm tracking-tight">Amtsilati</div>
            <div className="text-[11px] text-muted-foreground truncate">Manajemen Santri</div>
          </div>
        )}
      </div>

      {/* Menu */}
      <nav className="flex-1 overflow-y-auto py-3">
        <TooltipProvider delayDuration={120}>
          {groups.map((g) => {
            const items = MENU.filter((m) => m.group === g && hasPermission(m.key));
            if (items.length === 0) return null;
            return (
              <div key={g} className="mb-2">
                {!collapsed && (
                  <div className="px-4 pt-2 pb-1 text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">
                    {g}
                  </div>
                )}
                <div className="flex flex-col">
                  {items.map((m) => {
                    const Icon = m.icon;
                    const NavItem = (
                      <NavLink
                        key={m.key}
                        to={m.to}
                        end={m.to === '/'}
                        onClick={() => onItemClick && onItemClick()}
                        data-testid={`sidebar-nav-item-${m.key}`}
                        className={({ isActive }) =>
                          `mx-2 my-0.5 flex items-center gap-3 rounded-lg px-3 ${collapsed ? 'justify-center' : ''} min-h-11 text-sm transition-colors duration-200 ${
                            isActive
                              ? 'bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]'
                              : 'text-[hsl(var(--foreground))] hover:bg-[hsl(var(--secondary))]'
                          }`
                        }
                      >
                        <Icon className="w-4 h-4 shrink-0" />
                        {!collapsed && <span className="truncate">{m.label}</span>}
                      </NavLink>
                    );
                    if (collapsed) {
                      return (
                        <Tooltip key={m.key}>
                          <TooltipTrigger asChild>{NavItem}</TooltipTrigger>
                          <TooltipContent side="right">{m.label}</TooltipContent>
                        </Tooltip>
                      );
                    }
                    return NavItem;
                  })}
                </div>
              </div>
            );
          })}
        </TooltipProvider>
      </nav>

      <Separator />

      {/* User chip + Logout */}
      <div className={`p-3 ${collapsed ? 'space-y-2' : 'flex items-center gap-3'}`}>
        <div
          data-testid={APP.userChip}
          className={`flex items-center gap-3 ${collapsed ? 'justify-center' : 'flex-1 min-w-0'}`}
        >
          <Avatar className="w-9 h-9">
            <AvatarImage src={user?.profile_photo || ''} alt={user?.nama} />
            <AvatarFallback className="bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))] text-xs font-semibold">
              {(user?.nama || '?').split(' ').slice(0, 2).map((p) => p[0]).join('').toUpperCase()}
            </AvatarFallback>
          </Avatar>
          {!collapsed && (
            <div className="min-w-0">
              <div className="text-xs font-semibold truncate">{user?.nama}</div>
              <div className="text-[11px] text-muted-foreground capitalize">{user?.role}</div>
            </div>
          )}
        </div>
        <Button
          variant="ghost"
          size={collapsed ? 'icon' : 'sm'}
          onClick={handleLogout}
          data-testid={APP.logoutButton}
          className={collapsed ? 'w-full justify-center' : ''}
          aria-label="Keluar"
        >
          <LogOut className="w-4 h-4" />
          {!collapsed && <span className="ml-1.5">Keluar</span>}
        </Button>
      </div>
    </div>
  );
}

export function DashboardShell({ children, title, subtitle, actions }) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div
      className="min-h-dvh grid grid-cols-1 lg:grid-cols-[var(--sidebar-w)_1fr] bg-[hsl(var(--background))]"
      style={{ ['--sidebar-w']: collapsed ? 'var(--sidebar-collapsed-width)' : 'var(--sidebar-width)' }}
    >
      {/* Desktop sidebar */}
      <aside
        className="hidden lg:block sticky top-0 h-dvh border-r bg-white overflow-hidden"
        style={{ width: collapsed ? 'var(--sidebar-collapsed-width)' : 'var(--sidebar-width)', transition: 'width 220ms var(--ease-out)' }}
      >
        <SidebarContent collapsed={collapsed} />
      </aside>

      {/* Mobile drawer */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="left" className="p-0 w-[280px]">
          <SidebarContent collapsed={false} onItemClick={() => setMobileOpen(false)} />
        </SheetContent>
      </Sheet>

      {/* Main content */}
      <div className="min-w-0 flex flex-col">
        {/* Top bar */}
        <header className="sticky top-0 z-30 bg-white/85 backdrop-blur border-b">
          <div className="flex items-center gap-2 px-4 sm:px-6 py-3">
            <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="lg:hidden"
                  data-testid={APP.mobileMenuButton}
                  aria-label="Buka menu"
                >
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
            </Sheet>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setCollapsed((v) => !v)}
              className="hidden lg:inline-flex"
              data-testid={APP.sidebarToggle}
              aria-label={collapsed ? 'Buka sidebar' : 'Tutup sidebar'}
            >
              {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            </Button>
            <div className="flex-1 min-w-0">
              <h1 className="font-display text-base sm:text-lg font-semibold truncate">{title}</h1>
              {subtitle && <p className="text-[11px] sm:text-xs text-muted-foreground truncate">{subtitle}</p>}
            </div>
            <div className="flex items-center gap-2">{actions}</div>
          </div>
        </header>

        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-4 sm:py-6 max-w-[1280px] w-full mx-auto">
          {children}
        </main>
      </div>

      <Toaster position="top-center" richColors />
    </div>
  );
}
