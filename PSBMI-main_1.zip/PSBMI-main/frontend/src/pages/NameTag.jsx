import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { api, API_BASE } from '@/lib/api';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { NAME_TAG } from '@/constants/testIds';
import { Printer, Loader2, Search, Tag as TagIcon, IdCard } from 'lucide-react';
import { toast } from 'sonner';

function TagPreview({ s }) {
  return (
    <div data-testid={`${NAME_TAG.preview}-${s.nis}`} className="rounded-[var(--radius-md)] border-2 border-[hsl(var(--primary))] bg-white p-2 flex flex-col items-center justify-center min-h-[88px] text-center">
      <div className="font-display text-2xl font-bold text-[hsl(var(--primary))] leading-none">#{s.bet_no}</div>
      <div className="text-xs font-semibold mt-1 truncate w-full">{s.nama}</div>
      <div className="text-[10px] text-muted-foreground font-mono">NIS: {s.nis}</div>
    </div>
  );
}

function KtsPreview({ s }) {
  return (
    <div className="rounded-[var(--radius-md)] border-2 border-[hsl(var(--primary))] bg-white p-3">
      <div className="text-center pb-2 border-b">
        <div className="font-display text-xs font-bold text-[hsl(var(--primary))]">PONDOK PESANTREN AMTSILATI</div>
        <div className="text-[10px] text-muted-foreground">KARTU TANDA SANTRI</div>
      </div>
      <div className="text-[11px] space-y-1 pt-2">
        <div><span className="text-muted-foreground">NIS:</span> <span className="font-mono font-semibold">{s.nis}</span></div>
        <div><span className="text-muted-foreground">Nama:</span> <span className="font-semibold">{s.nama}</span></div>
        <div><span className="text-muted-foreground">Orang Tua:</span> <span>{s.wali_nama || '-'}</span></div>
        <div className="line-clamp-2"><span className="text-muted-foreground">Alamat:</span> <span>{s.alamat || '-'}</span></div>
      </div>
    </div>
  );
}

export default function NameTag() {
  const [list, setList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [printingTag, setPrintingTag] = useState(false);
  const [printingKts, setPrintingKts] = useState(false);
  const [q, setQ] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/santri');
      setList(data || []);
    } catch (err) {
      console.error('Failed to load santri:', err);
      toast.error('Gagal memuat data santri');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return list;
    return list.filter((x) => (x.nama || '').toLowerCase().includes(s) || (x.nis || '').toLowerCase().includes(s));
  }, [list, q]);

  const toggle = async (s, field) => {
    try {
      const newStatus = { ...(s.print_status || {}), [field]: !s.print_status?.[field] };
      await api.put(`/santri/${s.id}`, { print_status: newStatus });
      setList((cur) => cur.map((x) => x.id === s.id ? { ...x, print_status: newStatus } : x));
      toast.success('Status diperbarui');
    } catch (e) {
      toast.error('Gagal memperbarui');
    }
  };

  const openPdf = async (url, filename) => {
    const token = localStorage.getItem('amtsilati_token');
    const resp = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!resp.ok) throw new Error('Gagal');
    const blob = await resp.blob();
    const u = URL.createObjectURL(blob);
    const w = window.open(u, '_blank');
    if (!w) {
      const a = document.createElement('a'); a.href = u; a.download = filename; a.click();
    }
  };

  const printNameTag = async () => {
    setPrintingTag(true);
    try {
      await openPdf(`${API_BASE}/santri/print/name-tag.pdf`, 'name-tag.pdf');
      toast.success('Bet nama siap dicetak');
    } catch (e) {
      toast.error('Gagal menyiapkan PDF');
    } finally {
      setPrintingTag(false);
    }
  };

  const printKts = async () => {
    setPrintingKts(true);
    try {
      await openPdf(`${API_BASE}/santri/print/kts.pdf`, 'kts.pdf');
      toast.success('KTS preview siap');
    } catch (e) {
      toast.error('Gagal menyiapkan PDF');
    } finally {
      setPrintingKts(false);
    }
  };

  return (
    <DashboardShell
      title="Name Tag & KTS"
      subtitle="Bet nama (auto render), label lemari, dan preview KTS"
      actions={
        <div className="flex items-center gap-2">
          <Button onClick={printNameTag} disabled={printingTag} variant="outline" size="sm" className="gap-1.5" data-testid={NAME_TAG.printNameTag}>
            {printingTag ? <Loader2 className="w-4 h-4 animate-spin" /> : <Printer className="w-4 h-4" />} <span className="hidden sm:inline">Cetak Bet Nama</span>
          </Button>
          <Button onClick={printKts} disabled={printingKts} size="sm" className="gap-1.5 bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90" data-testid={NAME_TAG.printKts}>
            {printingKts ? <Loader2 className="w-4 h-4 animate-spin" /> : <Printer className="w-4 h-4" />} <span className="hidden sm:inline">Cetak KTS</span>
          </Button>
        </div>
      }
    >
      <div className="relative mb-4">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari santri" className="pl-9 max-w-sm" />
      </div>

      <div className="space-y-3">
        {(() => {
          if (loading) {
            return <Card><CardContent className="p-10 text-center text-muted-foreground">Memuat...</CardContent></Card>;
          }
          if (filtered.length === 0) {
            return <Card><CardContent className="p-10 text-center text-muted-foreground">Belum ada santri. Tambah santri terlebih dahulu.</CardContent></Card>;
          }
          return filtered.map((s) => (
            <Card key={s.id} data-testid={`${NAME_TAG.cardChecklist}-${s.nis}`}>
              <CardContent className="p-3 sm:p-4 grid grid-cols-1 sm:grid-cols-[180px_160px_1fr] gap-3 sm:gap-4 items-center">
                <TagPreview s={s} />
                <KtsPreview s={s} />
                <div className="min-w-0">
                  <div className="font-display font-semibold truncate">{s.nama}</div>
                  <div className="text-xs text-muted-foreground flex items-center gap-3 mt-0.5">
                    <span className="font-mono">NIS: {s.nis}</span>
                    <span>Bet #{s.bet_no}</span>
                    <span>Lemari #{s.lemari_no}</span>
                  </div>
                  <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <label className="flex items-center gap-2 text-sm cursor-pointer rounded-lg border px-3 py-2 min-h-11">
                      <Checkbox checked={!!s.print_status?.name_tag_printed} onCheckedChange={() => toggle(s, 'name_tag_printed')} />
                      <span className="flex-1">Bet nama sudah dicetak</span>
                      {s.print_status?.name_tag_printed && <Badge className="text-[10px] bg-[hsl(var(--success))]/12 text-[hsl(var(--success))] border-[hsl(var(--success))]/25">OK</Badge>}
                    </label>
                    <label className="flex items-center gap-2 text-sm cursor-pointer rounded-lg border px-3 py-2 min-h-11">
                      <Checkbox checked={!!s.print_status?.name_tag_ready} onCheckedChange={() => toggle(s, 'name_tag_ready')} />
                      <span className="flex-1">Bet nama siap / tertempel</span>
                      {s.print_status?.name_tag_ready && <Badge className="text-[10px] bg-[hsl(var(--success))]/12 text-[hsl(var(--success))] border-[hsl(var(--success))]/25">OK</Badge>}
                    </label>
                    <label className="flex items-center gap-2 text-sm cursor-pointer rounded-lg border px-3 py-2 min-h-11">
                      <Checkbox checked={!!s.print_status?.kts_printed} onCheckedChange={() => toggle(s, 'kts_printed')} />
                      <span className="flex-1">KTS sudah dicetak</span>
                      {s.print_status?.kts_printed && <Badge className="text-[10px] bg-[hsl(var(--success))]/12 text-[hsl(var(--success))] border-[hsl(var(--success))]/25">OK</Badge>}
                    </label>
                    <label className="flex items-center gap-2 text-sm cursor-pointer rounded-lg border px-3 py-2 min-h-11">
                      <Checkbox checked={!!s.print_status?.lemari_label_printed} onCheckedChange={() => toggle(s, 'lemari_label_printed')} />
                      <span className="flex-1">Label lemari sudah dicetak</span>
                      {s.print_status?.lemari_label_printed && <Badge className="text-[10px] bg-[hsl(var(--success))]/12 text-[hsl(var(--success))] border-[hsl(var(--success))]/25">OK</Badge>}
                    </label>
                  </div>
                </div>
              </CardContent>
            </Card>
          ));
        })()}
      </div>
    </DashboardShell>
  );
}
