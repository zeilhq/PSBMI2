import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { api } from '@/lib/api';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PERLENGKAPAN } from '@/constants/testIds';
import { buildWaLink } from '@/lib/format';
import { Save, MessageCircle, Search, Loader2, BedDouble } from 'lucide-react';
import { toast } from 'sonner';

const ITEMS = [
  ['kasur', 'Kasur'],
  ['bantal', 'Bantal'],
  ['guling', 'Guling'],
  ['sarung_bantal_guling', 'Sarung Bantal & Guling'],
  ['alat_tulis', 'Alat Tulis'],
  ['yanbua', 'Yanbua'],
];

export default function Perlengkapan() {
  const [params, setParams] = useSearchParams();
  const initialId = params.get('id') || '';
  const [list, setList] = useState([]);
  const [murobbi, setMurobbi] = useState([]);
  const [petugas, setPetugas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState(initialId);
  const [perlengkapan, setPerlengkapan] = useState(null);
  const [murobbiId, setMurobbiId] = useState('');
  const [saving, setSaving] = useState(false);
  const [q, setQ] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [sres, mres, dres] = await Promise.all([
        api.get('/santri'),
        api.get('/admin/murobbi').catch(() => ({ data: [] })),
        api.get('/dashboard').catch(() => ({ data: { petugas: [] } })),
      ]);
      setList(sres.data || []);
      setMurobbi(mres.data || []);
      setPetugas(dres.data?.petugas || []);
      if (sres.data && sres.data.length > 0) setSelectedId((curr) => curr || sres.data[0].id);
    } catch (err) {
      console.error('Failed to load data:', err);
      toast.error('Gagal memuat data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    const sel = list.find((x) => x.id === selectedId);
    if (sel) {
      setPerlengkapan(JSON.parse(JSON.stringify(sel.perlengkapan || {})));
      setMurobbiId(sel.murobbi_id || '');
    } else {
      setPerlengkapan(null);
      setMurobbiId('');
    }
  }, [selectedId, list]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return list;
    return list.filter((x) => (x.nama || '').toLowerCase().includes(s) || (x.nis || '').toLowerCase().includes(s));
  }, [list, q]);

  const selected = list.find((x) => x.id === selectedId);
  const murobbiObj = murobbi.find((m) => m.id === murobbiId);
  const targetPetugas = petugas.find((p) => p.role === 'admin') || petugas[0];

  const setItem = (k, v) => setPerlengkapan((p) => ({ ...p, [k]: v }));

  const save = async () => {
    if (!selected || !perlengkapan) return;
    setSaving(true);
    try {
      const { data } = await api.put(`/santri/${selected.id}`, { perlengkapan, murobbi_id: murobbiId || null });
      setList((cur) => cur.map((x) => x.id === selected.id ? data : x));
      toast.success('Perlengkapan tersimpan');
    } catch (e) {
      toast.error(e?.response?.data?.detail || 'Gagal menyimpan');
    } finally {
      setSaving(false);
    }
  };

  const buildWaMessage = () => {
    if (!selected) return '';
    const checked = ITEMS.filter(([k]) => perlengkapan?.[k]).map(([, l]) => l).join(', ') || '-';
    const unchecked = ITEMS.filter(([k]) => !perlengkapan?.[k]).map(([, l]) => l).join(', ') || '-';
    return [
      `Assalamualaikum, perlengkapan asrama untuk santri:`,
      `Nama: ${selected.nama}`,
      `NIS: ${selected.nis}`,
      `Lemari: #${selected.lemari_no}`,
      `Murobbi: ${murobbiObj?.nama || '-'}`,
      `--`,
      `Sudah lengkap: ${checked}`,
      `Masih kurang: ${unchecked}`,
    ].join('\n');
  };

  return (
    <DashboardShell title="Perlengkapan Asrama" subtitle="Lemari, kasur, alat tulis, dan pembagian murobbi">
      <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-4">
        <Card>
          <CardHeader className="pb-2">
            <div className="font-display font-semibold">Pilih Santri</div>
            <div className="relative mt-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari santri" className="pl-9" />
            </div>
          </CardHeader>
          <CardContent className="max-h-[480px] overflow-y-auto p-2">
            {loading ? (
              <div className="text-sm text-muted-foreground p-4">Memuat...</div>
            ) : filtered.map((s) => (
              <button
                type="button"
                key={s.id}
                onClick={() => { setSelectedId(s.id); setParams({ id: s.id }); }}
                data-testid={`${PERLENGKAPAN.santriSelect}-${s.nis}`}
                className={`w-full text-left rounded-lg px-3 py-2 mb-1 min-h-11 transition-colors ${selectedId === s.id ? 'bg-[hsl(var(--accent))]' : 'hover:bg-[hsl(var(--muted))]'}`}
              >
                <div className="flex items-center justify-between">
                  <div className="min-w-0">
                    <div className="text-sm font-semibold truncate">{s.nama}</div>
                    <div className="text-[11px] text-muted-foreground font-mono">NIS: {s.nis} · Lemari #{s.lemari_no}</div>
                  </div>
                  {s.perlengkapan?.all_delivered && <Badge className="bg-[hsl(var(--success))]/12 text-[hsl(var(--success))] border-[hsl(var(--success))]/25 text-[10px]">OK</Badge>}
                </div>
              </button>
            ))}
          </CardContent>
        </Card>

        <div className="space-y-4">
          {!selected || !perlengkapan ? (
            <Card><CardContent className="p-10 text-center text-muted-foreground">Pilih santri untuk mengelola perlengkapan.</CardContent></Card>
          ) : (
            <>
              <Card>
                <CardContent className="p-4 sm:p-5">
                  <div className="flex flex-wrap items-center gap-3 justify-between">
                    <div className="min-w-0">
                      <div className="font-display text-lg font-semibold truncate">{selected.nama}</div>
                      <div className="text-xs text-muted-foreground font-mono">NIS: {selected.nis}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">Lemari #{selected.lemari_no}</Badge>
                      <Badge variant="outline">Bet #{selected.bet_no}</Badge>
                    </div>
                  </div>
                  <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {ITEMS.map(([k, label]) => (
                      <label key={k} className="flex items-center gap-3 rounded-lg border bg-white px-3 py-2.5 min-h-11 cursor-pointer">
                        <Checkbox
                          checked={!!perlengkapan[k]}
                          onCheckedChange={(v) => setItem(k, !!v)}
                          data-testid={`${PERLENGKAPAN.itemCheckbox}-${k}`}
                        />
                        <span className="text-sm flex-1">{label}</span>
                        <Badge
                          className={`text-[10px] ${perlengkapan[k] ? 'bg-[hsl(var(--success))]/12 text-[hsl(var(--success))] border-[hsl(var(--success))]/25' : 'bg-transparent text-muted-foreground border-[hsl(var(--border))]'}`}
                        >
                          {perlengkapan[k] ? 'OK' : 'Belum'}
                        </Badge>
                      </label>
                    ))}
                  </div>
                  <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <div className="text-xs font-semibold text-muted-foreground">Pembagian Murobbi</div>
                      <Select value={murobbiId || ''} onValueChange={setMurobbiId}>
                        <SelectTrigger data-testid={PERLENGKAPAN.murobbiSelect}><SelectValue placeholder="Pilih murobbi" /></SelectTrigger>
                        <SelectContent>{murobbi.map((m) => <SelectItem key={m.id} value={m.id}>{m.nama}{m.wa ? ` · ${m.wa}` : ''}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-3 sm:p-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-2 sm:gap-3 justify-between">
                  <div className="text-xs text-muted-foreground flex items-center gap-2">
                    <BedDouble className="w-4 h-4" /> Beritahu petugas tentang status perlengkapan
                  </div>
                  <div className="flex items-center gap-2">
                    <a
                      href={targetPetugas?.wa_number ? buildWaLink(targetPetugas.wa_number, buildWaMessage()) : '#'}
                      target="_blank"
                      rel="noopener noreferrer"
                      data-testid={PERLENGKAPAN.waConfirm}
                      onClick={(e) => { if (!targetPetugas?.wa_number) { e.preventDefault(); toast.error('Belum ada petugas dengan nomor WA'); } }}
                    >
                      <Button variant="secondary" size="sm" className="gap-1.5"><MessageCircle className="w-4 h-4" /> Kirim ke Petugas</Button>
                    </a>
                    <Button data-testid={PERLENGKAPAN.save} size="sm" onClick={save} disabled={saving} className="gap-1.5 bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90 min-w-[120px]">
                      {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} Simpan
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </div>
    </DashboardShell>
  );
}
