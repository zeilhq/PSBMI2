import React, { useEffect, useState } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { api } from '@/lib/api';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DATA_DIRI } from '@/constants/testIds';
import { fileToCompressedDataUrl } from '@/lib/imageCompress';
import { toast } from 'sonner';
import { Loader2, ExternalLink, Camera, UserCircle2, Save } from 'lucide-react';

export default function DataDiri() {
  const [params] = useSearchParams();
  const id = params.get('id');
  const isEdit = !!id;
  const navigate = useNavigate();
  const [form, setForm] = useState({
    nis: '', nama: '', alamat: '', wali_nama: '', wali_wa: '', foto: '', murobbi_id: '',
  });
  const [murobbiList, setMurobbiList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [photoLoading, setPhotoLoading] = useState(false);
  const [psbLink, setPsbLink] = useState('https://psb.amtsilatipusat.com/admin');

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [mres, cres] = await Promise.all([
          api.get('/admin/murobbi'),
          api.get('/admin/config'),
        ]);
        if (cancelled) return;
        setMurobbiList(mres.data || []);
        if (cres?.data?.psb_admin_link) setPsbLink(cres.data.psb_admin_link);
      } catch (err) {
        // Non-blocking: form still usable without murobbi list or PSB link.
        console.warn('Optional config/murobbi load failed:', err);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!isEdit) return undefined;
    let cancelled = false;
    setLoading(true);
    (async () => {
      try {
        const { data } = await api.get(`/santri/${id}`);
        if (cancelled) return;
        setForm({
          nis: data.nis || '',
          nama: data.nama || '',
          alamat: data.alamat || '',
          wali_nama: data.wali_nama || '',
          wali_wa: data.wali_wa || '',
          foto: data.foto || '',
          murobbi_id: data.murobbi_id || '',
        });
      } catch (err) {
        if (cancelled) return;
        console.error('Failed to load santri:', err);
        toast.error('Santri tidak ditemukan');
        navigate('/santri');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [id, isEdit, navigate]);

  const change = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const handlePhoto = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPhotoLoading(true);
    try {
      const dataUrl = await fileToCompressedDataUrl(file);
      change('foto', dataUrl);
      toast.success('Foto siap diunggah');
    } catch (err) {
      toast.error('Gagal memproses foto');
    } finally {
      setPhotoLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.nis || !form.nama) {
      toast.error('NIS & Nama wajib diisi');
      return;
    }
    setSubmitting(true);
    try {
      const payload = { ...form, murobbi_id: form.murobbi_id || null };
      if (isEdit) {
        await api.put(`/santri/${id}`, payload);
        toast.success('Data santri diperbarui');
      } else {
        await api.post('/santri', payload);
        toast.success('Santri baru disimpan');
      }
      navigate('/santri');
    } catch (err) {
      toast.error(err?.response?.data?.detail || 'Gagal menyimpan');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <DashboardShell
      title={isEdit ? 'Edit Data Diri Santri' : 'Tambah Data Diri Santri'}
      subtitle="Pastikan data sesuai dengan PSB pusat"
      actions={
        <a href={psbLink} target="_blank" rel="noopener noreferrer" data-testid={DATA_DIRI.psbLink}>
          <Button variant="outline" size="sm" className="gap-1.5"><ExternalLink className="w-4 h-4" /> <span className="hidden sm:inline">PSB Admin</span></Button>
        </a>
      }
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <Card>
          <CardHeader className="pb-3">
            <div className="font-display font-semibold">Foto Santri</div>
            <div className="text-xs text-muted-foreground">Foto otomatis dikompres ke ukuran optimal untuk web (±400KB)</div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <Avatar className="w-20 h-20">
                <AvatarImage src={form.foto || ''} alt={form.nama || 'foto'} />
                <AvatarFallback className="bg-[hsl(var(--accent))] text-[hsl(var(--primary))]"><UserCircle2 className="w-9 h-9" /></AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <Label htmlFor="photo-upload" className="cursor-pointer">
                  <div className="inline-flex items-center gap-2 rounded-[var(--radius-md)] border bg-white hover:bg-[hsl(var(--muted))] px-3 py-2 text-sm font-medium transition-colors">
                    {photoLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Camera className="w-4 h-4" />}
                    Unggah Foto
                  </div>
                </Label>
                <input
                  id="photo-upload"
                  data-testid={DATA_DIRI.photo}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handlePhoto}
                  disabled={photoLoading}
                />
                <p className="text-[11px] text-muted-foreground mt-1">JPG/PNG, otomatis dikompres &amp; resize</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <div className="font-display font-semibold">Identitas Santri</div>
            <div className="text-xs text-muted-foreground">Petugas wajib memastikan data &amp; NIS sesuai dengan PSB pusat</div>
          </CardHeader>
          <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="nis">NIS</Label>
              <Input id="nis" data-testid={DATA_DIRI.nis} value={form.nis} onChange={(e) => change('nis', e.target.value)} placeholder="Contoh: 2025001" className="font-mono" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="nama">Nama Lengkap</Label>
              <Input id="nama" data-testid={DATA_DIRI.nama} value={form.nama} onChange={(e) => change('nama', e.target.value)} placeholder="Nama lengkap sesuai PSB" />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="alamat">Alamat <span className="text-muted-foreground">(opsional)</span></Label>
              <Textarea id="alamat" data-testid={DATA_DIRI.alamat} rows={2} value={form.alamat} onChange={(e) => change('alamat', e.target.value)} placeholder="Alamat lengkap" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <div className="font-display font-semibold">Data Wali Santri</div>
          </CardHeader>
          <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="wali_nama">Nama Wali Santri</Label>
              <Input id="wali_nama" data-testid={DATA_DIRI.waliNama} value={form.wali_nama} onChange={(e) => change('wali_nama', e.target.value)} placeholder="Nama orang tua/wali" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="wali_wa">Nomor WhatsApp Wali</Label>
              <Input id="wali_wa" data-testid={DATA_DIRI.waliWa} value={form.wali_wa} onChange={(e) => change('wali_wa', e.target.value)} placeholder="08xxxxxxxxxx" />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label>Murobbi yang Membimbing</Label>
              <Select value={form.murobbi_id || ''} onValueChange={(v) => change('murobbi_id', v)}>
                <SelectTrigger><SelectValue placeholder="Pilih murobbi (opsional, dapat diubah nanti)" /></SelectTrigger>
                <SelectContent>
                  {murobbiList.map((m) => (
                    <SelectItem key={m.id} value={m.id}>{m.nama}{m.wa ? ` — ${m.wa}` : ''}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <div className="sticky bottom-0 -mx-4 sm:mx-0 px-4 sm:px-0 py-3 bg-[hsl(var(--background))]/90 backdrop-blur border-t flex items-center justify-between">
          <Link to="/santri" className="text-sm text-muted-foreground hover:underline">← Kembali</Link>
          <Button data-testid={DATA_DIRI.save} type="submit" disabled={submitting || loading} className="gap-1.5 bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90 min-w-[140px]">
            {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {isEdit ? 'Simpan Perubahan' : 'Simpan Santri'}
          </Button>
        </div>
      </form>
    </DashboardShell>
  );
}
