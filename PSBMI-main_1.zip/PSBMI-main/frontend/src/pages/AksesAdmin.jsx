import React, { useCallback, useEffect, useState } from 'react';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { api } from '@/lib/api';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ADMIN_PAGE } from '@/constants/testIds';
import { Plus, Trash2, Save, Edit, Camera, Loader2, UserCog, BookOpen, FileText, Boxes } from 'lucide-react';
import { toast } from 'sonner';
import { fileToCompressedDataUrl } from '@/lib/imageCompress';
import { useAuth } from '@/context/AuthContext';
import { formatRupiah } from '@/lib/format';

const MENU_KEYS = [
  { key: 'dashboard', label: 'Dashboard' },
  { key: 'santri', label: 'Santri' },
  { key: 'data-diri', label: 'Data Diri' },
  { key: 'administrasi', label: 'Administrasi Asrama' },
  { key: 'seragam', label: 'Seragam' },
  { key: 'perlengkapan', label: 'Perlengkapan Asrama' },
  { key: 'name-tag', label: 'Name Tag / KTS' },
  { key: 'akses-admin', label: 'Akses Admin' },
];

function UserDialog({ initial, onSaved }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(() => ({
    username: initial?.username || '',
    password: '',
    nama: initial?.nama || '',
    role: initial?.role || 'petugas',
    wa_number: initial?.wa_number || '',
    profile_photo: initial?.profile_photo || '',
    permissions: initial?.permissions || MENU_KEYS.filter((m) => m.key !== 'akses-admin').map((m) => m.key),
    active: initial?.active ?? true,
  }));
  const [photoLoading, setPhotoLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const togglePerm = (k) => setForm((f) => ({ ...f, permissions: f.permissions.includes(k) ? f.permissions.filter((x) => x !== k) : [...f.permissions, k] }));

  const handlePhoto = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPhotoLoading(true);
    try {
      const url = await fileToCompressedDataUrl(file, { maxSizeMB: 0.2, maxWidthOrHeight: 512 });
      setForm((f) => ({ ...f, profile_photo: url }));
    } catch { toast.error('Gagal memproses foto'); } finally { setPhotoLoading(false); }
  };

  const submit = async () => {
    setSaving(true);
    try {
      if (initial) {
        const payload = { ...form };
        if (!payload.password) delete payload.password;
        await api.put(`/admin/users/${initial.id}`, payload);
        toast.success('User diperbarui');
      } else {
        if (!form.username || !form.password || !form.nama) {
          toast.error('Username, password, dan nama wajib diisi');
          setSaving(false);
          return;
        }
        await api.post('/admin/users', form);
        toast.success('User baru ditambahkan');
      }
      setOpen(false);
      onSaved && onSaved();
    } catch (e) {
      toast.error(e?.response?.data?.detail || 'Gagal menyimpan');
    } finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {initial ? (
          <Button variant="ghost" size="icon" aria-label="Edit"><Edit className="w-4 h-4" /></Button>
        ) : (
          <Button data-testid={ADMIN_PAGE.addUser} size="sm" className="gap-1.5 bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90">
            <Plus className="w-4 h-4" /> Tambah User
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-lg max-h-[90dvh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{initial ? 'Edit User' : 'Tambah User'}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="flex items-center gap-4">
            <Avatar className="w-16 h-16">
              <AvatarImage src={form.profile_photo || ''} />
              <AvatarFallback className="bg-[hsl(var(--accent))] text-[hsl(var(--primary))]"><UserCog className="w-7 h-7" /></AvatarFallback>
            </Avatar>
            <Label className="cursor-pointer">
              <div className="inline-flex items-center gap-2 rounded-md border bg-white hover:bg-[hsl(var(--muted))] px-3 py-2 text-xs font-medium">
                {photoLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Camera className="w-3.5 h-3.5" />} Unggah Foto
              </div>
              <input type="file" accept="image/*" className="hidden" onChange={handlePhoto} disabled={photoLoading} />
            </Label>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Username</Label>
              <Input value={form.username} onChange={(e) => setForm((f) => ({ ...f, username: e.target.value }))} disabled={!!initial} />
            </div>
            <div className="space-y-1.5">
              <Label>Password {initial && <span className="text-[11px] text-muted-foreground">(kosongkan jika tidak diubah)</span>}</Label>
              <Input type="password" value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label>Nama</Label>
              <Input value={form.nama} onChange={(e) => setForm((f) => ({ ...f, nama: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label>Role</Label>
              <Select value={form.role} onValueChange={(v) => setForm((f) => ({ ...f, role: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="petugas">Petugas</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5 col-span-2">
              <Label>No. WhatsApp</Label>
              <Input value={form.wa_number} onChange={(e) => setForm((f) => ({ ...f, wa_number: e.target.value }))} placeholder="628xxx" />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Hak Akses Menu</Label>
            <div className="grid grid-cols-2 gap-2">
              {MENU_KEYS.map((m) => (
                <label key={m.key} className="flex items-center justify-between gap-2 rounded-lg border px-3 py-2 text-sm">
                  <span>{m.label}</span>
                  <Switch checked={form.permissions.includes(m.key)} onCheckedChange={() => togglePerm(m.key)} />
                </label>
              ))}
            </div>
            {form.role === 'admin' && <p className="text-[11px] text-muted-foreground">Role admin otomatis memiliki seluruh akses.</p>}
          </div>
          {initial && (
            <label className="flex items-center justify-between gap-2 rounded-lg border px-3 py-2 text-sm">
              <span>Akun aktif</span>
              <Switch checked={form.active} onCheckedChange={(v) => setForm((f) => ({ ...f, active: v }))} />
            </label>
          )}
        </div>
        <DialogFooter>
          <DialogClose asChild><Button variant="ghost">Batal</Button></DialogClose>
          <Button data-testid={ADMIN_PAGE.saveButton} onClick={submit} disabled={saving} className="bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90 gap-1.5">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} Simpan
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function MurobbiDialog({ initial, onSaved }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ nama: initial?.nama || '', wa: initial?.wa || '' });
  const [saving, setSaving] = useState(false);
  const submit = async () => {
    setSaving(true);
    try {
      if (initial) await api.put(`/admin/murobbi/${initial.id}`, form);
      else await api.post('/admin/murobbi', form);
      toast.success('Murobbi tersimpan');
      setOpen(false);
      onSaved && onSaved();
    } catch (e) { toast.error(e?.response?.data?.detail || 'Gagal'); } finally { setSaving(false); }
  };
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {initial ? <Button variant="ghost" size="icon"><Edit className="w-4 h-4" /></Button> : <Button data-testid={ADMIN_PAGE.addMurobbi} size="sm" className="gap-1.5 bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90"><Plus className="w-4 h-4" /> Tambah Murobbi</Button>}
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>{initial ? 'Edit Murobbi' : 'Tambah Murobbi'}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>Nama Murobbi</Label>
            <Input value={form.nama} onChange={(e) => setForm((f) => ({ ...f, nama: e.target.value }))} />
          </div>
          <div className="space-y-1.5">
            <Label>No. WhatsApp</Label>
            <Input value={form.wa} onChange={(e) => setForm((f) => ({ ...f, wa: e.target.value }))} placeholder="628xxx" />
          </div>
        </div>
        <DialogFooter>
          <DialogClose asChild><Button variant="ghost">Batal</Button></DialogClose>
          <Button onClick={submit} disabled={saving} className="bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90 gap-1.5">{saving && <Loader2 className="w-4 h-4 animate-spin" />} Simpan</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function AksesAdmin() {
  const { user } = useAuth();
  const [users, setUsers] = useState([]);
  const [murobbi, setMurobbi] = useState([]);
  const [config, setConfig] = useState(null);
  const [feesDraft, setFeesDraft] = useState([]);
  const [betDraft, setBetDraft] = useState(1001);
  const [lemariDraft, setLemariDraft] = useState(1);
  const [psbDraft, setPsbDraft] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [u, m, c] = await Promise.all([
        api.get('/admin/users'),
        api.get('/admin/murobbi'),
        api.get('/admin/config'),
      ]);
      setUsers(u.data || []);
      setMurobbi(m.data || []);
      setConfig(c.data || {});
      setFeesDraft(c.data?.admin_fees || []);
      setBetDraft(c.data?.starting_bet_no || 1001);
      setLemariDraft(c.data?.starting_lemari_no || 1);
      setPsbDraft(c.data?.psb_admin_link || '');
    } catch (err) {
      console.error('Failed to load admin data:', err);
      toast.error('Gagal memuat data admin');
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  const saveConfig = async () => {
    setSaving(true);
    try {
      const payload = {
        admin_fees: feesDraft.map((f) => ({ key: f.key, name: f.name, price: Number(f.price) || 0 })),
        starting_bet_no: Number(betDraft) || 1,
        starting_lemari_no: Number(lemariDraft) || 1,
        psb_admin_link: psbDraft,
      };
      const { data } = await api.put('/admin/config', payload);
      setConfig(data);
      toast.success('Konfigurasi tersimpan');
    } catch (e) {
      toast.error('Gagal menyimpan konfigurasi');
    } finally { setSaving(false); }
  };

  const updateFee = (idx, field, val) => {
    setFeesDraft((cur) => cur.map((f, i) => i === idx ? { ...f, [field]: field === 'price' ? Number(val) || 0 : val } : f));
  };
  const addFee = () => setFeesDraft((cur) => [...cur, { key: `custom_${Date.now()}`, name: 'Item Baru', price: 0 }]);
  const removeFee = (idx) => setFeesDraft((cur) => cur.filter((_, i) => i !== idx));

  const deleteUser = async (u) => {
    try { await api.delete(`/admin/users/${u.id}`); toast.success('User dihapus'); loadAll(); }
    catch (e) { toast.error(e?.response?.data?.detail || 'Gagal menghapus'); }
  };
  const deleteMurobbi = async (m) => {
    try { await api.delete(`/admin/murobbi/${m.id}`); toast.success('Murobbi dihapus'); loadAll(); }
    catch (e) { toast.error('Gagal menghapus'); }
  };

  return (
    <DashboardShell title="Akses Admin" subtitle="Kelola user, hak akses, biaya administrasi, murobbi, dan konfigurasi">
      <Tabs defaultValue="users">
        <TabsList className="grid grid-cols-4 max-w-2xl">
          <TabsTrigger value="users" data-testid={ADMIN_PAGE.tabUsers}>Users</TabsTrigger>
          <TabsTrigger value="fees" data-testid={ADMIN_PAGE.tabFees}>Biaya</TabsTrigger>
          <TabsTrigger value="murobbi" data-testid={ADMIN_PAGE.tabMurobbi}>Murobbi</TabsTrigger>
          <TabsTrigger value="config" data-testid={ADMIN_PAGE.tabConfig}>Konfigurasi</TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="mt-4">
          <Card>
            <CardHeader className="pb-3 flex flex-row items-center justify-between">
              <div>
                <div className="font-display font-semibold">Daftar User & Petugas</div>
                <div className="text-xs text-muted-foreground">Atur hak akses menu per user</div>
              </div>
              <UserDialog onSaved={loadAll} />
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y">
                {users.map((u) => (
                  <div key={u.id} className="flex items-center gap-3 px-4 py-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={u.profile_photo || ''} />
                      <AvatarFallback className="bg-[hsl(var(--accent))] text-[hsl(var(--primary))] text-xs font-semibold">
                        {(u.nama || '?').split(' ').slice(0, 2).map((p) => p[0]).join('').toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold truncate">{u.nama}</div>
                      <div className="text-[11px] text-muted-foreground flex items-center gap-2">
                        <Badge variant="outline" className="capitalize text-[10px]">{u.role}</Badge>
                        <span>@{u.username}</span>
                        {!u.active && <Badge className="bg-red-50 text-red-600 border-red-200 text-[10px]">Nonaktif</Badge>}
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      <UserDialog initial={u} onSaved={loadAll} />
                      {u.id !== user?.id && (
                        <AlertDialog>
                          <AlertDialogTrigger asChild><Button variant="ghost" size="icon" className="text-[hsl(var(--destructive))]"><Trash2 className="w-4 h-4" /></Button></AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Hapus user {u.nama}?</AlertDialogTitle>
                              <AlertDialogDescription>Tindakan ini tidak dapat dibatalkan.</AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Batal</AlertDialogCancel>
                              <AlertDialogAction onClick={() => deleteUser(u)} className="bg-[hsl(var(--destructive))] hover:bg-[hsl(var(--destructive))]/90">Hapus</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      )}
                    </div>
                  </div>
                ))}
                {users.length === 0 && <div className="p-8 text-center text-sm text-muted-foreground">Belum ada user.</div>}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="fees" className="mt-4">
          <Card>
            <CardHeader className="pb-3 flex flex-row items-center justify-between">
              <div>
                <div className="font-display font-semibold">Biaya Administrasi</div>
                <div className="text-xs text-muted-foreground">Ubah biaya tiap item. Total: <span className="font-display font-semibold">{formatRupiah(feesDraft.reduce((a, b) => a + (Number(b.price) || 0), 0))}</span></div>
              </div>
              <Button onClick={addFee} variant="outline" size="sm" className="gap-1.5"><Plus className="w-4 h-4" /> Tambah Item</Button>
            </CardHeader>
            <CardContent className="space-y-2">
              {feesDraft.map((f, i) => (
                <div key={f.key + i} className="grid grid-cols-1 sm:grid-cols-[1fr_180px_auto] gap-2 items-center">
                  <Input value={f.name} onChange={(e) => updateFee(i, 'name', e.target.value)} placeholder="Nama item" />
                  <Input type="number" value={f.price} onChange={(e) => updateFee(i, 'price', e.target.value)} placeholder="0" className="tabular-nums" />
                  <Button variant="ghost" size="icon" onClick={() => removeFee(i)} className="text-[hsl(var(--destructive))]"><Trash2 className="w-4 h-4" /></Button>
                </div>
              ))}
              <div className="pt-2 flex justify-end">
                <Button onClick={saveConfig} disabled={saving} className="bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90 gap-1.5" data-testid={ADMIN_PAGE.saveButton}>
                  {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} Simpan Biaya
                </Button>
              </div>
              <p className="text-[11px] text-muted-foreground">Catatan: perubahan biaya akan berlaku untuk santri yang ditambahkan setelahnya. Untuk santri lama, harga lama tetap berlaku kecuali diubah manual.</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="murobbi" className="mt-4">
          <Card>
            <CardHeader className="pb-3 flex flex-row items-center justify-between">
              <div>
                <div className="font-display font-semibold">Daftar Murobbi</div>
                <div className="text-xs text-muted-foreground">Nama & nomor WA murobbi pesantren</div>
              </div>
              <MurobbiDialog onSaved={loadAll} />
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y">
                {murobbi.map((m) => (
                  <div key={m.id} className="flex items-center gap-3 px-4 py-3">
                    <div className="w-9 h-9 rounded-full bg-[hsl(var(--accent))] text-[hsl(var(--primary))] flex items-center justify-center text-xs font-semibold">
                      {(m.nama || '?').split(' ').slice(0, 2).map((p) => p[0]).join('').toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold truncate">{m.nama}</div>
                      <div className="text-[11px] text-muted-foreground">{m.wa || '-'}</div>
                    </div>
                    <MurobbiDialog initial={m} onSaved={loadAll} />
                    <AlertDialog>
                      <AlertDialogTrigger asChild><Button variant="ghost" size="icon" className="text-[hsl(var(--destructive))]"><Trash2 className="w-4 h-4" /></Button></AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Hapus murobbi {m.nama}?</AlertDialogTitle>
                          <AlertDialogDescription>Santri yang masih terhubung perlu di-assign ulang.</AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Batal</AlertDialogCancel>
                          <AlertDialogAction onClick={() => deleteMurobbi(m)} className="bg-[hsl(var(--destructive))] hover:bg-[hsl(var(--destructive))]/90">Hapus</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                ))}
                {murobbi.length === 0 && <div className="p-8 text-center text-sm text-muted-foreground">Belum ada murobbi.</div>}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="config" className="mt-4 space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="font-display font-semibold">Konfigurasi Sistem</div>
              <div className="text-xs text-muted-foreground">Nomor awal bet nama, lemari, dan link PSB Admin</div>
            </CardHeader>
            <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Nomor Awal Bet Nama</Label>
                <Input type="number" value={betDraft} onChange={(e) => setBetDraft(e.target.value)} className="tabular-nums" />
              </div>
              <div className="space-y-1.5">
                <Label>Nomor Awal Lemari</Label>
                <Input type="number" value={lemariDraft} onChange={(e) => setLemariDraft(e.target.value)} className="tabular-nums" />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label>Link PSB Admin Pusat</Label>
                <Input value={psbDraft} onChange={(e) => setPsbDraft(e.target.value)} placeholder="https://psb.amtsilatipusat.com/admin" />
              </div>
              <div className="sm:col-span-2 flex justify-end">
                <Button onClick={saveConfig} disabled={saving} className="bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90 gap-1.5">
                  {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} Simpan Konfigurasi
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <div className="font-display font-semibold">Dokumentasi API & Developer Tools</div>
              <div className="text-xs text-muted-foreground">Akses dokumentasi API lengkap (Swagger), file SQL schema, dan koleksi Postman</div>
            </CardHeader>
            <CardContent className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <a
                href={`${process.env.REACT_APP_BACKEND_URL}/api/docs`}
                target="_blank"
                rel="noopener noreferrer"
                data-testid="admin-api-docs-link"
              >
                <div className="rounded-lg border bg-white p-4 hover:border-[hsl(var(--primary))] hover:shadow-[var(--shadow-sm)] transition-all h-full">
                  <div className="flex items-center gap-2 mb-1">
                    <BookOpen className="w-4 h-4 text-[hsl(var(--primary))]" />
                    <div className="font-display font-semibold text-sm">Swagger UI</div>
                  </div>
                  <div className="text-[11px] text-muted-foreground">Dokumentasi interaktif semua endpoint REST API</div>
                  <div className="text-[10px] text-muted-foreground mt-2 font-mono truncate">/api/docs</div>
                </div>
              </a>
              <div className="rounded-lg border bg-white p-4 h-full">
                <div className="flex items-center gap-2 mb-1">
                  <FileText className="w-4 h-4 text-[hsl(var(--primary))]" />
                  <div className="font-display font-semibold text-sm">SQL Schema</div>
                </div>
                <div className="text-[11px] text-muted-foreground">Skema SQL siap import ke phpMyAdmin sebagai cadangan</div>
                <div className="text-[10px] text-muted-foreground mt-2 font-mono truncate">/app/docs/schema.sql</div>
              </div>
              <div className="rounded-lg border bg-white p-4 h-full">
                <div className="flex items-center gap-2 mb-1">
                  <Boxes className="w-4 h-4 text-[hsl(var(--primary))]" />
                  <div className="font-display font-semibold text-sm">Postman Collection</div>
                </div>
                <div className="text-[11px] text-muted-foreground">Koleksi siap import ke Postman dengan auto-token</div>
                <div className="text-[10px] text-muted-foreground mt-2 font-mono truncate">/app/docs/postman_collection.json</div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </DashboardShell>
  );
}
