import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { api } from '@/lib/api';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { SANTRI } from '@/constants/testIds';
import { formatRupiah, buildWaLink } from '@/lib/format';
import { Search, Plus, MessageCircle, MapPin, IdCard, Trash2 } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { useAuth } from '@/context/AuthContext';

function SantriCard({ s, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      data-testid={`${SANTRI.openModal}-${s.nis}`}
      className="text-left rounded-[var(--radius-lg)] border bg-white shadow-[var(--shadow-sm)] hover:shadow-[var(--shadow-md)] transition-shadow overflow-hidden focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--ring))] focus-visible:ring-offset-2"
    >
      <div className="aspect-[4/3] bg-[hsl(var(--muted))] overflow-hidden">
        {s.foto ? (
          <img src={s.foto} alt={s.nama} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-muted-foreground">
            <Avatar className="w-20 h-20">
              <AvatarFallback className="bg-[hsl(var(--accent))] text-[hsl(var(--primary))] text-2xl font-display font-semibold">
                {(s.nama || '?').split(' ').slice(0, 2).map((p) => p[0]).join('').toUpperCase()}
              </AvatarFallback>
            </Avatar>
          </div>
        )}
      </div>
      <div className="p-3">
        <div className="flex items-center gap-1.5 text-[11px] font-mono text-muted-foreground">
          <IdCard className="w-3 h-3" />
          NIS: {s.nis}
        </div>
        <div className="font-display font-semibold text-sm truncate mt-0.5">{s.nama}</div>
        <div className="text-[11px] text-muted-foreground flex items-start gap-1 mt-0.5 line-clamp-2">
          <MapPin className="w-3 h-3 mt-0.5 shrink-0" />
          {s.alamat || '-'}
        </div>
        <div className="mt-2 flex items-center gap-1.5 flex-wrap">
          <Badge variant="outline" className="text-[10px] px-1.5 py-0">Bet #{s.bet_no}</Badge>
          <Badge variant="outline" className="text-[10px] px-1.5 py-0">Lemari #{s.lemari_no}</Badge>
          {s.seragam?.all_delivered && (
            <Badge className="bg-[hsl(var(--success))]/12 text-[hsl(var(--success))] border-[hsl(var(--success))]/25 text-[10px] px-1.5 py-0">Seragam OK</Badge>
          )}
        </div>
      </div>
    </button>
  );
}

function SantriDetailModal({ s, open, onClose, onDelete }) {
  const { user } = useAuth();
  if (!s) return null;
  const adminItems = s.administrasi || [];
  const totalTagihan = adminItems.reduce((a, b) => a + Number(b.price || 0), 0);
  const paidTagihan = adminItems.filter((x) => x.paid).reduce((a, b) => a + Number(b.price || 0), 0);
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent data-testid={SANTRI.modal} className="max-w-2xl p-0 overflow-hidden">
        <div className="grid grid-cols-1 sm:grid-cols-[180px_1fr] gap-0">
          <div className="bg-[hsl(var(--muted))] aspect-square sm:aspect-auto sm:h-full overflow-hidden">
            {s.foto ? (
              <img src={s.foto} alt={s.nama} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <Avatar className="w-24 h-24">
                  <AvatarFallback className="bg-[hsl(var(--accent))] text-[hsl(var(--primary))] text-3xl font-display font-semibold">
                    {(s.nama || '?').split(' ').slice(0, 2).map((p) => p[0]).join('').toUpperCase()}
                  </AvatarFallback>
                </Avatar>
              </div>
            )}
          </div>
          <div className="p-4 sm:p-5">
            <DialogHeader className="text-left">
              <DialogTitle className="font-display text-xl">{s.nama}</DialogTitle>
              <DialogDescription className="font-mono text-xs">NIS: {s.nis}</DialogDescription>
            </DialogHeader>
            <Tabs defaultValue="profil" className="mt-3">
              <TabsList className="w-full grid grid-cols-4 h-9">
                <TabsTrigger value="profil" className="text-xs">Profil</TabsTrigger>
                <TabsTrigger value="administrasi" className="text-xs">Administrasi</TabsTrigger>
                <TabsTrigger value="seragam" className="text-xs">Seragam</TabsTrigger>
                <TabsTrigger value="perlengkapan" className="text-xs">Perlengkapan</TabsTrigger>
              </TabsList>
              <TabsContent value="profil" className="text-sm space-y-2 mt-3">
                <Row label="NIS" value={s.nis} mono />
                <Row label="Nama Lengkap" value={s.nama} />
                <Row label="Alamat" value={s.alamat || '-'} />
                <Row label="Wali Santri" value={s.wali_nama || '-'} />
                <Row label="Nomor Wali" value={s.wali_wa || '-'} />
                <Row label="Nomor Bet" value={`#${s.bet_no}`} />
                <Row label="Lemari" value={`#${s.lemari_no}`} />
                {s.wali_wa && (
                  <a
                    href={buildWaLink(s.wali_wa, `Assalamualaikum, Bpk/Ibu wali dari ananda ${s.nama} (NIS ${s.nis}). Kami dari Pondok Pesantren Amtsilati ingin menyampaikan informasi.`)}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Button size="sm" variant="secondary" className="gap-1.5 mt-2">
                      <MessageCircle className="w-3.5 h-3.5" /> Hubungi Wali
                    </Button>
                  </a>
                )}
              </TabsContent>
              <TabsContent value="administrasi" className="text-sm space-y-2 mt-3">
                <div className="flex items-center justify-between">
                  <div className="text-xs text-muted-foreground">Total tagihan</div>
                  <div className="font-display tabular-nums font-semibold">{formatRupiah(totalTagihan)}</div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="text-xs text-muted-foreground">Dibayar</div>
                  <div className="font-display tabular-nums font-semibold text-[hsl(var(--success))]">{formatRupiah(paidTagihan)}</div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="text-xs text-muted-foreground">Sisa</div>
                  <div className="font-display tabular-nums font-semibold text-[hsl(var(--pending))]">{formatRupiah(totalTagihan - paidTagihan)}</div>
                </div>
                <div className="pt-2 space-y-1.5">
                  {adminItems.map((it) => (
                    <div key={it.key} className="flex items-center justify-between text-xs">
                      <span className="flex-1">{it.name}</span>
                      <span className="tabular-nums">{formatRupiah(it.price)}</span>
                      <Badge
                        className={`ml-2 text-[10px] ${it.paid ? 'bg-[hsl(var(--success))]/12 text-[hsl(var(--success))] border-[hsl(var(--success))]/25' : 'bg-transparent text-muted-foreground border-[hsl(var(--border))]'}`}
                      >
                        {it.paid ? 'LUNAS' : 'BELUM'}
                      </Badge>
                    </div>
                  ))}
                </div>
                <Link to={`/administrasi?id=${s.id}`}><Button size="sm" variant="outline" className="mt-2">Kelola Pembayaran</Button></Link>
              </TabsContent>
              <TabsContent value="seragam" className="text-sm space-y-2 mt-3">
                {['biru', 'ungu', 'coklat'].map((c) => (
                  <div key={c} className="flex items-center justify-between text-xs">
                    <div>
                      <span className="capitalize font-semibold">{c}</span>
                      <span className="text-muted-foreground"> · Sergm {s.seragam?.[c]?.ukuran_seragam || '-'} / Sarung {s.seragam?.[c]?.ukuran_sarung || '-'}</span>
                    </div>
                    <Badge className={s.seragam?.[c]?.delivered ? 'bg-[hsl(var(--success))]/12 text-[hsl(var(--success))] border-[hsl(var(--success))]/25' : 'bg-transparent text-muted-foreground border-[hsl(var(--border))]'}>
                      {s.seragam?.[c]?.delivered ? 'OK' : 'BELUM'}
                    </Badge>
                  </div>
                ))}
                <Link to={`/seragam?id=${s.id}`}><Button size="sm" variant="outline" className="mt-2">Kelola Seragam</Button></Link>
              </TabsContent>
              <TabsContent value="perlengkapan" className="text-sm space-y-2 mt-3">
                {[
                  ['kasur', 'Kasur'],
                  ['bantal', 'Bantal'],
                  ['guling', 'Guling'],
                  ['sarung_bantal_guling', 'Sarung bantal/guling'],
                  ['alat_tulis', 'Alat Tulis'],
                  ['yanbua', 'Yanbua'],
                ].map(([k, label]) => (
                  <div key={k} className="flex items-center justify-between text-xs">
                    <span>{label}</span>
                    <Badge className={s.perlengkapan?.[k] ? 'bg-[hsl(var(--success))]/12 text-[hsl(var(--success))] border-[hsl(var(--success))]/25' : 'bg-transparent text-muted-foreground border-[hsl(var(--border))]'}>
                      {s.perlengkapan?.[k] ? 'OK' : 'BELUM'}
                    </Badge>
                  </div>
                ))}
                <Link to={`/perlengkapan?id=${s.id}`}><Button size="sm" variant="outline" className="mt-2">Kelola Perlengkapan</Button></Link>
              </TabsContent>
            </Tabs>
          </div>
        </div>
        <DialogFooter className="p-4 border-t bg-[hsl(var(--background))]">
          {(user?.role === 'admin' || (user?.permissions || []).includes('data-diri')) && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="ghost" size="sm" className="text-[hsl(var(--destructive))] gap-1" data-testid={`${SANTRI.deleteButton}-${s.nis}`}>
                  <Trash2 className="w-3.5 h-3.5" /> Hapus
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Hapus santri {s.nama}?</AlertDialogTitle>
                  <AlertDialogDescription>Tindakan ini tidak dapat dibatalkan. Data administrasi, seragam, perlengkapan, dan name tag terkait juga akan dihapus.</AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Batal</AlertDialogCancel>
                  <AlertDialogAction onClick={() => onDelete(s)} className="bg-[hsl(var(--destructive))] hover:bg-[hsl(var(--destructive))]/90">Hapus</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
          <Link to={`/data-diri?id=${s.id}`}><Button variant="outline" size="sm">Edit Data</Button></Link>
          <DialogClose asChild>
            <Button size="sm" data-testid={SANTRI.modalClose}>Tutup</Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Row({ label, value, mono }) {
  return (
    <div className="flex items-start gap-3">
      <div className="w-28 text-xs text-muted-foreground">{label}</div>
      <div className={`flex-1 text-sm ${mono ? 'font-mono' : ''}`}>{value || '-'}</div>
    </div>
  );
}

export default function Santri() {
  const [list, setList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState('');
  const [openId, setOpenId] = useState(null);
  const navigate = useNavigate();

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/santri');
      setList(data || []);
    } catch (err) {
      console.error('Failed to load santri:', err);
      toast.error('Gagal memuat data santri');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return list;
    return list.filter((x) =>
      (x.nama || '').toLowerCase().includes(s) ||
      (x.nis || '').toLowerCase().includes(s) ||
      (x.alamat || '').toLowerCase().includes(s)
    );
  }, [list, q]);

  const selected = list.find((x) => x.id === openId) || null;

  const handleDelete = async (s) => {
    try {
      await api.delete(`/santri/${s.id}`);
      toast.success(`Santri ${s.nama} dihapus`);
      setOpenId(null);
      load();
    } catch (e) {
      toast.error(e?.response?.data?.detail || 'Gagal menghapus santri');
    }
  };

  return (
    <DashboardShell
      title="Daftar Santri"
      subtitle="Klik kartu untuk melihat detail lengkap"
      actions={
        <Link to="/data-diri">
          <Button size="sm" className="gap-1.5 bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90">
            <Plus className="w-4 h-4" /> <span className="hidden sm:inline">Tambah</span>
          </Button>
        </Link>
      }
    >
      <div className="sticky top-[57px] z-10 bg-[hsl(var(--background))]/85 backdrop-blur -mx-4 px-4 sm:-mx-6 sm:px-6 py-3 border-b">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            data-testid={SANTRI.search}
            placeholder="Cari nama, NIS, atau alamat..."
            className="pl-9 min-h-11"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
        {(() => {
          if (loading) {
            return ['s1', 's2', 's3', 's4', 's5', 's6'].map((k) => (
              <div key={`santri-skel-${k}`} className="rounded-[var(--radius-lg)] border bg-white overflow-hidden">
                <Skeleton className="aspect-[4/3] w-full" />
                <div className="p-3 space-y-1.5">
                  <Skeleton className="h-3 w-1/2" />
                  <Skeleton className="h-4 w-3/4" />
                </div>
              </div>
            ));
          }
          if (filtered.length === 0) {
            const emptyText = q ? 'Tidak ada santri yang cocok.' : 'Belum ada santri terdaftar.';
            return (
              <Card className="col-span-full">
                <CardContent className="p-10 text-center">
                  <div className="text-sm text-muted-foreground mb-3">{emptyText}</div>
                  <Link to="/data-diri"><Button>Tambah Santri Pertama</Button></Link>
                </CardContent>
              </Card>
            );
          }
          return filtered.map((s) => (
            <SantriCard key={s.id} s={s} onClick={() => setOpenId(s.id)} />
          ));
        })()}
      </div>

      <SantriDetailModal s={selected} open={!!selected} onClose={() => setOpenId(null)} onDelete={handleDelete} />
    </DashboardShell>
  );
}
