import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { api, API_BASE } from '@/lib/api';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { ADMINISTRASI } from '@/constants/testIds';
import { formatRupiah } from '@/lib/format';
import { Printer, Loader2, Search, FileText } from 'lucide-react';
import { toast } from 'sonner';

export default function Administrasi() {
  const [params, setParams] = useSearchParams();
  const initialId = params.get('id') || '';
  const [list, setList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState(initialId);
  const [printing, setPrinting] = useState(false);
  const [q, setQ] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/santri');
      setList(data || []);
      if (data && data.length > 0) {
        setSelectedId((curr) => curr || data[0].id);
      }
    } catch (err) {
      console.error('Failed to load santri:', err);
      toast.error('Gagal memuat data santri');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return list;
    return list.filter((x) =>
      (x.nama || '').toLowerCase().includes(s) ||
      (x.nis || '').toLowerCase().includes(s)
    );
  }, [list, q]);

  const selected = list.find((x) => x.id === selectedId);
  const items = selected?.administrasi || [];
  const total = items.reduce((a, b) => a + Number(b.price || 0), 0);
  const paid = items.filter((x) => x.paid).reduce((a, b) => a + Number(b.price || 0), 0);
  const remaining = total - paid;
  const percent = total > 0 ? Math.round((paid / total) * 100) : 0;

  const togglePaid = async (key, paidVal) => {
    if (!selected) return;
    try {
      const { data } = await api.post(`/santri/${selected.id}/administrasi/toggle`, { key, paid: paidVal });
      // Update local list with the fresh items
      setList((cur) => cur.map((x) => x.id === selected.id ? { ...x, administrasi: data.administrasi } : x));
      toast.success(`Status pembayaran diperbarui`);
    } catch (e) {
      toast.error(e?.response?.data?.detail || 'Gagal memperbarui');
    }
  };

  const handlePrintKwitansi = async () => {
    if (!selected) return;
    setPrinting(true);
    try {
      const token = localStorage.getItem('amtsilati_token');
      const url = `${API_BASE}/santri/${selected.id}/kwitansi.pdf`;
      const resp = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
      if (!resp.ok) throw new Error('Gagal generate PDF');
      const blob = await resp.blob();
      const objectUrl = URL.createObjectURL(blob);
      // Open in new tab for print
      const w = window.open(objectUrl, '_blank');
      if (!w) {
        // Fallback: download
        const a = document.createElement('a');
        a.href = objectUrl;
        a.download = `kwitansi-${selected.nis}.pdf`;
        a.click();
      }
      toast.success('Kwitansi siap dicetak');
    } catch (e) {
      toast.error('Gagal menyiapkan kwitansi PDF');
    } finally {
      setPrinting(false);
    }
  };

  return (
    <DashboardShell title="Administrasi Asrama" subtitle="Catat pembayaran per santri & cetak kwitansi PDF">
      <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-4">
        {/* Santri picker */}
        <Card className="rounded-[var(--radius-lg)]">
          <CardHeader className="pb-2">
            <div className="font-display font-semibold">Pilih Santri</div>
            <div className="relative mt-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari santri" className="pl-9" />
            </div>
          </CardHeader>
          <CardContent className="max-h-[480px] overflow-y-auto p-2">
            {(() => {
              if (loading) return <div className="text-sm text-muted-foreground p-4">Memuat...</div>;
              if (filtered.length === 0) return <div className="text-sm text-muted-foreground p-4">Tidak ada santri</div>;
              return filtered.map((s) => {
                const p = (s.administrasi || []).filter((x) => x.paid).length;
                const t = (s.administrasi || []).length;
                const isActive = selectedId === s.id;
                return (
                  <button
                    type="button"
                    key={s.id}
                    onClick={() => { setSelectedId(s.id); setParams({ id: s.id }); }}
                    data-testid={`${ADMINISTRASI.santriSelect}-${s.nis}`}
                    className={`w-full text-left rounded-lg px-3 py-2 mb-1 min-h-11 transition-colors ${isActive ? 'bg-[hsl(var(--accent))]' : 'hover:bg-[hsl(var(--muted))]'}`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="min-w-0">
                        <div className="text-sm font-semibold truncate">{s.nama}</div>
                        <div className="text-[11px] text-muted-foreground font-mono">NIS: {s.nis}</div>
                      </div>
                      <Badge variant="outline" className="text-[10px]">{p}/{t}</Badge>
                    </div>
                  </button>
                );
              });
            })()}
          </CardContent>
        </Card>

        {/* Detail */}
        <div className="space-y-4">
          {!selected ? (
            <Card><CardContent className="p-10 text-center text-muted-foreground">Pilih santri untuk mengelola administrasi.</CardContent></Card>
          ) : (
            <>
              <Card>
                <CardContent className="p-4 sm:p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="font-display text-lg font-semibold truncate">{selected.nama}</div>
                      <div className="text-xs text-muted-foreground font-mono">NIS: {selected.nis}</div>
                    </div>
                    <Button
                      data-testid={ADMINISTRASI.print}
                      disabled={printing}
                      onClick={handlePrintKwitansi}
                      className="gap-1.5 bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90 min-w-[160px]"
                    >
                      {printing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Printer className="w-4 h-4" />}
                      Cetak Kwitansi PDF
                    </Button>
                  </div>
                  <div className="grid grid-cols-3 gap-3 mt-4">
                    <Stat label="Total Tagihan" value={formatRupiah(total)} />
                    <Stat label="Sudah Dibayar" value={formatRupiah(paid)} variant="success" />
                    <Stat label="Sisa" value={formatRupiah(remaining)} variant="pending" />
                  </div>
                  <div className="mt-3">
                    <Progress value={percent} className="h-2" />
                    <div className="text-[11px] text-muted-foreground mt-1">{percent}% terlunasi</div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-2 sm:p-3">
                  {items.map((it) => (
                    <div key={it.key} className="flex items-center gap-3 px-3 py-3 rounded-lg hover:bg-[hsl(var(--muted))]/60 min-h-11">
                      <Checkbox
                        id={`fee-${it.key}`}
                        checked={!!it.paid}
                        onCheckedChange={(v) => togglePaid(it.key, !!v)}
                        data-testid={`${ADMINISTRASI.feeCheckbox}-${it.key}`}
                      />
                      <label htmlFor={`fee-${it.key}`} className="flex-1 text-sm cursor-pointer">
                        <div className="font-medium">{it.name}</div>
                        {it.paid && it.paid_at && (
                          <div className="text-[11px] text-muted-foreground">Dibayar: {new Date(it.paid_at).toLocaleString('id-ID')}</div>
                        )}
                      </label>
                      <div className="font-display font-semibold tabular-nums text-sm">{formatRupiah(it.price)}</div>
                      <Badge
                        className={it.paid ? 'bg-[hsl(var(--success))]/12 text-[hsl(var(--success))] border-[hsl(var(--success))]/25' : 'bg-transparent text-muted-foreground border-[hsl(var(--border))]'}
                      >
                        {it.paid ? 'LUNAS' : 'BELUM'}
                      </Badge>
                    </div>
                  ))}
                  {items.length === 0 && (
                    <div className="text-sm text-muted-foreground p-6 text-center flex flex-col items-center gap-2">
                      <FileText className="w-8 h-8 opacity-50" />
                      Belum ada item biaya. Konfigurasi biaya di menu Akses Admin.
                    </div>
                  )}
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </div>
    </DashboardShell>
  );
}

function Stat({ label, value, variant }) {
  const colors = {
    success: 'text-[hsl(var(--success))]',
    pending: 'text-[hsl(var(--pending))]',
  }[variant] || '';
  return (
    <div className="rounded-lg border p-3 bg-white">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">{label}</div>
      <div className={`font-display font-semibold text-sm sm:text-base mt-0.5 tabular-nums ${colors}`}>{value}</div>
    </div>
  );
}
