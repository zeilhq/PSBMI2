import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { api } from '@/lib/api';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { SERAGAM } from '@/constants/testIds';
import { buildWaLink } from '@/lib/format';
import { Save, MessageCircle, Search, Loader2, Shirt } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/context/AuthContext';

const SET_KEYS = [
  { key: 'biru', label: 'Seragam Biru', dotClass: 'bg-blue-500' },
  { key: 'ungu', label: 'Seragam Ungu', dotClass: 'bg-purple-500' },
  { key: 'coklat', label: 'Seragam Coklat', dotClass: 'bg-amber-700' },
];

const SIZE_OPTIONS = ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL'];
const SARUNG_OPTIONS = ['Standar', 'Panjang', 'Pendek', 'Kecil', 'Besar'];

export default function Seragam() {
  const [params, setParams] = useSearchParams();
  const initialId = params.get('id') || '';
  const { user } = useAuth();
  const [list, setList] = useState([]);
  const [petugasList, setPetugasList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState(initialId);
  const [saving, setSaving] = useState(false);
  const [q, setQ] = useState('');
  const [seragam, setSeragam] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [s, d] = await Promise.all([api.get('/santri'), api.get('/dashboard').catch(() => ({ data: { petugas: [] } }))]);
      setList(s.data || []);
      setPetugasList(d.data?.petugas || []);
      if (s.data && s.data.length > 0) setSelectedId((curr) => curr || s.data[0].id);
    } catch (err) {
      console.error('Failed to load data:', err);
      toast.error('Gagal memuat data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    const sel = list.find((x) => x.id === selectedId);
    if (sel) setSeragam(JSON.parse(JSON.stringify(sel.seragam || {})));
    else setSeragam(null);
  }, [selectedId, list]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return list;
    return list.filter((x) => (x.nama || '').toLowerCase().includes(s) || (x.nis || '').toLowerCase().includes(s));
  }, [list, q]);

  const selected = list.find((x) => x.id === selectedId);

  const updateField = (color, field, val) => {
    setSeragam((s) => ({ ...s, [color]: { ...(s?.[color] || {}), [field]: val } }));
  };

  const save = async () => {
    if (!selected || !seragam) return;
    setSaving(true);
    try {
      const { data } = await api.put(`/santri/${selected.id}`, { seragam });
      setList((cur) => cur.map((x) => x.id === selected.id ? data : x));
      toast.success('Data seragam tersimpan');
    } catch (e) {
      toast.error(e?.response?.data?.detail || 'Gagal menyimpan');
    } finally {
      setSaving(false);
    }
  };

  const buildWaMessage = () => {
    if (!selected || !seragam) return '';
    const lines = [
      `Assalamualaikum, mohon dicatat ukuran seragam santri:`,
      `Nama: ${selected.nama}`,
      `NIS: ${selected.nis}`,
      `--- Ukuran ---`,
      ...SET_KEYS.map((sk) => `• ${sk.label}: Sergm ${seragam?.[sk.key]?.ukuran_seragam || '-'} | Sarung ${seragam?.[sk.key]?.ukuran_sarung || '-'}`),
      '',
      'Mohon diproses. Terima kasih.',
    ];
    return lines.join('\n');
  };

  // Pick first admin petugas as default contact target (could pick by role)
  const targetPetugas = petugasList.find((p) => p.role === 'admin') || petugasList[0];

  return (
    <DashboardShell title="Seragam Santri" subtitle="Ukuran 3 warna seragam (Biru, Ungu, Coklat) & sarungnya">
      <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-4">
        <Card>
          <CardHeader className="pb-2">
            <div className="font-display font-semibold">Pilih Santri</div>
            <div className="relative mt-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari santri" className="pl-9" />
            </div>
          </CardHeader>
          <CardContent className="max-h-[480px] overflow-y-auto p-2">
            {loading ? (
              <div className="text-sm text-muted-foreground p-4">Memuat...</div>
            ) : filtered.map((s) => (
              <button
                type="button"
                key={s.id}
                onClick={() => { setSelectedId(s.id); setParams({ id: s.id }); }}
                data-testid={`${SERAGAM.santriSelect}-${s.nis}`}
                className={`w-full text-left rounded-lg px-3 py-2 mb-1 min-h-11 transition-colors ${selectedId === s.id ? 'bg-[hsl(var(--accent))]' : 'hover:bg-[hsl(var(--muted))]'}`}
              >
                <div className="text-sm font-semibold truncate">{s.nama}</div>
                <div className="text-[11px] text-muted-foreground flex items-center gap-2">
                  <span className="font-mono">NIS: {s.nis}</span>
                  {s.seragam?.all_delivered && <Badge className="bg-[hsl(var(--success))]/12 text-[hsl(var(--success))] border-[hsl(var(--success))]/25 text-[10px]">OK</Badge>}
                </div>
              </button>
            ))}
          </CardContent>
        </Card>

        <div className="space-y-4">
          {!selected || !seragam ? (
            <Card><CardContent className="p-10 text-center text-muted-foreground">Pilih santri untuk mengelola seragam.</CardContent></Card>
          ) : (
            <>
              {SET_KEYS.map((sk) => (
                <Card key={sk.key}>
                  <CardContent className="p-4 sm:p-5">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <span className={`w-2.5 h-2.5 rounded-full ${sk.dotClass}`} />
                        <div className="font-display font-semibold">{sk.label}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className={`text-[10px] ${seragam[sk.key]?.ready ? 'border-[hsl(var(--info))]/30 text-[hsl(var(--info))]' : ''}`}>
                          {seragam[sk.key]?.ready ? 'Tersedia' : 'Belum tersedia'}
                        </Badge>
                        <Badge
                          className={`text-[10px] ${seragam[sk.key]?.delivered ? 'bg-[hsl(var(--success))]/12 text-[hsl(var(--success))] border-[hsl(var(--success))]/25' : 'bg-transparent text-muted-foreground border-[hsl(var(--border))]'}`}
                        >
                          {seragam[sk.key]?.delivered ? 'Diserahkan' : 'Belum diserahkan'}
                        </Badge>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <Label>Ukuran Seragam</Label>
                        <Select value={seragam[sk.key]?.ukuran_seragam || ''} onValueChange={(v) => updateField(sk.key, 'ukuran_seragam', v)}>
                          <SelectTrigger data-testid={`${SERAGAM.sizeInput}-${sk.key}-seragam`}><SelectValue placeholder="Pilih ukuran" /></SelectTrigger>
                          <SelectContent>{SIZE_OPTIONS.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1.5">
                        <Label>Ukuran Sarung</Label>
                        <Select value={seragam[sk.key]?.ukuran_sarung || ''} onValueChange={(v) => updateField(sk.key, 'ukuran_sarung', v)}>
                          <SelectTrigger data-testid={`${SERAGAM.sizeInput}-${sk.key}-sarung`}><SelectValue placeholder="Pilih ukuran sarung" /></SelectTrigger>
                          <SelectContent>{SARUNG_OPTIONS.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-4 mt-3">
                      <label className="flex items-center gap-2 text-sm cursor-pointer">
                        <Checkbox checked={!!seragam[sk.key]?.ready} onCheckedChange={(v) => updateField(sk.key, 'ready', !!v)} />
                        Sudah tersedia
                      </label>
                      <label className="flex items-center gap-2 text-sm cursor-pointer">
                        <Checkbox
                          data-testid={`${SERAGAM.delivered}-${sk.key}`}
                          checked={!!seragam[sk.key]?.delivered}
                          onCheckedChange={(v) => updateField(sk.key, 'delivered', !!v)}
                        />
                        Sudah diserahkan
                      </label>
                    </div>
                  </CardContent>
                </Card>
              ))}
              <Card>
                <CardContent className="p-3 sm:p-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-2 sm:gap-3 justify-between">
                  <div className="text-xs text-muted-foreground flex items-center gap-2"><Shirt className="w-4 h-4" /> Konfirmasi ukuran ke petugas via WhatsApp</div>
                  <div className="flex items-center gap-2">
                    <a
                      href={targetPetugas?.wa_number ? buildWaLink(targetPetugas.wa_number, buildWaMessage()) : '#'}
                      target="_blank"
                      rel="noopener noreferrer"
                      data-testid={SERAGAM.waConfirm}
                      onClick={(e) => { if (!targetPetugas?.wa_number) { e.preventDefault(); toast.error('Belum ada petugas dengan nomor WA'); } }}
                    >
                      <Button variant="secondary" size="sm" className="gap-1.5"><MessageCircle className="w-4 h-4" /> Kirim ke Petugas</Button>
                    </a>
                    <Button data-testid={SERAGAM.save} size="sm" onClick={save} disabled={saving} className="gap-1.5 bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90 min-w-[120px]">
                      {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} Simpan
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </div>
    </DashboardShell>
  );
}
