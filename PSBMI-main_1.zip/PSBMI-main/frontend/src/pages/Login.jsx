import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { LOGIN } from '@/constants/testIds';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { Toaster } from '@/components/ui/sonner';
import { GraduationCap, Loader2 } from 'lucide-react';

export default function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('admin123');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (user) navigate('/', { replace: true });
  }, [user, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (!username || !password) {
      setError('Username & password wajib diisi');
      return;
    }
    setLoading(true);
    try {
      const u = await login(username.trim(), password);
      toast.success(`Selamat datang, ${u.nama}`);
      navigate('/', { replace: true });
    } catch (err) {
      const msg = err?.response?.data?.detail || 'Login gagal';
      setError(msg);
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-dvh grid grid-cols-1 lg:grid-cols-2 bg-[hsl(var(--background))]">
      {/* Left brand panel */}
      <div className="relative hidden lg:flex flex-col justify-between bg-[hsl(var(--primary))] text-white p-10 pattern-bg overflow-hidden">
        <div className="relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-white/15 backdrop-blur flex items-center justify-center">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <div className="font-display font-semibold tracking-tight">Pondok Pesantren Amtsilati</div>
              <div className="text-xs text-white/80">Sistem Pendataan Santri</div>
            </div>
          </div>
        </div>
        <div className="relative z-10 max-w-sm">
          <h2 className="font-display text-3xl xl:text-4xl font-semibold leading-tight tracking-tight">
            Tertib administrasi, tenang berkhidmat.
          </h2>
          <p className="text-sm text-white/85 mt-3">
            Kelola data santri, administrasi, seragam, perlengkapan asrama, hingga name tag &amp; KTS
            dalam satu sistem yang ringan untuk dipakai sehari-hari.
          </p>
        </div>
        <div className="relative z-10 text-xs text-white/70">
          © {new Date().getFullYear()} Pondok Pesantren Amtsilati
        </div>
        <div className="absolute -right-24 -bottom-24 w-[420px] h-[420px] rounded-full bg-white/5 blur-2xl" />
        <div className="absolute -left-10 top-10 w-[260px] h-[260px] rounded-full bg-white/5 blur-3xl" />
      </div>

      {/* Right form */}
      <div className="flex items-center justify-center p-5 sm:p-10">
        <Card className="w-full max-w-md rounded-[var(--radius-lg)] border border-[hsl(var(--border))] shadow-[var(--shadow-md)]">
          <CardHeader className="pb-2">
            <div className="flex items-center gap-2 lg:hidden mb-3">
              <div className="w-10 h-10 rounded-xl bg-[hsl(var(--primary))] text-white flex items-center justify-center">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div>
                <div className="font-display font-semibold text-sm">Amtsilati</div>
                <div className="text-[11px] text-muted-foreground">Manajemen Santri</div>
              </div>
            </div>
            <h1 className="font-display text-2xl font-semibold tracking-tight">Masuk ke Dasbor</h1>
            <p className="text-sm text-muted-foreground">Silakan masuk menggunakan akun petugas/admin Anda.</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  data-testid={LOGIN.username}
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  autoComplete="username"
                  placeholder="admin"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="password">Sandi</Label>
                <Input
                  id="password"
                  data-testid={LOGIN.password}
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="current-password"
                  placeholder="••••••••"
                />
              </div>
              {error && (
                <div data-testid={LOGIN.error} className="text-sm text-[hsl(var(--destructive))]">{error}</div>
              )}
              <Button
                type="submit"
                data-testid={LOGIN.submit}
                disabled={loading}
                className="w-full min-h-11 bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90 text-[hsl(var(--primary-foreground))]"
              >
                {loading && <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />}
                Masuk
              </Button>
              <div className="text-[11px] text-muted-foreground text-center">
                Default admin: <span className="font-semibold">admin</span> / <span className="font-semibold">admin123</span>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
      <Toaster position="top-center" richColors />
    </div>
  );
}
