import React, { useCallback, useEffect, useState } from 'react';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { api } from '@/lib/api';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { DASHBOARD } from '@/constants/testIds';
import { formatRupiah, buildWaLink } from '@/lib/format';
import { Users, Wallet, ShieldCheck, BedDouble, ExternalLink, MessageCircle, ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { toast } from 'sonner';

function KpiCard({ icon: Icon, label, value, accent, testId, hint }) {
  return (
    <Card data-testid={testId} className="rounded-[var(--radius-lg)] border bg-white shadow-[var(--shadow-sm)] hover:shadow-[var(--shadow-md)] transition-shadow">
      <CardContent className="p-4 sm:p-5">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="text-[11px] sm:text-xs uppercase tracking-wider text-muted-foreground font-semibold">{label}</div>
            <div className="font-display text-2xl sm:text-3xl font-semibold tabular-nums tracking-tight mt-1">{value}</div>
            {hint && <div className="text-[11px] text-muted-foreground mt-0.5">{hint}</div>}
          </div>
          <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${accent}`}>
            <Icon className="w-5 h-5" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const loadDashboard = useCallback(async (signal) => {
    try {
      const { data: resp } = await api.get('/dashboard');
      if (!signal?.aborted) setData(resp);
    } catch (err) {
      if (!signal?.aborted) {
        console.error('Failed to load dashboard:', err);
        toast.error('Gagal memuat dashboard');
      }
    } finally {
      if (!signal?.aborted) setLoading(false);
    }
  }, []);

  useEffect(() => {
    const ctrl = new AbortController();
    loadDashboard(ctrl.signal);
    return () => ctrl.abort();
  }, [loadDashboard]);

  return (
    <DashboardShell
      title="Dashboard Utama"
      subtitle="Ringkasan operasional pendataan santri"
      actions={
        <a
          href={data?.psb_admin_link || 'https://psb.amtsilatipusat.com/admin'}
          target="_blank"
          rel="noopener noreferrer"
          data-testid={DASHBOARD.psbAdminLink}
        >
          <Button variant="outline" size="sm" className="gap-1.5">
            <ExternalLink className="w-4 h-4" />
            <span className="hidden sm:inline">PSB Admin</span>
          </Button>
        </a>
      }
    >
      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 sm:gap-4">
        {loading ? (
          ['santri', 'uang', 'seragam', 'perlengkapan'].map((slot) => (
            <Skeleton key={`kpi-skel-${slot}`} className="h-[112px] rounded-[var(--radius-lg)]" />
          ))
        ) : (
          <>
            <KpiCard
              icon={Users}
              label="Jumlah Santri"
              value={data?.santri_count ?? 0}
              accent="bg-[hsl(var(--accent))] text-[hsl(var(--primary))]"
              testId={DASHBOARD.kpiSantri}
              hint="Total santri terdaftar"
            />
            <KpiCard
              icon={Wallet}
              label="Uang Diterima"
              value={formatRupiah(data?.paid_uang ?? 0)}
              accent="bg-[hsl(var(--primary))]/10 text-[hsl(var(--primary))]"
              testId={DASHBOARD.kpiUang}
              hint={`dari total ${formatRupiah(data?.total_uang ?? 0)}`}
            />
            <KpiCard
              icon={ShieldCheck}
              label="Seragam Lengkap"
              value={data?.seragam_lengkap ?? 0}
              accent="bg-[hsl(var(--success))]/12 text-[hsl(var(--success))]"
              testId={DASHBOARD.kpiSeragam}
              hint="Sudah diserahkan ke santri"
            />
            <KpiCard
              icon={BedDouble}
              label="Perlengkapan Lengkap"
              value={data?.perlengkapan_lengkap ?? 0}
              accent="bg-[hsl(var(--info))]/12 text-[hsl(var(--info))]"
              testId={DASHBOARD.kpiPerlengkapan}
              hint="Asrama siap pakai"
            />
          </>
        )}
      </div>

      {/* Petugas list & quick actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 sm:gap-4 mt-4">
        <Card className="lg:col-span-2 rounded-[var(--radius-lg)]">
          <CardContent className="p-4 sm:p-5" data-testid={DASHBOARD.petugasList}>
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="font-display font-semibold">Data Petugas</div>
                <div className="text-xs text-muted-foreground">Hubungi petugas yang sedang bertugas via WhatsApp</div>
              </div>
              <Link to="/akses-admin">
                <Button variant="ghost" size="sm" className="gap-1">Kelola <ArrowUpRight className="w-3.5 h-3.5" /></Button>
              </Link>
            </div>
            <div className="divide-y">
              {(() => {
                if (loading) {
                  return ['skel-0', 'skel-1', 'skel-2'].map((k) => (
                    <Skeleton key={k} className="h-12 my-2" />
                  ));
                }
                const petugasList = data?.petugas || [];
                if (petugasList.length === 0) {
                  return (
                    <div className="text-sm text-muted-foreground py-6 text-center">
                      Belum ada petugas terdaftar.
                    </div>
                  );
                }
                return petugasList.map((p) => (
                  <div key={p.id} className="flex items-center gap-3 py-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={p.profile_photo || ''} alt={p.nama} />
                      <AvatarFallback className="bg-[hsl(var(--accent))] text-[hsl(var(--primary))] text-xs font-semibold">
                        {(p.nama || '?').split(' ').slice(0, 2).map((q) => q[0]).join('').toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold truncate">{p.nama}</div>
                      <div className="text-[11px] text-muted-foreground flex items-center gap-2">
                        <Badge variant="outline" className="capitalize text-[10px] px-1.5 py-0">{p.role}</Badge>
                        <span className="truncate">@{p.username}</span>
                      </div>
                    </div>
                    {p.wa_number ? (
                      <a
                        href={buildWaLink(p.wa_number, `Assalamualaikum ${p.nama}, ada keperluan terkait pesantren.`)}
                        target="_blank"
                        rel="noopener noreferrer"
                        data-testid={DASHBOARD.petugasWaButton}
                      >
                        <Button size="sm" variant="secondary" className="gap-1.5">
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">WA</span>
                        </Button>
                      </a>
                    ) : (
                      <span className="text-[11px] text-muted-foreground">No WA: -</span>
                    )}
                  </div>
                ));
              })()}
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-[var(--radius-lg)]">
          <CardContent className="p-4 sm:p-5">
            <div className="font-display font-semibold">Aksi Cepat</div>
            <div className="text-xs text-muted-foreground">Pintasan operasional harian</div>
            <div className="mt-4 space-y-2">
              <Link to="/data-diri" className="block">
                <Button variant="outline" className="w-full justify-start gap-2 min-h-11">+ Tambah Santri Baru</Button>
              </Link>
              <Link to="/santri" className="block">
                <Button variant="outline" className="w-full justify-start gap-2 min-h-11">Lihat Daftar Santri</Button>
              </Link>
              <Link to="/administrasi" className="block">
                <Button variant="outline" className="w-full justify-start gap-2 min-h-11">Catat Pembayaran &amp; Kwitansi</Button>
              </Link>
              <a
                href={data?.psb_admin_link || 'https://psb.amtsilatipusat.com/admin'}
                target="_blank"
                rel="noopener noreferrer"
                className="block"
              >
                <Button variant="secondary" className="w-full justify-start gap-2 min-h-11">
                  <ExternalLink className="w-4 h-4" /> Buka PSB Admin Pusat
                </Button>
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  );
}
