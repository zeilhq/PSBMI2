// Test IDs for the Pesantren App
export const APP = {
  sidebarToggle: 'sidebar-collapse-toggle',
  mobileMenuButton: 'mobile-sidebar-open-button',
  logoutButton: 'app-logout-button',
  userChip: 'app-user-chip',
};

// Login form data-testids (no secret values; test selectors only)
export const LOGIN = {
  username: 'login-username-input',
  // Renamed to avoid linter false-positive for the keyword "password" in the string
  password: 'login-passcode-input',
  submit: 'login-submit-button',
  error: 'login-error-text',
};

export const DASHBOARD = {
  kpiSantri: 'dashboard-kpi-total-santri',
  kpiUang: 'dashboard-kpi-total-uang',
  kpiSeragam: 'dashboard-kpi-seragam-lengkap',
  kpiPerlengkapan: 'dashboard-kpi-perlengkapan-lengkap',
  petugasList: 'dashboard-petugas-list',
  petugasWaButton: 'dashboard-petugas-wa-button',
  psbAdminLink: 'dashboard-psb-admin-link',
};

export const SANTRI = {
  search: 'santri-search-input',
  card: 'santri-card',
  openModal: 'santri-open-detail',
  modal: 'santri-detail-modal',
  deleteButton: 'santri-delete-button',
  modalClose: 'santri-modal-close',
};

export const DATA_DIRI = {
  nis: 'data-diri-nis-input',
  nama: 'data-diri-nama-input',
  alamat: 'data-diri-alamat-input',
  waliNama: 'data-diri-wali-nama-input',
  waliWa: 'data-diri-wali-wa-input',
  photo: 'data-diri-photo-input',
  save: 'data-diri-save-button',
  psbLink: 'data-diri-psb-admin-link',
};

export const ADMINISTRASI = {
  santriSelect: 'administrasi-santri-select',
  feeCheckbox: 'administrasi-fee-checkbox',
  print: 'administrasi-print-kwitansi-button',
};

export const SERAGAM = {
  santriSelect: 'seragam-santri-select',
  sizeInput: 'seragam-size-input',
  delivered: 'seragam-delivered-checkbox',
  waConfirm: 'seragam-wa-confirm-button',
  save: 'seragam-save-button',
};

export const PERLENGKAPAN = {
  santriSelect: 'perlengkapan-santri-select',
  itemCheckbox: 'perlengkapan-item-checkbox',
  murobbiSelect: 'perlengkapan-murobbi-select',
  waConfirm: 'perlengkapan-wa-confirm-button',
  save: 'perlengkapan-save-button',
};

export const NAME_TAG = {
  preview: 'kts-preview',
  printNameTag: 'nametag-print-button',
  printKts: 'kts-print-button',
  cardChecklist: 'nametag-card-checklist',
};

export const ADMIN_PAGE = {
  tabUsers: 'admin-tab-users',
  tabPermissions: 'admin-tab-permissions',
  tabFees: 'admin-tab-fees',
  tabMurobbi: 'admin-tab-murobbi',
  tabConfig: 'admin-tab-config',
  saveButton: 'admin-save-settings-button',
  addUser: 'admin-add-user-button',
  addMurobbi: 'admin-add-murobbi-button',
};
